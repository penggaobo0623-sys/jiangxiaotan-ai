# v0.5.0 / schema v3 架构增量（2026-10-19）

本节为最新约定，后续旧版章节作为历史。保留React/TypeScript/Vite、FastAPI、SQLite及已有业务入口，无新增依赖。

## 数据与事务

initialize在BEGIN IMMEDIATE中将v1/v2升级到v3，添加sales_records/expenses.deleted_at，及business_days、record_audit、submissions、model_calls、model_cache。保留已有行、编号和快照，不播种数据，不预先确认旧状态；迁移失败回滚，更高版本拒绝。

- day_state.py集中解释状态和变更失效。旧销售默认显示待核对但不创建已核对记录；仅有支出不推断营业。零销售是明确声明，休息日允许支出；销售与休息/零声明冲突由接口处理。
- 所有历史与汇总排除已软删除记录；商品历史关联计数保留回收区关联。恢复保留原快照，重新核对。record_audit保存关键增改删、状态与收摊凭据，无操作者鉴权，不是不可篡改审计系统。
- POST /api/closing在同一写事务内校验商品快照与支出、插入全部记录和提交凭据。相同request_id+内容返回原结果，冲突返回409，0数量只记提交凭据，不插入销售行。GET /api/closing/requests/{id}核对保存结果。
- 单条销售/支出可带request_id，前端同页网络不确定时复用编号；旧客户端未传编号仍兼容，不能保证其幂等。PUT编辑为明确替换，DELETE软删。
- /api/recycle按日期列已删除记录，/api/recycle/{sales|expenses}/{id}/restore恢复；/api/audit查看最近200条，完整历史可JSON导出。
- /api/data/backup从只读连接SQLite backup到内存，integrity_check后下载；/api/data/export只读事务导出业务表与历史。不支持恢复覆盖。

## 科学汇总与自然表达

summary与analysis_summary统一排除软删。未知和休息均不自动补零；商家明确零销售提供零值。费用不齐时只是已录入费用下的估算结余。全商品扫描最低负毛利，即使在明细前20之外仍提供证据；不因候选长度丢失这一提示。首尾比较要求各日明确核对，仍不称趋势或因果。

analysis的schema2保留finding/evidence/action引用，只允许模型自由组织可选行动和复盘，不接受自由事实观察。natural_text检查格式、断言与未核实数字，事实、金额、日期、局限仍由后端提供。保留schema1兼容；自动规则无法保证所有语义正确，来源说明明确人审边界。

marketing独立确认商品、特色、主题、渠道、风格和活动。schema2由模型提供邀请标题与条件场景短句，服务端渲染名称、价格、确认特色和活动；数字型特色保留于已确认事实，不允许模型另造数值。主题不是活动证明。编辑草稿标记未重新校验，不能自动发布。

## 调用保护

model_usage按本库北京时间记录真实请求，发送前BEGIN IMMEDIATE预占，失败和中断不返还，跨进程并发不越过AI_DAILY_CALL_LIMIT（默认20）。不是金额预算，不计旧版本/其他库/其他应用调用。预览与普通页面读取不调用模型。

已校验结果按输入、目标、provider/base/model/输出限制及提示词版本哈希缓存24小时；不含密钥。读取需既有来源许可；regenerate主动跳过缓存。摘要和商品在生成后再次核对指纹。进程内共享锁保留；跨进程仅保证次数上限，不承诺相同请求严格只产生一次模型调用。

调用回执保留脱敏模型标识、耗时、HTTP、token、规则校验情况。可配置每百万token价格估算，未取得完整用量/价格显示未知。缓存回执明确属于历史调用，不把原用量当作本次新消费。备份包含缓存/回执，不包含.env。

## 页面和保护

Care.tsx收摊/状态/回收区/导出；Confirmation.tsx统一确认；UnsavedGuard与unsaved处理站内离开/日期/后退提醒，beforeunload由浏览器决定是否显示。草稿仅内存，未增加静默长期存储。字号和点击区已改善，375 CSS像素做过布局检查，尚未声称完整无障碍达标。

测试环境固定独立数据库与模拟设置，scripts/serve_care_qa.py只监听8013；前端预览5186。本轮未对默认库执行迁移。用户重启正常服务时才迁移其库。Windows批处理保持原格式。

---

以下为旧版本架构与历史验收，冲突时以上述当前章节为准。

# 2026-10-19真实验收增量

生产摘要、Gateway、分析与营销严格校验已通过3次DeepSeek官方真实API。没有为通过验收放宽事实规则或修改数据结构。

scripts/accept_deepseek.py为本次有限授权使用，执行前将计数写入artifacts/deepseek/real-20261019/calls.json，专用锁阻止并发脚本；week/sparse/marketing各最多一次，总数3。失败和中断保守占用额度，超限在网络前拒绝。只对独立演示库create_app，环境密钥仅在内存使用，off/false和.env不改写。此锁/计数只约束专用验收脚本，不是普通网页的计费配额或长期调用审计。

每次保存已处理结果、脱敏返回模型标识、用量、耗时、校验状态和数据保护摘要，不保存未校验原文/思考。测试用TestClient经过生产业务路由并真实调用官方网络；不是浏览器真实模型验收。详细记录见docs/DEEPSEEK_ACCEPTANCE_20261019.md。

---

# v0.4.0 架构增量（2026-10-18）

现有数据库v2与历史快照口径保持不变；没有新增数据表或破坏性迁移。

## 模型连接与结果记录

analysis_summary.py生成整数分事实、证据与候选行动；analysis.py负责授权、摘要指纹及结果校验；model_gateway.py负责传输。marketing.py单独定义已确认商品事实和表达选择格式，复用同一个Gateway及本进程互斥锁。

AI_PROVIDER=deepseek时只允许官方api.deepseek.com（demo/test本机模拟除外），支持根路径、/v1或完整chat/completions路径，拒绝重复/v1、第三方地址、URL密钥和重定向。AI_PROVIDER=compatible保留以后替换能力。厂商地址、模型、密钥从后端配置读取；DeepSeek专用thinking disabled、response_format json_object仅在连接层加入。只解析最终message.content；finish_reason非stop、空内容、畸形/过大响应均失败，不展示reasoning_content。

请求限60000字节、响应65536字节；输出默认1600 tokens，AI_MAX_OUTPUT_TOKENS限制256–4096；超时默认15秒、配置上限20秒；没有自动重试。HTTP响应成功不代表业务校验通过。返回脱敏call包含配置/返回模型、耗时、HTTP状态、服务提供的tokens及validation_passed；失败也尽量提供收到的用量信息，未收到则未知。没有持久化调用日志、精确计费或跨进程限流。前端不持有密钥。

## 营销事实与接口

| API | 行为 |
| --- | --- |
| GET /api/marketing/config | 仅取可用性及来源，不调用模型 |
| POST /api/marketing/preview | 校验当前商品、价格和商家确认事实，返回发送预览/指纹 |
| POST /api/marketing | 比对指纹与同意状态，模板或主动调用；再校验最新商品，返回待审草稿 |

商品名称和当前售价从数据库读取；特色须确认，只允许非数值口味/制作方式描述；优惠仅支持明确确认的活动价及起止日期。禁止借特色字段加入销量、排名、折扣、功效等。模型结果只允许schema_version、style_id及headline_id；后端严格枚举校验并组装已确认事实，模型没有机会输出任意价格或新优惠。此设计限制表达丰富度，并不能验证商家所填特色是否真实，使用前仍需人工审核。

营销不发送成本、销量或利润、不存草稿、不发布。分析仅发送经营摘要与候选证据，不发送支出备注、数据库文件或密钥。分析与营销都在生成期间复核指纹，变化返回409；并发返回429。

## 前端与备份

营业操作用同步inFlight标志及disabled字段防重复/编辑竞态；分析与文案增加1200毫秒双击抑制，没有自动重发。分析页前台每15秒和获得焦点时只读取本机摘要，变化后撤下旧分析；不是实时多设备同步。营销变更字段立即清空确认预览。

scripts/backup.py使用只读SQLite backup生成唯一文件并执行integrity_check，不覆盖原库或旧备份。备份失败不报告成功，可能遗留未完成文件。无自动恢复入口；恢复真实库须另行确认。

---

# 技术架构

## 技术选择

采用 React + TypeScript + Vite、Tailwind CSS、Recharts、Python + FastAPI、SQLite。适合单人维护、中文移动页面与小规模本地持久化。TypeScript 提前发现前端数据类型错误；FastAPI 提供输入验证和接口文档；SQLite 无需单独安装数据库服务。

第一版使用 Python 标准库 sqlite3，暂不引入 ORM、Redis、任务队列、向量库等额外组件。金额用整数分，避免浮点误差。API 响应用 Pydantic 定义，生成 OpenAPI。

## 请求链路

```mermaid
flowchart LR
    Browser[浏览器 React 页面] -->|同源 /api 请求| Vite[Vite 开发服务 5173]
    Vite -->|代理| API[FastAPI 8000]
    API --> Summary[汇总与计算]
    Summary --> DB[(SQLite 持久化数据库)]
```

本地开发后端仅监听 127.0.0.1；前端通过 Vite 代理连接后端。赛前版本已实现可选模型连接，仅由后端读取环境变量；默认关闭，本轮无外部模型请求。

## v0.2 接口

| 接口 | 参数 | 行为 |
| --- | --- | --- |
| GET /api/health | 无 | 实际查询数据库，返回服务与数据库状态、结构版本 |
| GET /api/dashboard | 可选 business_date，YYYY-MM-DD | 返回当日指标、近七天趋势、近七天商品销售额排行和口径说明 |

非法日期或超出 2000-01-01 至 2100-12-31 范围的查询由 FastAPI 返回 422，避免极端日期导致七天窗口越界。营业日默认按北京时间计算。第二阶段所有写入接口实行严格校验。

## 数据库结构 v2 与迁移

首次启动创建父目录与三张表；通过 `PRAGMA user_version = 2` 记录版本。初始化在 BEGIN IMMEDIATE 事务内为 v0/v1 检查字段并执行 ALTER TABLE products ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0, 1))，最后更新版本并提交；失败回滚。保留原行、编号、快照，旧商品默认启用；重复初始化不重复添加字段；高于 v2 的库拒绝打开。升级无需删除或重建旧库。

| 表 | 核心字段 | 用途 |
| --- | --- | --- |
| products | id、name、price_cents、unit_cost_cents、is_active、created_at | 商品定义，停用保留历史 |
| sales_records | id、product_id（可空）、product_name、business_date、quantity、unit_price_cents、unit_cost_cents、created_at | 每日商品销售汇总及当时价格成本快照 |
| expenses | id、business_date、category、amount_cents、created_at | 当日额外支出，与销售分开，避免重复计算 |

金额为 INTEGER；销量正整数；商品售价与单位成本非负；额外支出为正数；名称不能为空且最多 60 字符。启用外键；商品有关联销售时禁止直接物理删除。营业日建立索引。SQL 使用参数绑定。日期完整业务校验在所有写入接口执行，不接受客户端提交计算结果。

初始化和迁移不插入业务数据。自动化测试在 pytest 临时数据库插入独立测试样本；浏览器验收显式指定 artifacts/phase2/ui-20261015.db。APP_ENV=test 仅控制健康接口 test_mode 标记，不会自动切换数据库，必须同时指定 DATABASE_PATH。

## 计算与缺失值

销售额 = Σ(销量 × 售价)。商品估算毛利 = Σ[销量 × (售价 − 单位成本)]。记录成本 = Σ(销量 × 单位成本) + Σ(额外支出)。估算利润 = 销售额 − 记录成本。

销售记录缺失时营业额与利润为 null；记录成本在当日有销售或支出记录时计算，否则为 null。未记录日期在趋势中保留日期并显示空缺。商品排行按七天销售额降序，同额按名称排序。有商品编号的记录按编号汇总，名称取窗口内最新销售快照；旧记录 product_id 为空时按快照名称归组，与有编号的同名商品分开。停用不影响历史统计，显式编辑快照只影响该条记录；允许估算利润为负。

汇总不处理未记录费用，不声称计算真实净利润；不从记录条数推断订单数，不推断客流、天气或销量变动原因。

## 配置与部署方向

根目录 `.env` 只由后端读取；默认数据库 `backend/data/jiangxiaotan.db`。前端源码没有密钥。`.env`、数据库、虚拟环境、依赖与构建产物被 Git 忽略。根目录无密钥也可启动。

将来可以由 Nginx 托管前端构建，并把 `/api` 代理至 FastAPI。SQLite 使用持久卷与备份，单实例起步。开放公网前需实现身份鉴权、商家隔离、HTTPS 和部署测试。多实例与大规模并发需求出现后再评估 PostgreSQL。

技术用法参考：[Vite](https://vite.dev/guide/)、[Tailwind Vite 插件](https://tailwindcss.com/docs/installation/using-vite)、[FastAPI lifespan](https://fastapi.tiangolo.com/advanced/events/)。依赖实际解析版本由锁文件及 requirements 文件记录。


## 第二阶段业务接口与一致性

| 接口 | 输入及行为 |
| --- | --- |
| GET /api/products | 全部商品、启用状态、历史销售条数 |
| POST /api/products | name、price_cents、unit_cost_cents、is_active；创建返回 201 |
| PUT /api/products/{id} | 同上；修改商品资料或启用状态，不修改历史 |
| GET /api/records?business_date=YYYY-MM-DD | 单日销售快照和支出，省略日期使用北京时间今天 |
| POST /api/sales | product_id、business_date、quantity；事务内读取商品快照，返回 201 |
| PUT /api/sales/{id} | business_date、quantity、product_name、unit_price_cents、unit_cost_cents；显式更正该条历史快照，商品编号不可修改 |
| POST /api/expenses | business_date、category、amount_cents；返回 201 |
| PUT /api/expenses/{id} | 同上；更正日期、说明或金额 |
| DELETE /api/sales/{id}、/api/expenses/{id} | 删除单条记录返回 204；不存在返回 404 |

日期必须为存在的 YYYY-MM-DD；名称去除首尾空白，1–60 字，拒绝控制字符。销量严格整数 1–100000；金额严格整数分 0–100000000，支出最少 1 分；拒绝浮点、布尔值、数字字符串、额外字段。非法输入返回中文说明和 422，商品重名/停用商品新增销售返回 409，不存在返回 404。商品名称按 SQLite NOCASE 比较（包含停用商品）；保留旧库既有重名行，不强加可能破坏迁移的唯一索引。

商品没有物理删除 API。商品检查重名与写入、销售取快照与写入、历史修改删除使用写事务；历史、汇总使用一致读事务。动态 SQL 表名来自模块固定常量，其余参数绑定。当前面向本机单商家，尚无多用户版本冲突检测及审计日志。

前端 Business.tsx 提供表单、历史与确认删除；保存后触发历史、工作台及看板重新请求。money.ts 拆分十进制文本并用整数运算换算元/分，避免浮点金额乘 100。后端校验为最终边界。销售编辑展示旧快照，不自动套用新价格。删除弹窗说明对象、日期、金额及不可撤销，默认聚焦取消。超时提示先刷新核对，避免盲目重复提交。

## 赛前版本：分析模块

- analysis_summary.py：在单个读事务中读取历史快照与支出，计算截至选定日期的七日摘要、每日覆盖、缺失日期、商品明细、整数分合计、证据目录和候选发现。未录入支出为 null；计算估算利润只扣已录入支出并明确不完整。仅七天每天有销售记录时提供首尾两日金额比较，不称趋势或因果。
- model_gateway.py：Gateway 协议与兼容 Chat Completions 传输层。地址、模型、密钥、超时仅取后端配置；不依赖厂商专有功能，其他协议可另实现 Gateway。
- analysis.py：协调摘要、连接、选择校验及结果呈现。统一模型输出为 schema_version=1 + items[{finding_id,evidence_ids,action_id}]，1–5 项；严格拒绝额外自由文本、假数字、缺失/错误依据、错误行动、重复项、错误版本。模型可选择重点与顺序，事实/行动文字及局限来自后端候选，不展示任意模型自然语言。该约束限制生成丰富度，不能宣称开放式经营决策。
- Analysis.tsx：打开仅请求本机摘要；主动分析、同意勾选、加载/错误、来源、依据与日期逐条呈现。日期/记录变化清空旧结果，摘要 SHA256 不匹配返回 409，避免发送已过时且未经重新确认的摘要。

| API | 行为 |
| --- | --- |
| GET /api/analysis/preview?business_date=YYYY-MM-DD | 本机读取七日摘要、证据、候选行动和模型可用状态；不发模型请求 |
| POST /api/analysis | business_date、summary_hash、use_model、consent_to_send；主动分析，返回统一发现、来源、回退原因、时间及局限 |

默认 AI_MODE=off，或 AI_ALLOW_EXTERNAL=false、无密钥/不完整配置时返回 basic。仅 mode=remote、明确允许外部调用且配置完整，再由当次请求 consent_to_send=true 才调用；后端锁阻止本进程同时重复分析（429），没有自动重试。mock 仅允许 APP_ENV=demo/test，来源明确为模拟，不是大模型。

发送日期、商品快照名称、销量、金额、覆盖及候选行动；不发送支出备注、原始数据库或密钥。传输层 TLS 校验默认启用；仅本机 demo/test 模拟服务器允许 HTTP，拒绝 URL 内嵌用户名/密码/查询参数及重定向。请求上限 60 KB、响应上限 64 KB、默认输出上限 1600 tokens（可配置256–4096）；网络超时默认 15 秒、配置上限 20 秒。异常响应原文不进入前端或业务日志。当前无跨进程限流、分析缓存、历史分析保存或成本精确计量。

结构化日期范围、事实和证据在后端生成。产品仅传销售额前 20 款商品明细，合计仍包含所有商品；超过时明确列出遗漏数与分析局限。当前真实候选已改为 DeepSeek 官方 deepseek-flash，见 configs/deepseek.example.env；旧百炼示例只保留为可替换配置。真实调用仍待密钥及独立费用授权。

## 独立演示

scripts/demo.py + demo.cmd 使用固定 demo/data/{week,sparse,empty}/demo.db，不打开商家库。只在场景文件不存在时准备样本；重复启动保留记录，场景重建前手动停服务并改名备份。默认强制 AI_MODE=mock、禁用外部并清空子进程的模型密钥/地址，--real-model 才选择真实配置，后端费用开关与页面同意仍必需。

前端使用正式构建预览 5175、后端 8002，复用 manage.py 子进程管理、日志与等待逻辑；只新增生产 HTML/JS 内容检查和可传入检查列表，原 start.cmd 的默认五项检查与端口不变。health 增加 demo_mode/demo_business_date，界面标注演示数据并在首次连接选中该演示库最新记录日期。数据库仍为 v2，本轮不需要新迁移。
