import sqlite3
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.backup import backup


def test_readonly_backup_preserves_original_and_existing_backup(tmp_path):
    source=tmp_path/'original.db'
    with sqlite3.connect(source) as c:
        c.execute('CREATE TABLE sample(value INTEGER)');c.execute('INSERT INTO sample VALUES (29)')
    before=source.read_bytes()
    first=backup(source,tmp_path/'copies');second=backup(source,tmp_path/'copies')
    assert first!=second and source.read_bytes()==before
    for p in (first,second):
        with sqlite3.connect(p) as c: assert c.execute('SELECT value FROM sample').fetchone()[0]==29
