"""演示脚本只在临时目录准备样本，验证隔离、重启与不覆盖。"""
import importlib.util
from datetime import date
from pathlib import Path
import sqlite3
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
spec=importlib.util.spec_from_file_location('competition_demo',ROOT/'scripts'/'demo.py')
demo=importlib.util.module_from_spec(spec)
spec.loader.exec_module(demo)


def test_demo_isolation_repeat_and_preservation(tmp_path,monkeypatch):
    monkeypatch.setattr(demo,'ROOT',tmp_path)
    merchant=tmp_path/'backend'/'data'/'jiangxiaotan.db'
    merchant.parent.mkdir(parents=True);merchant.write_bytes(b'merchant sentinel')
    path=demo.prepare('week',date(2026,10,15))
    with sqlite3.connect(path) as con:
        assert con.execute('SELECT COUNT(*) FROM sales_records').fetchone()[0]==21
        assert con.execute('SELECT SUM(quantity*unit_price_cents) FROM sales_records').fetchone()[0]==259700
        con.execute("INSERT INTO expenses(business_date,category,amount_cents) VALUES ('2026-10-15','edit sentinel',1)")
    assert demo.prepare('week',date(2026,10,22))==path
    with sqlite3.connect(path) as con:
        assert con.execute('SELECT COUNT(*) FROM expenses').fetchone()[0]==5
    assert merchant.read_bytes()==b'merchant sentinel'
    empty=demo.prepare('empty',date(2026,10,15))
    sparse=demo.prepare('sparse',date(2026,10,15))
    for database,count in [(empty,0),(sparse,6)]:
        with sqlite3.connect(database) as con: assert con.execute('SELECT COUNT(*) FROM sales_records').fetchone()[0]==count
