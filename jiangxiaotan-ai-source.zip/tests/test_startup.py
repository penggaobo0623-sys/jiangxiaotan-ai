"""启动回归测试：隔离 HTTP 服务和临时脚本，不连接商家数据库。"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts import manage


@pytest.fixture
def http_server():
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/redirect":
                self.send_response(302)
                self.send_header("Location", "/health")
                self.end_headers()
                return
            self.send_response(503 if self.path == "/unavailable" else 200)
            self.end_headers()
            body = {"status": "ok", "database": "connected", "service": "江小摊 AI"}
            self.wfile.write(json.dumps(body).encode() if self.path == "/health" else b"wrong service")

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


def test_probe_uses_real_content_and_bypasses_proxy(http_server, monkeypatch):
    monkeypatch.setenv("HTTP_PROXY", "http://127.0.0.1:1")
    monkeypatch.setenv("HTTPS_PROXY", "http://127.0.0.1:1")
    monkeypatch.setenv("NO_PROXY", "")
    assert manage.probe_http(http_server + "/health", "health").ok
    assert not manage.probe_http(http_server + "/wrong", "health").ok
    assert "HTTP 302" in manage.probe_http(http_server + "/redirect", "health").detail
    assert "HTTP 503" in manage.probe_http(http_server + "/unavailable", "health").detail


def test_slow_start_over_90_seconds_keeps_waiting_and_requires_success(monkeypatch, tmp_path, capsys):
    clock = SimpleNamespace(now=0.0, attempts=0)
    process = SimpleNamespace(poll=lambda: None)
    services = [manage.Service("前端", process, tmp_path / "frontend.log")]

    def probe(url, kind):
        clock.attempts += 1
        return manage.ProbeResult(clock.attempts >= 3, "TimeoutError: timed out")

    monkeypatch.setattr(manage, "readiness_checks", lambda: [("前端首页", "http://127.0.0.1:5173/", "html")])
    monkeypatch.setattr(manage, "probe_http", probe)
    monkeypatch.setattr(manage.time, "monotonic", lambda: clock.now)
    monkeypatch.setattr(manage.time, "sleep", lambda _: setattr(clock, "now", clock.now + 91))
    manage.wait_for_services(services)
    output = capsys.readouterr().out
    assert clock.attempts == 3
    assert "等待已超过 90 秒" in output
    assert "进程将继续运行" in output
    assert "TimeoutError" in output
    assert "http://127.0.0.1:5173/" in output


def test_exited_process_reports_name_exit_code_and_log(tmp_path):
    log = tmp_path / "backend.log"
    log.write_text("ModuleNotFoundError: No module named 'uvicorn'", encoding="utf-8")
    service = manage.Service("后端", SimpleNamespace(poll=lambda: 17), log)
    with pytest.raises(RuntimeError, match="后端进程已退出（退出码 17）") as caught:
        manage.wait_for_services([service])
    assert "ModuleNotFoundError" in str(caught.value)
    assert str(log) in str(caught.value)


def test_launch_failure_cleans_up_already_started_service(monkeypatch, tmp_path):
    service = manage.Service("后端", SimpleNamespace(poll=lambda: None), tmp_path / "backend.log")
    launched = []
    stopped = []

    def launch(*args):
        if launched:
            raise OSError("cannot start node")
        launched.append(service)
        return service

    monkeypatch.setattr(manage, "ROOT", tmp_path)
    monkeypatch.setattr(manage, "is_port_free", lambda _: True)
    monkeypatch.setattr(manage, "launch_service", launch)
    monkeypatch.setattr(manage, "stop_services", lambda services: stopped.extend(services))
    with pytest.raises(OSError, match="cannot start node"):
        manage.start("node", no_browser=True)
    assert stopped == [service]


def test_occupied_port_does_not_start_or_stop_other_programs(monkeypatch):
    monkeypatch.setattr(manage, "is_port_free", lambda port: port != 5173)
    monkeypatch.setattr(manage, "launch_service", lambda *args: pytest.fail("占用端口时不应启动子进程"))
    monkeypatch.setattr(manage, "stop_services", lambda *args: pytest.fail("不应结束其他程序"))
    with pytest.raises(RuntimeError, match="端口 5173 已被占用"):
        manage.start("node", no_browser=True)


def test_browser_open_failure_keeps_ready_services_running(monkeypatch, tmp_path, capsys):
    stopped = []
    entered_monitor = []

    def launch(name, *args):
        return manage.Service(name, SimpleNamespace(poll=lambda: None), tmp_path / (name + ".log"))

    def browser_error(url):
        raise manage.webbrowser.Error("no default browser")

    def monitor(services):
        entered_monitor.append(True)
        raise KeyboardInterrupt

    monkeypatch.setattr(manage, "ROOT", tmp_path)
    monkeypatch.setattr(manage, "is_port_free", lambda port: True)
    monkeypatch.setattr(manage, "launch_service", launch)
    monkeypatch.setattr(manage, "wait_for_services", lambda services: None)
    monkeypatch.setattr(manage.webbrowser, "open", browser_error)
    monkeypatch.setattr(manage, "check_processes", monitor)
    monkeypatch.setattr(manage, "stop_services", lambda services: stopped.extend(services))
    manage.start("node", no_browser=False)
    assert entered_monitor == [True]
    assert len(stopped) == 2
    assert "服务继续运行" in capsys.readouterr().out


@pytest.mark.skipif(os.name != "nt", reason="验证真实 Windows cmd 解析")
@pytest.mark.parametrize("filename,action", [("start.cmd", "start"), ("setup.cmd", "install"), ("check.cmd", "check")])
def test_batch_scripts_encoding_paths_arguments_and_exit_codes(tmp_path, filename, action):
    project = tmp_path / "校园 测试项目"
    (project / "scripts").mkdir(parents=True)
    script = ROOT / filename
    data = script.read_bytes()
    assert data.isascii()
    assert b"\n" not in data.replace(b"\r\n", b"")
    shutil.copy2(script, project / filename)
    # 使用无业务逻辑的临时 Python 入口，绝不安装依赖或启动真实商家服务。
    (project / "scripts/manage.py").write_text(
        "import os,sys\nprint('PROBE',sys.argv[1:],os.environ.get('PYTHONUTF8'))\n"
        "sys.exit(int(os.environ.get('JXT_TEST_EXIT','0')))\n", encoding="utf-8",
    )
    for code in (0, 23):
        env = os.environ.copy()
        env["JXT_TEST_EXIT"] = str(code)
        # cmd 的命令字符串不能使用 Python 的 argv 引号转义（会产生字面量反斜杠）。
        command = f'cmd.exe /d /s /c ""{project / filename}" --no-browser"'
        result = subprocess.run(command, input=b"\r\n", capture_output=True, env=env, timeout=20)
        output = result.stdout.decode("utf-8", errors="replace")
        assert result.returncode == code, (result.returncode, output, result.stderr)
        assert f"'{action}', '--no-browser'" in output
        assert "] 1" in output
        assert not result.stderr, result.stderr
        if code:
            assert f"failed with exit code {code}" in output
