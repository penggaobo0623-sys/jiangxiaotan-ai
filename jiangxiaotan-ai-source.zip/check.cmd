@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not exist "scripts\manage.py" goto missing_project
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "scripts\manage.py" check %*
  goto finished
)
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
  "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" "scripts\manage.py" check %*
  goto finished
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "scripts\manage.py" check %*
  goto finished
)
where python >nul 2>nul
if errorlevel 1 goto missing_python
python "scripts\manage.py" check %*
goto finished
:missing_project
echo ERROR: scripts\manage.py was not found. Keep this file in the project folder.
set "JXT_EXIT=1"
goto complete
:missing_python
echo ERROR: Python was not found. Install Python 3.12 and enable Add Python to PATH.
set "JXT_EXIT=1"
goto complete
:finished
set "JXT_EXIT=%ERRORLEVEL%"
:complete
if not "%JXT_EXIT%"=="0" (
  echo.
  echo check failed with exit code %JXT_EXIT%. Read the error above and README.md.
  pause
) else (
  pause
)
exit /b %JXT_EXIT%
