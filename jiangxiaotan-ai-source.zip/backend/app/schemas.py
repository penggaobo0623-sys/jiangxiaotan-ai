from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    sample_data: bool = False
    demo_business_date: str | None = None
    demo_mode: bool = False
    test_mode: bool = False
    status: str
    service: str
    version: str
    database: str
    schema_version: int


class Metrics(BaseModel):
    gross_profit_cents: int | None = None
    extra_expense_cents: int | None = None
    revenue_cents: int | None
    recorded_cost_cents: int | None
    estimated_profit_cents: int | None
    sales_record_count: int
    expense_record_count: int
    order_count: int | None = None


class TrendPoint(BaseModel):
    date: str
    revenue_cents: int | None
    has_sales_records: bool


class ProductTotal(BaseModel):
    key: str
    product_id: int | None
    name: str
    quantity: int
    revenue_cents: int
    gross_profit_cents: int


class DashboardResponse(BaseModel):
    business_status: dict = Field(default_factory=dict)
    business_date: str
    timezone: str = "Asia/Shanghai"
    currency: str = "CNY"
    source: str = "recorded_data"
    has_data: bool
    metrics: Metrics
    trend: list[TrendPoint]
    product_ranking: list[ProductTotal]
    notices: list[str]

