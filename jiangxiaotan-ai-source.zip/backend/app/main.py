from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import os
import threading

from fastapi import FastAPI, Query
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from .config import cors_origins, database_path
from .database import connect, initialize
from .schemas import DashboardResponse, HealthResponse
from .summary import dashboard_summary
from .records import BusinessDay, create_records_router
from .analysis import create_analysis_router
from .marketing import create_marketing_router
from .care import create_care_router
from .model_gateway import ModelSettings, CompatibleGateway


def create_app(db_path: Path | None = None, model_settings=None, model_gateway=None) -> FastAPI:
    path = db_path if db_path is not None else database_path()

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        initialize(path)
        yield

    application = FastAPI(title="江小摊 AI", version="0.5.0", lifespan=lifespan)
    application.add_middleware(CORSMiddleware, allow_origins=cors_origins(), allow_methods=["GET", "POST", "PUT", "DELETE"], allow_headers=["Content-Type"])

    def today():
        return datetime.now(timezone(timedelta(hours=8))).date()

    application.include_router(create_records_router(path, today))
    application.include_router(create_care_router(path, today))
    settings=model_settings or ModelSettings.from_env()
    gateway=model_gateway or CompatibleGateway(settings)
    model_lock=threading.Lock()
    application.include_router(create_analysis_router(path, today, settings, gateway, model_lock))
    application.include_router(create_marketing_router(path,settings,gateway,model_lock))

    @application.exception_handler(RequestValidationError)
    async def invalid_input(request, error):
        fields = {"name": "商品名称", "product_name": "商品快照名称", "price_cents": "售价（分）", "unit_price_cents": "快照售价（分）", "unit_cost_cents": "单位成本（分）", "amount_cents": "支出金额（分）", "quantity": "销售数量", "business_date": "营业日期", "category": "支出说明", "product_id": "商品编号", "is_active": "商品状态"}
        messages = []
        fields.update({'status':'营业状态','request_id':'提交编号','expected_price_cents':'核对售价（分）','expected_cost_cents':'核对成本（分）','sales':'本次销量','expenses':'本次支出','theme':'宣传主题','style':'表达风格','channel':'使用场景','goal':'本次经营目标','summary_hash':'摘要标识','facts_hash':'确认内容标识'})
        for issue in error.errors():
            field = str(issue["loc"][-1])
            kind = issue["type"]
            if kind == "int_type":
                message = "必须填写整数，不接受小数、布尔值或字符串"
            elif kind == "extra_forbidden":
                message = "是不支持的字段，请勿提交计算结果或修改关联商品"
            elif kind == "missing":
                message = "不能为空"
            elif kind == "bool_type":
                message = "必须为启用或停用状态"
            elif kind == 'literal_error':
                message = '选项无效，请从页面提供的选项中选择'
            elif kind == 'string_pattern_mismatch':
                message = '格式无效，请重新核对或刷新页面获取新的标识'
            elif kind.startswith("string_"):
                message = "请填写符合页面长度要求的有效文字"
            elif kind in ("greater_than_equal", "less_than_equal"):
                message = "超出允许范围（金额 0–100000000 分，支出大于 0，数量 1–100000）"
            else:
                message = issue["msg"].removeprefix("Value error, ")
            messages.append(fields.get(field, field) + "：" + message)
        return JSONResponse(status_code=422, content={"detail": "；".join(messages)})

    @application.get("/api/health", response_model=HealthResponse)
    def health():
        with connect(path) as connection:
            connection.execute("SELECT 1").fetchone()
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            sample_data = any(connection.execute(f"SELECT 1 FROM {table} WHERE {field} LIKE '演示·%' LIMIT 1").fetchone() is not None
                              for table,field in [('products','name'),('sales_records','product_name'),('expenses','category')])
            demo_date = connection.execute("SELECT MAX(business_date) FROM (SELECT business_date FROM sales_records UNION ALL SELECT business_date FROM expenses)").fetchone()[0] if os.getenv("APP_ENV") == "demo" else None
        return HealthResponse(status="ok", service="江小摊 AI", version="0.5.0", database="connected", schema_version=version, test_mode=os.getenv("APP_ENV") == "test", demo_mode=os.getenv("APP_ENV") == "demo", demo_business_date=demo_date, sample_data=sample_data)

    @application.get("/api/dashboard", response_model=DashboardResponse)
    def dashboard(business_date: BusinessDay | None = Query(default=None, description="营业日期 YYYY-MM-DD（2000–2100 年）；默认北京时间今天")):
        return dashboard_summary(path, business_date or today())

    return application


app = create_app()

