"""第二阶段业务接口；事务内取商品快照，所有金额只使用整数分。"""
from datetime import date
from pathlib import Path
import hashlib
import json
import re
from typing import Annotated

from fastapi import APIRouter, HTTPException, Path as ApiPath, Query, Response
from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, StrictBool, StrictInt, StrictStr, field_validator

from .database import connect
from .day_state import allow_sale, invalidate, audit

MAX_CENTS = 100_000_000  # 单项金额上限 100 万元。


def parse_day(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError("营业日期必须为 YYYY-MM-DD")
    try:
        parsed = date.fromisoformat(value)
    except ValueError:
        raise ValueError("营业日期不存在") from None
    if not date(2000, 1, 1) <= parsed <= date(2100, 12, 31):
        raise ValueError("营业日期须在 2000-01-01 至 2100-12-31 之间")
    return parsed


BusinessDay = Annotated[date, BeforeValidator(parse_day)]
Cents = Annotated[StrictInt, Field(ge=0, le=MAX_CENTS)]
Quantity = Annotated[StrictInt, Field(ge=1, le=100_000)]
Name = Annotated[StrictStr, Field(min_length=1, max_length=60)]
PositiveId = Annotated[StrictInt, Field(ge=1)]


class InputModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    @field_validator("*", mode="before")
    @classmethod
    def clean_text(cls, value):
        if isinstance(value, str) and any(ord(char) < 32 or ord(char) == 127 for char in value):
            raise ValueError("名称或日期不能包含换行、制表等控制字符")
        return value


class ProductInput(InputModel):
    name: Name
    price_cents: Cents
    unit_cost_cents: Cents
    is_active: StrictBool = True


class ProductResponse(BaseModel):
    id: int
    name: str
    price_cents: int
    unit_cost_cents: int
    is_active: bool
    created_at: str
    sales_record_count: int


class SaleInput(InputModel):
    request_id: StrictStr | None = Field(default=None, pattern=r'^[a-zA-Z0-9_-]{16,80}$')
    product_id: PositiveId
    business_date: BusinessDay
    quantity: Quantity


class SaleEdit(InputModel):
    business_date: BusinessDay
    quantity: Quantity
    product_name: Name
    unit_price_cents: Cents
    unit_cost_cents: Cents


class SaleResponse(BaseModel):
    id: int
    product_id: int | None
    product_name: str
    business_date: str
    quantity: int
    unit_price_cents: int
    unit_cost_cents: int
    created_at: str
    revenue_cents: int
    gross_profit_cents: int


class ExpenseInput(InputModel):
    request_id: StrictStr | None = Field(default=None, pattern=r'^[a-zA-Z0-9_-]{16,80}$')
    business_date: BusinessDay
    category: Name
    amount_cents: Annotated[StrictInt, Field(ge=1, le=MAX_CENTS)]


class ExpenseResponse(BaseModel):
    id: int
    business_date: str
    category: str
    amount_cents: int
    created_at: str


class HistoryResponse(BaseModel):
    business_date: str
    sales: list[SaleResponse]
    expenses: list[ExpenseResponse]


def sale_result(row) -> SaleResponse:
    data = dict(row)
    data["revenue_cents"] = data["quantity"] * data["unit_price_cents"]
    data["gross_profit_cents"] = data["quantity"] * (data["unit_price_cents"] - data["unit_cost_cents"])
    return SaleResponse(**data)


def need_row(connection, table: str, record_id: int):
    # table 仅由本模块固定调用传入，不接受请求字符串。
    active = ' AND deleted_at IS NULL' if table in ('sales_records', 'expenses') else ''
    row = connection.execute(f"SELECT * FROM {table} WHERE id = ?{active}", (record_id,)).fetchone()
    if row is None:
        raise HTTPException(404, "记录不存在，可能已被删除；请刷新后重试。")
    return row


def product_result(connection, record_id: int) -> ProductResponse:
    data = dict(need_row(connection, "products", record_id))
    data["sales_record_count"] = connection.execute("SELECT COUNT(*) FROM sales_records WHERE product_id = ?", (record_id,)).fetchone()[0]
    return ProductResponse(**data)


def check_name(connection, name: str, record_id: int = 0):
    exists = connection.execute("SELECT id FROM products WHERE name = ? COLLATE NOCASE AND id <> ?", (name, record_id)).fetchone()
    if exists:
        raise HTTPException(409, "商品名称已存在，请修改名称或启用原有商品。")


def replay(con, body, kind):
    if not body.request_id: return None
    digest = hashlib.sha256(json.dumps([kind,body.model_dump(mode='json',exclude={'request_id'})],sort_keys=True).encode()).hexdigest()
    previous=con.execute('SELECT * FROM submissions WHERE request_id=?',(body.request_id,)).fetchone()
    if previous:
        if previous['payload_hash']!=digest: raise HTTPException(409,'提交编号与原内容不一致，请核对历史。')
        result=json.loads(previous['result_json'])
        need_row(con,kind,result['id'])  # 已移入回收区时不重复新建或恢复。
        return result
    return None


def remember(con,body,kind,result):
    if body.request_id:
        digest=hashlib.sha256(json.dumps([kind,body.model_dump(mode='json',exclude={'request_id'})],sort_keys=True).encode()).hexdigest()
        con.execute('INSERT INTO submissions(request_id,payload_hash,result_json) VALUES (?,?,?)',(body.request_id,digest,result.model_dump_json()))
    return result


def create_records_router(path: Path, today) -> APIRouter:
    router = APIRouter(prefix="/api")

    @router.get("/products", response_model=list[ProductResponse])
    def products():
        with connect(path) as connection:
            rows = connection.execute("""SELECT p.*, COUNT(s.id) AS sales_record_count FROM products p
                LEFT JOIN sales_records s ON s.product_id = p.id GROUP BY p.id ORDER BY p.is_active DESC, p.id DESC""").fetchall()
            return [ProductResponse(**dict(row)) for row in rows]

    @router.post("/products", response_model=ProductResponse, status_code=201)
    def add_product(body: ProductInput):
        with connect(path) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            check_name(connection, body.name)
            cursor = connection.execute("INSERT INTO products(name, price_cents, unit_cost_cents, is_active) VALUES (?, ?, ?, ?)", (body.name, body.price_cents, body.unit_cost_cents, int(body.is_active)))
            return product_result(connection, cursor.lastrowid)

    @router.put("/products/{record_id}", response_model=ProductResponse)
    def edit_product(body: ProductInput, record_id: int = ApiPath(ge=1)):
        with connect(path) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            need_row(connection, "products", record_id)
            check_name(connection, body.name, record_id)
            before = need_row(connection, 'products', record_id)
            connection.execute("UPDATE products SET name=?, price_cents=?, unit_cost_cents=?, is_active=? WHERE id=?", (body.name, body.price_cents, body.unit_cost_cents, int(body.is_active), record_id))
            audit(connection, 'products', record_id, 'edit', before, need_row(connection, 'products', record_id))
            return product_result(connection, record_id)

    @router.get("/records", response_model=HistoryResponse)
    def history(business_date: BusinessDay | None = Query(default=None)):
        day = (business_date or today()).isoformat()
        with connect(path) as connection:
            connection.execute("BEGIN")
            sales = connection.execute("SELECT * FROM sales_records WHERE business_date = ? AND deleted_at IS NULL ORDER BY id DESC", (day,)).fetchall()
            expenses = connection.execute("SELECT * FROM expenses WHERE business_date = ? AND deleted_at IS NULL ORDER BY id DESC", (day,)).fetchall()
        return HistoryResponse(business_date=day, sales=[sale_result(row) for row in sales], expenses=[ExpenseResponse(**dict(row)) for row in expenses])

    @router.post("/sales", response_model=SaleResponse, status_code=201)
    def add_sale(body: SaleInput):
        with connect(path) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            previous=replay(connection,body,'sales_records')
            if previous: return previous
            product = need_row(connection, "products", body.product_id)
            if not product["is_active"]:
                raise HTTPException(409, "该商品已停用，请先在商品管理中启用。")
            allow_sale(connection, body.business_date.isoformat())
            cursor = connection.execute("""INSERT INTO sales_records(product_id, product_name, business_date, quantity, unit_price_cents, unit_cost_cents)
                VALUES (?, ?, ?, ?, ?, ?)""", (product["id"], product["name"], body.business_date.isoformat(), body.quantity, product["price_cents"], product["unit_cost_cents"]))
            invalidate(connection, body.business_date.isoformat(), sale=True)
            audit(connection, 'sales_records', cursor.lastrowid, 'create', after=need_row(connection, 'sales_records', cursor.lastrowid))
            return remember(connection,body,'sales_records',sale_result(need_row(connection, "sales_records", cursor.lastrowid)))

    @router.put("/sales/{record_id}", response_model=SaleResponse)
    def edit_sale(body: SaleEdit, record_id: int = ApiPath(ge=1)):
        with connect(path) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            before = need_row(connection, "sales_records", record_id)
            allow_sale(connection, body.business_date.isoformat())
            connection.execute("""UPDATE sales_records SET product_name=?, business_date=?, quantity=?, unit_price_cents=?, unit_cost_cents=? WHERE id=?""", (body.product_name, body.business_date.isoformat(), body.quantity, body.unit_price_cents, body.unit_cost_cents, record_id))
            invalidate(connection, before['business_date'], sale=True)
            invalidate(connection, body.business_date.isoformat(), sale=True)
            audit(connection, 'sales_records', record_id, 'edit', before, need_row(connection, 'sales_records', record_id))
            return sale_result(need_row(connection, "sales_records", record_id))

    @router.post("/expenses", response_model=ExpenseResponse, status_code=201)
    def add_expense(body: ExpenseInput):
        with connect(path) as connection, connection:
            connection.execute('BEGIN IMMEDIATE')
            previous=replay(connection,body,'expenses')
            if previous: return previous
            cursor = connection.execute("INSERT INTO expenses(business_date, category, amount_cents) VALUES (?, ?, ?)", (body.business_date.isoformat(), body.category, body.amount_cents))
            invalidate(connection, body.business_date.isoformat())
            audit(connection, 'expenses', cursor.lastrowid, 'create', after=need_row(connection, 'expenses', cursor.lastrowid))
            return remember(connection,body,'expenses',ExpenseResponse(**dict(need_row(connection, "expenses", cursor.lastrowid))))

    @router.put("/expenses/{record_id}", response_model=ExpenseResponse)
    def edit_expense(body: ExpenseInput, record_id: int = ApiPath(ge=1)):
        with connect(path) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            before = need_row(connection, "expenses", record_id)
            connection.execute("UPDATE expenses SET business_date=?, category=?, amount_cents=? WHERE id=?", (body.business_date.isoformat(), body.category, body.amount_cents, record_id))
            invalidate(connection, before['business_date'])
            invalidate(connection, body.business_date.isoformat())
            audit(connection, 'expenses', record_id, 'edit', before, need_row(connection, 'expenses', record_id))
            return ExpenseResponse(**dict(need_row(connection, "expenses", record_id)))

    def delete(table: str, record_id: int):
        with connect(path) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            before = need_row(connection, table, record_id)
            connection.execute(f"UPDATE {table} SET deleted_at=CURRENT_TIMESTAMP WHERE id = ?", (record_id,))
            invalidate(connection, before['business_date'], sale=table == 'sales_records')
            audit(connection, table, record_id, 'delete', before)
        return Response(status_code=204)

    @router.delete("/sales/{record_id}", status_code=204)
    def delete_sale(record_id: int = ApiPath(ge=1)):
        return delete("sales_records", record_id)

    @router.delete("/expenses/{record_id}", status_code=204)
    def delete_expense(record_id: int = ApiPath(ge=1)):
        return delete("expenses", record_id)

    return router
