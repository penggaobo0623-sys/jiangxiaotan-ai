"""分析编排与严格结果校验；不展示任何未验证模型文本。"""
import json
import threading
from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field, StrictInt, StrictStr, StrictBool, ValidationError

from .records import BusinessDay
from .analysis_summary import build_summary
from .model_gateway import ModelSettings, CompatibleGateway, ModelFailure, mock_output
from .natural_text import action_prose
from .model_usage import policy, cache_key, cached, reserve, finish, save_cache, estimate


class Selection(BaseModel):
    model_config=ConfigDict(extra='forbid')
    finding_id: StrictStr
    evidence_ids: list[StrictStr]=Field(min_length=1,max_length=8)
    action_id: StrictStr
    suggestion: StrictStr | None = Field(default=None,max_length=400)
    follow_up: StrictStr | None = Field(default=None,max_length=400)


class ModelResult(BaseModel):
    model_config=ConfigDict(extra='forbid')
    schema_version: StrictInt
    items: list[Selection]=Field(min_length=1,max_length=5)


class AnalysisRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    business_date: BusinessDay
    summary_hash: str=Field(pattern=r'^[a-f0-9]{64}$')
    use_model: StrictBool=False
    consent_to_send: StrictBool=False
    goal: Literal['看清商品贡献','减少剩余和浪费','减少准备与操作负担','尝试一个新品']='看清商品贡献'
    regenerate: StrictBool=False


def validate_result(raw, summary):
    if len(raw)>16000: raise ValueError('large')
    result=ModelResult.model_validate_json(raw)
    if result.schema_version not in (1,2): raise ValueError('version')
    catalog={c['id']:c for c in summary['candidates']}
    seen=set()
    for item in result.items:
        c=catalog.get(item.finding_id)
        if c is None or item.finding_id in seen or item.evidence_ids!=c['evidence_ids'] or item.action_id!=c['action_id']:
            raise ValueError('unsupported evidence or action')
        seen.add(item.finding_id)
    selected=[]
    for i in result.items:
        c=dict(catalog[i.finding_id])
        if result.schema_version==2:
            if i.suggestion is None or i.follow_up is None: raise ValueError('missing prose')
            c['recommendation']=action_prose(i.suggestion)
            c['follow_up']=action_prose(i.follow_up,follow_up=True)
        elif i.suggestion is not None or i.follow_up is not None:
            raise ValueError('version')
        selected.append(c)
    return selected


def create_analysis_router(path, today, settings=None, gateway=None, model_lock=None):
    router=APIRouter(prefix='/api/analysis')
    lock=model_lock or threading.Lock()
    config=settings or ModelSettings.from_env()
    model=gateway or CompatibleGateway(config)

    @router.get('/preview')
    def preview(business_date: BusinessDay | None=Query(default=None)):
        summary=build_summary(path,business_date or today())
        return dict(summary=summary,usage_policy=policy(path),model_available=config.unavailable() is None,model_mode=config.mode,
                    model_label='模拟模型（非真实大模型）' if config.mode=='mock' else config.model if config.mode=='remote' else '未启用',
                    notice=config.unavailable(),disclosure='仅在主动点击并同意后发送本页七日经营摘要，包含日期、商品快照名称、销量、金额、营业核对状态、数据覆盖、所选经营目标及可选行动；不发送密钥、原始数据库文件或支出备注。服务商可能按配置计费。')

    @router.post('')
    def analyze(body: AnalysisRequest):
        summary=build_summary(path,body.business_date)
        if summary['fingerprint']!=body.summary_hash:
            raise HTTPException(409,'记录已变化，请刷新摘要后重新确认分析。')
        source,reason,selected='basic','主动选择本机基础分析。',summary['candidates']
        metadata=None
        was_cached=False
        if body.use_model:
            reason=config.unavailable()
            if not reason and not body.consent_to_send:
                raise HTTPException(422,'请先同意发送本页经营摘要；也可以选择仅基础分析。')
            if not reason and not lock.acquire(blocking=False):
                raise HTTPException(429,'已有分析正在进行，请等待完成后再试。')
            if not reason:
                reservation=None
                try:
                    payload={**summary,'merchant_goal':body.goal}
                    key=cache_key('analysis',payload,config)
                    entry=None if body.regenerate or config.mode=='mock' else cached(path,key)
                    if entry:
                        selected=validate_result(entry['raw'],summary)
                        metadata=entry.get('call')
                        was_cached=True
                    else:
                        if config.mode=='remote': reservation=reserve(path,'analysis')
                        raw=mock_output(payload) if config.mode=='mock' else model.generate(payload)
                        selected=validate_result(raw,summary)
                        if config.mode=='remote': save_cache(path,key,dict(raw=raw,call=getattr(model,'last_call',None)))
                    source='mock' if config.mode=='mock' else 'model'
                    reason='模拟服务验证格式与页面，未调用真实大模型。' if source=='mock' else '模型围绕已核实事实组织行动建议；事实、金额和局限由后端提供。自由表达自动校验有限，请结合实际判断。'
                    if was_cached: reason='复用同配置、同摘要及目标的已校验结果，未新增外部请求。'+reason
                except (ModelFailure,ValueError,ValidationError):
                    # 不返回响应原文、异常堆栈、地址或密钥。
                    import sys
                    failure=sys.exc_info()[1]
                    reason=str(failure) if isinstance(failure,ModelFailure) else '模型输出未通过数据依据校验，已改用本机基础分析。'
                finally:
                    if config.mode=='remote' and reservation is not None:
                        call=getattr(model,'last_call',None)
                        if call: metadata={**call,'validation_passed':source=='model'}
                        metadata=estimate(metadata or {'validation_passed':False,'usage':{}})
                        finish(path,reservation,metadata)
                    lock.release()
        if build_summary(path,body.business_date)['fingerprint']!=summary['fingerprint']:
            raise HTTPException(409,'分析期间记录已变化，请重新读取摘要；不要连续重复调用。')
        if metadata: metadata=estimate({**metadata,'cached':was_cached,'validation_passed':source=='model'})
        return dict(schema_version=2,source=source,cached=was_cached,goal=body.goal,usage_policy=policy(path),source_label={'basic':'本机基础分析（非大模型）','mock':'模拟模型（非真实大模型）','model':'大模型辅助分析'}[source],call=metadata,
                    model=config.model if source=='model' else None,reason=reason,generated_at=datetime.now(timezone.utc).isoformat(),summary=summary,
                    findings=[dict(**c,period=summary['period'],evidence=[summary['evidence'][ref] for ref in c['evidence_ids']]) for c in selected],
                    limitations=summary['limitations'],cannot_determine=summary['cannot_determine'])

    return router
