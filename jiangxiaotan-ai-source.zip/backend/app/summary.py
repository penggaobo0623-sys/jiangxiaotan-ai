"""只汇总已记录数据；未记账的日期返回 null，不推断为零营业额。"""
from datetime import date, timedelta
from pathlib import Path

from .database import connect
from .day_state import state_for
from .schemas import DashboardResponse, Metrics, ProductTotal, TrendPoint


def dashboard_summary(path: Path, day: date) -> DashboardResponse:
    start = day - timedelta(days=6)
    with connect(path) as connection:
        connection.execute("BEGIN")
        daily = connection.execute(
            """SELECT COUNT(*) AS count,
            COALESCE(SUM(quantity * unit_price_cents), 0) AS revenue,
            COALESCE(SUM(quantity * unit_cost_cents), 0) AS cost
            FROM sales_records WHERE deleted_at IS NULL AND business_date = ?""", (day.isoformat(),)
        ).fetchone()
        expense = connection.execute(
            "SELECT COUNT(*) AS count, COALESCE(SUM(amount_cents), 0) AS total FROM expenses WHERE deleted_at IS NULL AND business_date = ?",
            (day.isoformat(),),
        ).fetchone()
        period_expense_count = connection.execute(
            "SELECT COUNT(*) FROM expenses WHERE deleted_at IS NULL AND business_date BETWEEN ? AND ?",
            (start.isoformat(), day.isoformat()),
        ).fetchone()[0]
        rows = connection.execute(
            """SELECT business_date, SUM(quantity * unit_price_cents) AS revenue
            FROM sales_records WHERE deleted_at IS NULL AND business_date BETWEEN ? AND ? GROUP BY business_date""",
            (start.isoformat(), day.isoformat()),
        ).fetchall()
        product_rows = connection.execute(
            """SELECT * FROM sales_records WHERE deleted_at IS NULL AND business_date BETWEEN ? AND ? ORDER BY business_date, id""",
            (start.isoformat(), day.isoformat()),
        ).fetchall()
        state = state_for(connection, day.isoformat())
        zero_days = {r[0] for r in connection.execute("SELECT business_date FROM business_days WHERE status='zero' AND business_date BETWEEN ? AND ?", (start.isoformat(), day.isoformat()))}
    # 同一商品改名后仍按 ID 合并；名称来自窗口内最后一条销售快照。
    # 旧版无 product_id 的记录按快照名称合并，与有 ID 的商品区分。
    grouped = {}
    for row in product_rows:
        key = f"product:{row['product_id']}" if row["product_id"] is not None else f"legacy:{row['product_name']}"
        total = grouped.setdefault(key, dict(key=key, product_id=row["product_id"], name=row["product_name"], quantity=0, revenue_cents=0, gross_profit_cents=0))
        total["name"] = row["product_name"]
        total["quantity"] += row["quantity"]
        total["revenue_cents"] += row["quantity"] * row["unit_price_cents"]
        total["gross_profit_cents"] += row["quantity"] * (row["unit_price_cents"] - row["unit_cost_cents"])
    products = sorted(grouped.values(), key=lambda row: (-row["revenue_cents"], row["name"], row["key"]))
    has_sales = daily["count"] > 0 or state["status"] == "zero"
    has_cost = has_sales or expense["count"] > 0
    cost = daily["cost"] + expense["total"]
    by_date = {row["business_date"]: row["revenue"] for row in rows}
    actual_sales_dates = set(by_date)
    by_date.update({key: 0 for key in zero_days if key not in by_date})
    trend = []
    for offset in range(7):
        key = (start + timedelta(days=offset)).isoformat()
        trend.append(TrendPoint(date=key, revenue_cents=by_date.get(key), has_sales_records=key in actual_sales_dates))
    return DashboardResponse(
        business_date=day.isoformat(), business_status=state, has_data=bool(rows or period_expense_count or zero_days),
        metrics=Metrics(
            gross_profit_cents=daily["revenue"] - daily["cost"] if has_sales else None,
            extra_expense_cents=expense["total"] if expense["count"] else None,
            revenue_cents=daily["revenue"] if has_sales else None,
            recorded_cost_cents=cost if has_cost else None,
            estimated_profit_cents=daily["revenue"] - cost if has_sales else None,
            sales_record_count=daily["count"], expense_record_count=expense["count"],
        ),
        trend=trend, product_ranking=[ProductTotal(**dict(row)) for row in products],
        notices=[
            "最近七天没有销售记录，暂时无法分析营业趋势和商品表现。" if not rows else "统计仅覆盖已记录数据；未记录日期不代表停业或零销售。",
            "估算结余 = 销售额 − 商品记录成本 − 额外记录支出；未记录的房租、人工、水电等费用不包含在内。",
            "当前未采集订单数据，因此不展示订单数；销售记录条数不等于订单数。",
        ],
    )

