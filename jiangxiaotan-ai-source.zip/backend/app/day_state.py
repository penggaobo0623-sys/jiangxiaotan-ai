"""营业状态不是完整性证明；写入记录后保守撤销旧核对。"""
from fastapi import HTTPException

LABELS = {'unrecorded': '尚未记录', 'rest': '今日休息', 'pending': '今日营业，记录待核对', 'checked': '今日营业，记录已核对', 'zero': '今日营业，确认没有销售'}


def state_for(con, day):
    row = con.execute('SELECT * FROM business_days WHERE business_date=?', (day,)).fetchone()
    sales = con.execute('SELECT COUNT(*) FROM sales_records WHERE business_date=? AND deleted_at IS NULL', (day,)).fetchone()[0]
    status = row['status'] if row else ('pending' if sales else 'unrecorded')
    return dict(business_date=day, status=status, label=LABELS[status], updated_at=row['updated_at'] if row else None,
                notice='核对状态由商家确认，不代表系统证明账目完整；仅有支出不推断销售。')


def allow_sale(con, day):
    if state_for(con, day)['status'] == 'rest':
        raise HTTPException(409, '这天已标记休息，请先改为营业待核对，再录入销售。')


def invalidate(con, day, sale=False):
    state = state_for(con, day)['status']
    status = 'pending' if sale or state in ('checked', 'zero') else state
    con.execute('INSERT INTO business_days(business_date,status) VALUES (?,?) ON CONFLICT(business_date) DO UPDATE SET status=excluded.status,updated_at=CURRENT_TIMESTAMP', (day, status))


def audit(con, kind, record_id, action, before=None, after=None):
    import json
    encode = lambda value: json.dumps(dict(value), ensure_ascii=False) if value is not None else None
    con.execute('INSERT INTO record_audit(kind,record_id,action,before_json,after_json) VALUES (?,?,?,?,?)',
                (kind, record_id, action, encode(before), encode(after)))
