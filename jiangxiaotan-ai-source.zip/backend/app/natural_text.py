"""有限自动校验：只允许行动/邀请表达；事实仍由后端展示，不能证明全部语义真实。"""
import re


UNSUPPORTED = ('客流','天气','市场调研','净利润','订单数','必赚','保证','一定会','提升了','增长了','导致','由于','稳赚','全校第一','全网','冠军','获奖','认证','治愈','治疗','减肥','养生','回头客','排队','热销','爆款','限量','免费','赠送','买一送','好评','卖光','大家都','每个人都','口碑','必吃','闭眼冲')


def safe_prose(text, limit=400, allowed=''):
    if not isinstance(text, str) or not text.strip() or len(text)>limit or any(ord(c)<32 and c!='\n' for c in text):
        raise ValueError('invalid prose')
    if any(word in text and word not in allowed for word in UNSUPPORTED) or '<' in text or '>' in text or 'http' in text.lower():
        raise ValueError('unsupported assertion')
    # 数字只有在完整的已核实片段中才允许，不能拿其中的数字重新组织其他事实。
    remainder = text
    for fragment in sorted([f for f in allowed.split('\n') if f], key=len, reverse=True):
        remainder = remainder.replace(fragment, '')
    if re.search(r'[0-9０-９¥￥%％]', remainder):
        raise ValueError('unverified number')
    return text.strip()


def action_prose(text, follow_up=False):
    text = safe_prose(text)
    if re.search(r'[零一二三四五六七八九十百千万两]+(?:元|份|成|倍|天|次|箱|袋|杯|串|小时|分钟|公斤|斤|克|%)', text):
        raise ValueError('unverified verbal number')
    if follow_up:
        if not text.startswith(('下次', '复盘时', '可以观察', '请观察')):
            raise ValueError('follow-up must be observational')
    elif not text.startswith(('建议', '可以', '请先', '不妨', '如果')):
        raise ValueError('must be optional action')
    if any(t in text for t in ('说明了','证明','消费者喜欢','顾客喜欢','生意差','偷懒','必须','应该立刻')):
        raise ValueError('unsupported interpretation')
    return text
