"""文案只组装商家已确认的事实，模型只选择表达结构。"""
from datetime import date
import hashlib
import json
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import Field, StrictBool, StrictInt, StrictStr, BaseModel, ConfigDict

from .database import connect
from .records import InputModel, BusinessDay, need_row, MAX_CENTS
from .analysis_summary import yuan
from .model_gateway import ModelFailure
from .natural_text import safe_prose
from .model_usage import policy, cache_key, cached, reserve, finish, save_cache, estimate


class MarketingInput(InputModel):
    product_id: StrictInt=Field(ge=1)
    expected_price_cents: StrictInt=Field(ge=0,le=MAX_CENTS)
    price_confirmed: StrictBool=False
    feature: StrictStr=Field(default='',max_length=60)
    feature_confirmed: StrictBool=False
    theme: StrictStr=Field(default='校园日常',min_length=1,max_length=40)
    channel: Literal['朋友圈','摊位海报','小红书']='朋友圈'
    style: Literal['校园日常','商品介绍','收摊随记']='校园日常'
    offer_kind: Literal['none','special_price']='none'
    offer_price_cents: StrictInt | None=Field(default=None,ge=1,le=MAX_CENTS)
    start_date: BusinessDay | None=None
    end_date: BusinessDay | None=None
    offer_confirmed: StrictBool=False


class MarketingRequest(MarketingInput):
    facts_hash: StrictStr=Field(pattern=r'^[a-f0-9]{64}$')
    use_model: StrictBool=False
    consent_to_send: StrictBool=False
    regenerate: StrictBool=False


class CopySelection(BaseModel):
    model_config=ConfigDict(extra='forbid')
    schema_version: StrictInt
    style_id: Literal['warm','plain']
    headline_id: Literal['invitation','simple']


class NaturalCopy(BaseModel):
    model_config=ConfigDict(extra='forbid')
    schema_version: StrictInt
    headline: StrictStr=Field(min_length=1,max_length=30)
    body: StrictStr=Field(min_length=1,max_length=200)


def validate_copy(raw, facts):
    if len(raw)>16000: raise ValueError()
    data=json.loads(raw)
    if not isinstance(data,dict): raise ValueError('object required')
    if data.get('schema_version')==1:
        result=CopySelection.model_validate(data)
        return assemble(facts,result.style_id,result.headline_id)
    result=NaturalCopy.model_validate(data)
    if result.schema_version!=2: raise ValueError()
    title=safe_prose(result.headline,30)
    text=safe_prose(result.body,200)
    if not text.startswith(('如果','想','可以','欢迎')): raise ValueError('invitation only')
    # 事实行另由后端渲染；自由段不得自行添加口味、供应、经历或价格。
    forbidden=('酥','脆','香甜','鲜','现做','现点','手工','低糖','无糖','有机','健康','开摊','出摊','今天在','营业到','我们已经','我已经','我曾','同学说','顾客说','辛苦','坚持了','原价','售价','活动价','折扣','优惠','限时','最低','便宜','热乎','热腾','微辣','麻辣','校园门口','食堂旁','宿舍楼','小时','分钟','元','块钱')
    if any(word in title+text for word in forbidden): raise ValueError('unconfirmed fact')
    if any(c.isdigit() for c in title+text): raise ValueError('numeric facts belong in confirmed lines')
    if facts['channel']=='摊位海报' and len(text)>80: raise ValueError('poster too long')
    return compose_facts(facts,title,text)


def facts_for(path,body):
    if not body.price_confirmed: raise HTTPException(422,'请先核对并确认当前商品售价。')
    with connect(path) as con: product=dict(need_row(con,'products',body.product_id))
    if not product['is_active']: raise HTTPException(409,'商品已停用，不能生成推广文案。')
    if product['price_cents']!=body.expected_price_cents: raise HTTPException(409,'商品价格已变化，请刷新商品并重新确认。')
    feature=body.feature.strip()
    # 特色只描述已确认的非数值属性；价格/优惠必须走专门的结构化字段。
    banned=('折','优惠','免费','赠','买一','限量','第一','最好','销量','热销','爆款','冠军','获奖','认证','治','疗','养生','减肥','口碑','全网','全校','原价','售价','元','零添加','无糖','忽略指令','system','http')
    if feature and (not body.feature_confirmed or any(word in feature for word in banned) or any(c in feature for c in '¥￥%％<>')):
        raise HTTPException(422,'特色须由商家确认；只描述可核实的口味或制作方式，不填价格优惠、排名、销量或功效承诺。')
    safe_prose_theme=body.theme
    if any(word in safe_prose_theme for word in ('免费','折扣','买一','限量','第一','热销','优惠','获奖','治','销量')) or any(c in safe_prose_theme for c in '<>¥￥%％'):
        raise HTTPException(422,'主题只描述宣传场景；优惠和活动事实请使用专门字段确认。')
    offer=None
    if body.offer_kind=='special_price':
        if not body.offer_confirmed or body.offer_price_cents is None or body.start_date is None or body.end_date is None:
            raise HTTPException(422,'活动价必须同时填写价格、起止日期并确认优惠真实有效。')
        if body.offer_price_cents>=product['price_cents']: raise HTTPException(422,'活动价须低于当前售价；请核对价格。')
        if body.start_date>body.end_date: raise HTTPException(422,'活动结束日期不能早于开始日期。')
        offer=dict(price_cents=body.offer_price_cents,start=body.start_date.isoformat(),end=body.end_date.isoformat())
    elif body.offer_price_cents is not None or body.start_date is not None or body.end_date is not None or body.offer_confirmed:
        raise HTTPException(422,'未选择活动价时请清空优惠价格、日期及确认选项。')
    facts=dict(product_id=product['id'],product_name=product['name'],price_cents=product['price_cents'],feature=feature,theme=body.theme,channel=body.channel,style=body.style,offer=offer)
    facts['fingerprint']=hashlib.sha256(json.dumps(facts,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    return facts


def assemble(facts,style,headline):
    tones={'校园日常':('课间，想吃点什么？','如果正在考虑加餐，可以看看这款。'), '商品介绍':('这款小吃，想介绍给你','想了解怎么选，可以先看看商品信息。'), '收摊随记':('把小摊的一款商品介绍给你','如果想了解这份小生意，欢迎从这款商品开始。')}
    title,text=tones.get(facts.get('style'),tones['校园日常'])
    if facts['channel']=='摊位海报': title,text='看看这款小吃','欢迎了解，按自己的喜好选择。'
    return compose_facts(facts,title,text)


def compose_facts(facts,title,text):
    lines=[title, text, f"{facts['product_name']} · {yuan(facts['price_cents'])}"]
    if facts['feature']: lines.append(facts['feature'])
    if facts['offer']:
        o=facts['offer']; lines.append(f"活动日期：{o['start']} 至 {o['end']}（北京时间）。活动价：{yuan(o['price_cents'])}。")
    lines.append('购买前欢迎向摊主确认供应情况。')
    return ('\n\n' if facts['channel'] in ('摊位海报','小红书') else '\n').join(lines)


def create_marketing_router(path,settings,gateway,lock):
    router=APIRouter(prefix='/api/marketing')

    @router.get('/config')
    def config():
        return dict(usage_policy=policy(path),model_available=settings.unavailable() is None,model_mode=settings.mode,model_label='模拟模型（非真实大模型）' if settings.mode=='mock' else settings.model or '未启用',notice=settings.unavailable())

    @router.post('/preview')
    def preview(body:MarketingInput):
        return dict(facts=facts_for(path,body),disclosure='仅在你同意并主动生成后，发送本页确认的商品名称、售价、特色、主题、表达风格、场景和优惠日期；不发送单位成本、销量、经营利润或密钥。文案仅为待审核草稿，不自动发布。')

    @router.post('')
    def generate(body:MarketingRequest):
        facts=facts_for(path,body)
        if facts['fingerprint']!=body.facts_hash: raise HTTPException(409,'确认内容已变化，请重新预览。')
        source,reason,style,headline='template','主动选择本机模板文案。','plain','simple'
        metadata=None
        was_cached=False
        draft=assemble(facts,style,headline)
        if body.use_model:
            reason=settings.unavailable()
            if reason: reason=reason.replace('本机基础分析','本机模板文案')
            if not reason and not body.consent_to_send: raise HTTPException(422,'请先同意发送确认的商品信息，或选择本机模板。')
            if not reason and not lock.acquire(blocking=False): raise HTTPException(429,'已有生成或分析进行中，请等待完成。')
            if not reason:
                reservation=None
                try:
                    key=cache_key('marketing',facts,settings)
                    entry=None if body.regenerate or settings.mode=='mock' else cached(path,key)
                    if entry:
                        draft=validate_copy(entry['raw'],facts); metadata=entry.get('call'); was_cached=True
                    else:
                        if settings.mode=='remote': reservation=reserve(path,'marketing')
                        raw=json.dumps(dict(schema_version=2,headline='课间想吃点什么？' if body.style=='校园日常' else '给你介绍这款小吃',body='如果想换个加餐选择，可以先了解这款，再按自己的喜好决定。'),ensure_ascii=False) if settings.mode=='mock' else gateway.generate_marketing(facts)
                        draft=validate_copy(raw,facts)
                        if settings.mode=='remote': save_cache(path,key,dict(raw=raw,call=getattr(gateway,'last_call',None)))
                    source='mock' if settings.mode=='mock' else 'model'
                    reason='模拟模型验证展示，未调用真实模型。' if source=='mock' else '模型编写邀请和场景表达；商品事实由后端按确认内容呈现。自动语义检查有限，请审核后使用。'
                    if was_cached: reason='复用已校验草稿，未新增外部请求。'+reason
                except (ModelFailure,ValueError) as failure:
                    reason=str(failure).replace('基础分析','模板文案') if isinstance(failure,ModelFailure) else '模型输出未通过校验，已回退本机模板文案。'
                finally:
                    if settings.mode=='remote' and reservation is not None:
                        call=getattr(gateway,'last_call',None)
                        if call: metadata={**call,'validation_passed':source=='model'}
                        metadata=estimate(metadata or {'validation_passed':False,'usage':{}})
                        finish(path,reservation,metadata)
                    lock.release()
        if facts_for(path,body)['fingerprint']!=facts['fingerprint']: raise HTTPException(409,'生成期间商品已变化，请重新确认后生成。')
        if metadata: metadata=estimate({**metadata,'cached':was_cached,'validation_passed':source=='model'})
        return dict(source=source,cached=was_cached,usage_policy=policy(path),source_label={'template':'本机模板（非AI生成）','mock':'模拟模型（非真实大模型）','model':'大模型辅助文案'}[source],reason=reason,facts=facts,
                    draft=draft,call=metadata,review_notice='待审核草稿：请核对价格、特色、活动有效期及实际供应；没有自动发布。自行编辑后不再属于后端已校验版本。')
    return router
