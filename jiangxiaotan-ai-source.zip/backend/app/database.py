"""第一版数据库结构；金额以整数分保存，避免浮点金额误差。"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 60),
    price_cents INTEGER NOT NULL CHECK(price_cents >= 0),
    unit_cost_cents INTEGER NOT NULL CHECK(unit_cost_cents >= 0),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sales_records (
    id INTEGER PRIMARY KEY,
    product_id INTEGER REFERENCES products(id) ON DELETE RESTRICT,
    product_name TEXT NOT NULL CHECK(length(trim(product_name)) BETWEEN 1 AND 60),
    business_date TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents >= 0),
    unit_cost_cents INTEGER NOT NULL CHECK(unit_cost_cents >= 0),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY,
    business_date TEXT NOT NULL,
    category TEXT NOT NULL CHECK(length(trim(category)) BETWEEN 1 AND 60),
    amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales_records(business_date);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(business_date);
"""


@contextmanager
def connect(path: Path):
    connection = sqlite3.connect(path, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
    finally:
        connection.close()


def initialize(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as connection:
        version = connection.execute("PRAGMA user_version").fetchone()[0]
        if version > 3:
            raise RuntimeError("数据库版本高于当前程序版本，请使用匹配的程序。")
        # DDL 与版本号在同一事务迁移，失败回滚，不删除或重建已有表。
        connection.execute("BEGIN IMMEDIATE")
        try:
            for statement in SCHEMA.split(";"):
                if statement.strip():
                    connection.execute(statement)
            if version < 2:
                columns = {row["name"] for row in connection.execute("PRAGMA table_info(products)")}
                if "is_active" not in columns:
                    connection.execute("ALTER TABLE products ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0, 1))")
                connection.execute("PRAGMA user_version = 2")
            if version < 3:
                for table in ('sales_records', 'expenses'):
                    columns = {row['name'] for row in connection.execute(f'PRAGMA table_info({table})')}
                    if 'deleted_at' not in columns:
                        connection.execute(f'ALTER TABLE {table} ADD COLUMN deleted_at TEXT')
                statements = [
                    "CREATE TABLE business_days (business_date TEXT PRIMARY KEY, status TEXT NOT NULL CHECK(status IN ('unrecorded','rest','pending','checked','zero')), updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
                    "CREATE TABLE record_audit (id INTEGER PRIMARY KEY, kind TEXT NOT NULL, record_id INTEGER NOT NULL, action TEXT NOT NULL, before_json TEXT, after_json TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
                    "CREATE TABLE submissions (request_id TEXT PRIMARY KEY, payload_hash TEXT NOT NULL, result_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
                    "CREATE TABLE model_calls (id INTEGER PRIMARY KEY, business_date TEXT NOT NULL, kind TEXT NOT NULL, metadata_json TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
                    "CREATE TABLE model_cache (cache_key TEXT PRIMARY KEY, result_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
                ]
                for statement in statements:
                    connection.execute(statement)
                connection.execute('PRAGMA user_version = 3')
            connection.commit()
        except Exception:
            connection.rollback()
            raise

