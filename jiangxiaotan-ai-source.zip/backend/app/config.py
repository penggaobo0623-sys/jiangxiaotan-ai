"""只在后端读取环境变量，数据库相对路径以项目根目录为基准。"""
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]
load_dotenv(ROOT / ".env", override=False)


def database_path() -> Path:
    path = Path(os.getenv("DATABASE_PATH", "backend/data/jiangxiaotan.db"))
    return path if path.is_absolute() else ROOT / path


def cors_origins() -> list[str]:
    value = os.getenv("CORS_ORIGINS", "http://127.0.0.1:5173,http://localhost:5173")
    return [origin.strip() for origin in value.split(",") if origin.strip()]

