"""本机持久化次数上限与结果缓存；不把次数限制称为金额预算。"""
import hashlib
import json
import os
from datetime import datetime, timedelta, timezone

from .database import connect
from .model_gateway import ModelFailure


def estimate(metadata):
    """仅使用用户配置的每百万 token 价格；不内置可能过期的厂商报价。"""
    from decimal import Decimal, InvalidOperation
    result={**(metadata or {}), 'estimated_cost_yuan': None,
            'cost_notice': '未配置价格或未取得完整用量，无法估算；费用以服务商账单为准。'}
    usage=result.get('usage') or {}
    try:
        ip=Decimal(os.getenv('AI_INPUT_YUAN_PER_MILLION',''))
        op=Decimal(os.getenv('AI_OUTPUT_YUAN_PER_MILLION',''))
        if not ip.is_finite() or not op.is_finite() or ip<0 or op<0: return result
        if type(usage.get('prompt_tokens')) is not int or type(usage.get('completion_tokens')) is not int: return result
        result['estimated_cost_yuan']=str((ip*usage['prompt_tokens']+op*usage['completion_tokens'])/Decimal(1000000))
        result['cost_notice']='按本机配置的每百万token输入/输出价格估算；缓存折扣、时段和实际扣费以账单为准，不是金额预算。'
    except (InvalidOperation,ValueError): pass
    return result


def policy(path):
    try: limit = min(1000, max(0, int(os.getenv('AI_DAILY_CALL_LIMIT', '20'))))
    except ValueError: limit = 20
    day = datetime.now(timezone(timedelta(hours=8))).date().isoformat()
    with connect(path) as con:
        count = con.execute('SELECT COUNT(*) FROM model_calls WHERE business_date=?', (day,)).fetchone()[0]
        recent = [dict(r) for r in con.execute('SELECT id,kind,created_at,metadata_json FROM model_calls ORDER BY id DESC LIMIT 10')]
    return dict(date=day, used=count, limit=limit, remaining=max(0, limit-count), recent=recent,
                notice='本机账本按北京时间限制真实请求次数（含失败和中断），不是金额预算；用量与费用以服务商账单为准。')


def cache_key(kind, payload, settings):
    value = [kind, payload, settings.provider, settings.base_url, settings.model, settings.max_output_tokens, 'natural-v2']
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def cached(path, key):
    with connect(path) as con:
        row = con.execute("SELECT result_json FROM model_cache WHERE cache_key=? AND created_at >= datetime('now','-1 day')", (key,)).fetchone()
    return json.loads(row[0]) if row else None


def reserve(path, kind):
    config = policy(path)
    with connect(path) as con, con:
        con.execute('BEGIN IMMEDIATE')
        count = con.execute('SELECT COUNT(*) FROM model_calls WHERE business_date=?', (config['date'],)).fetchone()[0]
        if count >= config['limit']:
            raise ModelFailure('今日真实请求次数已达本机上限，已提供本机结果；未发送外部请求。')
        return con.execute('INSERT INTO model_calls(business_date,kind) VALUES (?,?)', (config['date'], kind)).lastrowid


def finish(path, reservation, metadata):
    with connect(path) as con, con:
        con.execute('UPDATE model_calls SET metadata_json=? WHERE id=?', (json.dumps(metadata, ensure_ascii=False), reservation))


def save_cache(path, key, result):
    with connect(path) as con, con:
        con.execute('INSERT INTO model_cache(cache_key,result_json) VALUES (?,?) ON CONFLICT(cache_key) DO UPDATE SET result_json=excluded.result_json,created_at=CURRENT_TIMESTAMP', (key, json.dumps(result, ensure_ascii=False)))
