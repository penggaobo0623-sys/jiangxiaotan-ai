"""可信七日摘要与可引用事实；所有运算在后端，以整数分完成。"""
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path

from .database import connect
from .day_state import state_for

LIMITS = [
    "未记录日期不等于零销售或停业；有记录也不保证当天已经记全。",
    "估算结余仅扣除商品快照成本和已录入额外支出，不是实际净利润。",
    "未采集订单、客流、天气、市场调研、库存或损耗，不能判断这些因素或推断因果。",
    "一周记录不足以预测未来销量；建议是待验证行动，不承诺经营成效。",
]


def yuan(cents):
    sign = "-" if cents < 0 else ""
    whole, part = divmod(abs(cents), 100)
    return f"{sign}{whole}.{part:02d} 元"


def build_summary(path: Path, end: date):
    start = end - timedelta(days=6)
    days = [(start + timedelta(days=i)).isoformat() for i in range(7)]
    with connect(path) as con:
        con.execute("BEGIN")
        sales = con.execute("SELECT * FROM sales_records WHERE deleted_at IS NULL AND business_date BETWEEN ? AND ? ORDER BY business_date, id", (days[0], days[-1])).fetchall()
        expenses = con.execute("SELECT * FROM expenses WHERE deleted_at IS NULL AND business_date BETWEEN ? AND ? ORDER BY business_date, id", (days[0], days[-1])).fetchall()
        states = [state_for(con, d) for d in days]
    grouped, daily, expense_days = {}, {}, {}
    for row in sales:
        key = f"product:{row['product_id']}" if row['product_id'] is not None else f"legacy:{row['product_name']}"
        p = grouped.setdefault(key, dict(key=key, name=row['product_name'], quantity=0, revenue_cents=0, cost_cents=0, gross_profit_cents=0))
        p['name'] = row['product_name']
        revenue, cost = row['quantity'] * row['unit_price_cents'], row['quantity'] * row['unit_cost_cents']
        p['quantity'] += row['quantity']; p['revenue_cents'] += revenue; p['cost_cents'] += cost; p['gross_profit_cents'] += revenue - cost
        daily[row['business_date']] = daily.get(row['business_date'], 0) + revenue
    for row in expenses:
        expense_days[row['business_date']] = expense_days.get(row['business_date'], 0) + row['amount_cents']
    products = sorted(grouped.values(), key=lambda p: (-p['revenue_cents'], p['key']))
    revenue = sum(p['revenue_cents'] for p in products) if sales else None
    cost = sum(p['cost_cents'] for p in products) if sales else None
    extra = sum(r['amount_cents'] for r in expenses)
    zero_dates = {s['business_date'] for s in states if s['status']=='zero'}
    unknown_dates = [s['business_date'] for s in states if s['business_date'] not in daily and s['status'] not in ('zero','rest')]
    known_daily = {**{d: 0 for d in zero_dates}, **daily}
    known = bool(sales or zero_dates)
    if known and not sales: revenue, cost = 0, 0
    summary = dict(period=dict(start=days[0], end=days[-1], days=7), currency='CNY', timezone='Asia/Shanghai',
        business_days=states,
        coverage=dict(sales_days=len(daily), expense_days=len(expense_days), missing_sales_dates=[d for d in days if d not in known_daily],
                      unknown_dates=unknown_dates, zero_days=len(zero_dates), rest_days=sum(s['status']=='rest' for s in states), checked_days=sum(s['status']=='checked' for s in states)),
        totals=dict(quantity=sum(p['quantity'] for p in products) if known else None, revenue_cents=revenue, product_cost_cents=cost,
                    gross_profit_cents=revenue-cost if known else None, extra_expense_cents=extra if expenses else None,
                    estimated_profit_cents=revenue-cost-extra if known else None, order_count=None),
        daily=[dict(date=d, revenue_cents=known_daily.get(d), expense_cents=expense_days.get(d)) for d in days],
        products=products[:20], product_count=len(products), omitted_product_count=max(0,len(products)-20), limitations=LIMITS)
    evidence, candidates = {}, []

    def fact(key, label, value, display, limitation, period=None):
        evidence[key] = dict(id=key, label=label, value=value, display=display, period=period or summary['period'], limitation=limitation)
        return key

    def finding(key, title, observation, refs, action, advice, limitation):
        candidates.append(dict(id=key, title=title, observation=observation, evidence_ids=refs, action_id=action, recommendation=advice, limitation=limitation))

    coverage = fact('coverage', '有销售记录的日期', len(daily), f"{len(daily)} / 7 天", LIMITS[0])
    fact('business_state', '商家标记的营业状态', summary['coverage'], f"确认零销售 {len(zero_dates)} 天；休息 {summary['coverage']['rest_days']} 天；商家已核对 {summary['coverage']['checked_days']} 天", '这些状态由商家声明，不证明完整性；休息日仍可有支出。')
    finding('coverage', '按实际营业情况核对记录', f"选定七天中，有销售记录的日期为 {len(daily)} 天；确认零销售 {len(zero_dates)} 天，休息 {summary['coverage']['rest_days']} 天。", [coverage,'business_state'], 'complete_records',
            '核对缺失日期与漏记支出，按实际发生情况补录；不要用零销售填补未知日期。', LIMITS[0])
    fact('expenses', '已录入额外支出合计', extra if expenses else None, yuan(extra) if expenses else '未录入支出', '没有支出记录不代表没有支出；商品成本不重复记入额外支出。')
    if sales:
        fact('revenue', '已记录销售额合计', revenue, yuan(revenue), '仅为已记录销售的合计，不保证覆盖整周全部营业。')
        fact('gross', '已记录商品估算毛利', revenue-cost, yuan(revenue-cost), '按每条销售的历史售价和成本快照计算，未扣额外支出。')
        fact('profit', '已记录估算结余', revenue-cost-extra, yuan(revenue-cost-extra), LIMITS[1])
        finding('totals', '已记录经营结果', f"已记录销售额 {yuan(revenue)}，商品估算毛利 {yuan(revenue-cost)}，估算结余 {yuan(revenue-cost-extra)}。", ['revenue','gross','profit','expenses'],
                'review_costs', '核对单位成本和额外支出是否齐全；优先更正遗漏，再评估经营结果。', LIMITS[1])
        for i, p in enumerate(products[:20]):
            fact(f'p{i}', f"{p['name']} · 销量/销售额/估算毛利", dict(quantity=p['quantity'], revenue_cents=p['revenue_cents'], gross_profit_cents=p['gross_profit_cents']),
                 f"销量 {p['quantity']}；销售额 {yuan(p['revenue_cents'])}；估算毛利 {yuan(p['gross_profit_cents'])}", '仅汇总该商品在选定窗口内已记录的销售快照，不能推断库存、需求或订单数。')
        p=products[0]
        finding('leader', '已记录销售额最高的商品', f"按已记录销售额排序，首位为「{p['name']}」，销售额 {yuan(p['revenue_cents'])}，估算毛利 {yuan(p['gross_profit_cents'])}。", ['p0','coverage'],
                'observe_leader', '单独跟踪这款商品的后续销量和成本，观察表现是否持续；记录不足时先不要据此大幅增加备货。', LIMITS[3])
        negative=sorted([i for i,p in enumerate(products) if p['gross_profit_cents'] < 0], key=lambda i: products[i]['gross_profit_cents'])
        if negative:
            i=negative[0]; p=products[i]
            if f'p{i}' not in evidence:
                fact(f'p{i}', f"{p['name']} · 估算毛利", p['gross_profit_cents'], yuan(p['gross_profit_cents']), '全商品检查后选取估算毛利最低的商品；不能推断原因。')
            finding('negative_margin', '存在估算毛利为负的商品', f"「{p['name']}」在窗口内商品估算毛利为 {yuan(p['gross_profit_cents'])}。", [f'p{i}'],
                    'check_margin', '核对该商品的售价与单位成本快照是否录错；确认无误后再评估配方、采购或定价，先做小范围验证。', '负毛利不说明客流或需求原因，不能承诺调价效果。')
    if expenses:
        finding('expenses', '核对额外支出', f"该窗口已录入额外支出合计 {yuan(extra)}。", ['expenses','coverage'], 'audit_expenses',
                '按原始凭据核对额外支出，避免漏记或与商品单位成本重复记账。', '仅有支出时不能推断营业额或利润，也不能推断支出高低是否合理。')
    if len(daily)==7 and all(s['status']=='checked' for s in states):
        first, last=daily[days[0]],daily[days[-1]]
        delta=last-first
        fact('day_comparison','首尾已记录销售额差',delta,f"{days[-1]} 比 {days[0]} {'增加' if delta>=0 else '减少'} {yuan(abs(delta))}", '只是两个日期已记录销售额的比较，不代表趋势或因果，也不保证每日记录完整。')
        finding('comparison','首尾两日记录对比',evidence['day_comparison']['display'],['day_comparison','coverage'],'keep_tracking',
                '继续记录并核对各天是否记全，再观察多周表现；暂不归因于天气、客流或活动。', evidence['day_comparison']['limitation'])
    summary['cannot_determine'] = ['订单数、客流、天气影响、市场偏好、真实净利润、未来销量与建议效果。']
    if unknown_dates: summary['cannot_determine'].append('未知日期的营业额、完整周营业额及连续七日变化。')
    if not known: summary['cannot_determine'].append('营业额、商品表现、估算毛利和估算结余；仅有支出也不能推算。')
    elif not sales: summary['cannot_determine'].append('没有商品销售明细，无法比较商品表现；零销售来自商家明确声明。')
    if summary['omitted_product_count']: summary['cannot_determine'].append('模型仅接收销售额前 20 款商品明细和全商品扫描出的最低负毛利项，不能逐项分析所有其余商品。')
    summary['limitations'] = list(LIMITS) + ['营业状态和核对状态由商家确认，不证明完整性；休息不是经营失败，销量不等于需求。']
    for candidate in candidates:
        candidate['follow_up'] = '下次核对相同口径的记录，看看信息是否更完整；不把前后变化直接归因于建议。'
    summary['evidence']=evidence
    summary['candidates']=candidates
    summary['fingerprint']=hashlib.sha256(json.dumps(summary,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    return summary
