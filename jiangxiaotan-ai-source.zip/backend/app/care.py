"""收摊事务、请求幂等、回收区和本机数据导出。"""
import hashlib
import json
import sqlite3
from typing import Literal

from fastapi import APIRouter, HTTPException, Query, Response
from pydantic import Field, StrictInt, StrictStr, model_validator

from .database import connect
from .records import InputModel, BusinessDay, Cents, PositiveId, ExpenseInput, need_row
from .day_state import state_for, allow_sale, invalidate, audit, LABELS


class DayInput(InputModel):
    status: Literal['unrecorded', 'rest', 'pending', 'checked', 'zero']


class ClosingSale(InputModel):
    product_id: PositiveId
    quantity: StrictInt = Field(ge=0, le=100000)
    expected_price_cents: Cents
    expected_cost_cents: Cents


class ClosingInput(InputModel):
    request_id: StrictStr = Field(pattern=r'^[a-zA-Z0-9_-]{16,80}$')
    business_date: BusinessDay
    sales: list[ClosingSale] = Field(default_factory=list, max_length=200)
    expenses: list[ExpenseInput] = Field(default_factory=list, max_length=50)

    @model_validator(mode='after')
    def check(self):
        if len({s.product_id for s in self.sales}) != len(self.sales):
            raise ValueError('同一商品在收摊表中只能填写一次')
        if not self.sales and not self.expenses:
            raise ValueError('请填写销量或支出；零销售请使用营业状态确认')
        if any(e.business_date != self.business_date for e in self.expenses):
            raise ValueError('收摊支出必须属于选定日期')
        return self


def create_care_router(path, today):
    router = APIRouter(prefix='/api')

    @router.get('/business-days/{day}')
    def get_day(day: BusinessDay):
        with connect(path) as con:
            return state_for(con, day.isoformat())

    @router.put('/business-days/{day}')
    def put_day(day: BusinessDay, body: DayInput):
        key = day.isoformat()
        with connect(path) as con, con:
            con.execute('BEGIN IMMEDIATE')
            count = con.execute('SELECT COUNT(*) FROM sales_records WHERE business_date=? AND deleted_at IS NULL', (key,)).fetchone()[0]
            if count and body.status in ('zero', 'rest', 'unrecorded'):
                raise HTTPException(409, '这天已有销售记录，请先核对记录；不能直接标记无销售、休息或尚未记录。')
            if not count and body.status == 'checked':
                raise HTTPException(422, '没有销售记录时，请明确选择确认没有销售，或保留待核对。')
            before = state_for(con, key)
            con.execute('INSERT INTO business_days(business_date,status) VALUES (?,?) ON CONFLICT(business_date) DO UPDATE SET status=excluded.status,updated_at=CURRENT_TIMESTAMP', (key, body.status))
            audit(con, 'business_day', 0, 'status', before, state_for(con, key))
            return state_for(con, key)

    @router.post('/closing')
    def closing(body: ClosingInput):
        payload = body.model_dump(mode='json', exclude={'request_id'})
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        day = body.business_date.isoformat()
        with connect(path) as con, con:
            con.execute('BEGIN IMMEDIATE')
            previous = con.execute('SELECT * FROM submissions WHERE request_id=?', (body.request_id,)).fetchone()
            if previous:
                if previous['payload_hash'] != digest:
                    raise HTTPException(409, '该提交编号对应其他内容，请先核对历史。')
                return {**json.loads(previous['result_json']), 'replayed': True}
            ids, expenses = [], []
            for item in body.sales:
                p = need_row(con, 'products', item.product_id)
                if not p['is_active'] or (p['price_cents'], p['unit_cost_cents']) != (item.expected_price_cents, item.expected_cost_cents):
                    raise HTTPException(409, '商品资料已变化或停用，请重新读取并核对；本次没有保存任何记录。')
                if item.quantity == 0:
                    continue  # 明确的零数量仅保留于提交凭据，不伪造销售行。
                allow_sale(con, day)
                cur = con.execute('INSERT INTO sales_records(product_id,product_name,business_date,quantity,unit_price_cents,unit_cost_cents) VALUES (?,?,?,?,?,?)',
                                  (p['id'], p['name'], day, item.quantity, p['price_cents'], p['unit_cost_cents']))
                ids.append(cur.lastrowid)
                audit(con, 'sales_records', cur.lastrowid, 'create', after=need_row(con, 'sales_records', cur.lastrowid))
            for e in body.expenses:
                cur = con.execute('INSERT INTO expenses(business_date,category,amount_cents) VALUES (?,?,?)', (day, e.category, e.amount_cents))
                expenses.append(cur.lastrowid)
                audit(con, 'expenses', cur.lastrowid, 'create', after=need_row(con, 'expenses', cur.lastrowid))
            if ids or expenses:
                invalidate(con, day, sale=bool(ids))
            result = dict(business_date=day, sale_ids=ids, expense_ids=expenses, replayed=False,
                          notice='已保存本次新增内容，请核对当日历史。填写零数量不代表确认整天零销售。')
            # 保存规范化输入供核对零数量；result 不持有过期快照金额。
            con.execute('INSERT INTO submissions(request_id,payload_hash,result_json) VALUES (?,?,?)', (body.request_id, digest, json.dumps(result)))
            audit(con, 'closing', 0, 'submit', after=payload)
            return result

    @router.get('/closing/requests/{request_id}')
    def closing_status(request_id: str):
        with connect(path) as con:
            row=con.execute('SELECT result_json FROM submissions WHERE request_id=?',(request_id,)).fetchone()
            return dict(saved=row is not None, result=json.loads(row[0]) if row else None)

    @router.get('/recycle')
    def recycle(business_date: BusinessDay | None = Query(default=None)):
        day = (business_date or today()).isoformat()
        with connect(path) as con:
            return {kind: [dict(r) for r in con.execute(f'SELECT * FROM {table} WHERE business_date=? AND deleted_at IS NOT NULL ORDER BY id DESC', (day,))]
                    for kind, table in [('sales', 'sales_records'), ('expenses', 'expenses')]}

    @router.post('/recycle/{kind}/{record_id}/restore')
    def restore(kind: Literal['sales', 'expenses'], record_id: int):
        table = 'sales_records' if kind == 'sales' else 'expenses'
        with connect(path) as con, con:
            con.execute('BEGIN IMMEDIATE')
            row = con.execute(f'SELECT * FROM {table} WHERE id=? AND deleted_at IS NOT NULL', (record_id,)).fetchone()
            if row is None:
                raise HTTPException(404, '记录已恢复或不存在，请刷新历史。')
            if kind == 'sales':
                allow_sale(con, row['business_date'])
            con.execute(f'UPDATE {table} SET deleted_at=NULL WHERE id=?', (record_id,))
            invalidate(con, row['business_date'], sale=kind == 'sales')
            audit(con, table, record_id, 'restore', row, need_row(con, table, record_id))
            return dict(business_date=row['business_date'], notice='已恢复历史快照，请重新核对营业状态。')

    @router.get('/audit')
    def history():
        with connect(path) as con:
            return [dict(r) for r in con.execute('SELECT * FROM record_audit ORDER BY id DESC LIMIT 200')]

    @router.get('/data/export')
    def export():
        with connect(path) as con:
            con.execute('BEGIN')
            data = {t: [dict(r) for r in con.execute(f'SELECT * FROM {t}')] for t in ('products', 'sales_records', 'expenses', 'business_days', 'record_audit')}
        return Response(json.dumps(dict(schema_version=3, data=data), ensure_ascii=False), media_type='application/json', headers={'Content-Disposition': 'attachment; filename="jiangxiaotan-records.json"', 'Cache-Control': 'no-store'})

    @router.get('/data/backup')
    def backup():
        # SQLite backup 从只读源生成一致性快照；不修改源、不覆盖文件。
        with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as source, sqlite3.connect(':memory:') as dest:
            source.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise HTTPException(500, '备份校验失败，请勿使用此备份。')
            content = dest.serialize()
        return Response(content, media_type='application/octet-stream', headers={'Content-Disposition': 'attachment; filename="jiangxiaotan-backup.db"', 'Cache-Control': 'no-store'})

    return router
