"""全部使用临时 SQLite 和本机模拟模型；不打开商家数据库。"""
from concurrent.futures import ThreadPoolExecutor
from datetime import date
import json
import sqlite3
import threading

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.database import initialize, connect, SCHEMA
from app.model_gateway import ModelSettings, mock_output
from app.analysis import validate_result
from app.analysis_summary import build_summary
from app.marketing import validate_copy
from app.model_usage import reserve, policy, estimate

DAY='2026-10-19'


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('APP_ENV','test')
    with TestClient(create_app(tmp_path/'care.db',ModelSettings('mock'))) as c:
        yield c


def product(c, name='豆花', price=529,cost=210):
    r=c.post('/api/products',json=dict(name=name,price_cents=price,unit_cost_cents=cost))
    assert r.status_code==201, r.text
    return r.json()


def closing(p, qty=3, key='test-closing-00001'):
    return dict(request_id=key,business_date=DAY,sales=[dict(product_id=p['id'],quantity=qty,expected_price_cents=p['price_cents'],expected_cost_cents=p['unit_cost_cents'])],expenses=[dict(business_date=DAY,category='交通费',amount_cents=229)])


def metrics(c,day=DAY): return c.get('/api/dashboard',params=dict(business_date=day)).json()['metrics']


def test_unknown_rest_zero_expense_and_review(client):
    assert metrics(client)['revenue_cents'] is None
    assert client.put(f'/api/business-days/{DAY}',json={'status':'rest'}).status_code==200
    assert client.post('/api/expenses',json=dict(business_date=DAY,category='交通',amount_cents=100)).status_code==201
    assert client.get(f'/api/business-days/{DAY}').json()['status']=='rest'
    assert metrics(client)['revenue_cents'] is None
    p=product(client)
    assert client.post('/api/sales',json=dict(product_id=p['id'],business_date=DAY,quantity=1)).status_code==409
    assert client.put(f'/api/business-days/{DAY}',json={'status':'zero'}).status_code==200
    m=metrics(client); assert m['revenue_cents']==0 and m['estimated_profit_cents']==-100
    summary=client.get('/api/analysis/preview',params=dict(business_date=DAY)).json()['summary']
    assert summary['totals']['revenue_cents']==0 and summary['totals']['quantity']==0
    assert summary['daily'][-1]['revenue_cents']==0 and summary['daily'][0]['revenue_cents'] is None
    assert client.get('/api/records',params=dict(business_date=DAY)).json()['sales']==[]
    client.post('/api/expenses',json=dict(business_date=DAY,category='其他',amount_cents=1))
    assert client.get(f'/api/business-days/{DAY}').json()['status']=='pending'
    assert metrics(client)['revenue_cents'] is None


@pytest.mark.parametrize('status',['zero','rest','unrecorded'])
def test_status_conflict_with_sales(client,status):
    p=product(client);client.post('/api/closing',json=closing(p))
    assert client.put(f'/api/business-days/{DAY}',json=dict(status=status)).status_code==409
    assert client.put(f'/api/business-days/{DAY}',json=dict(status='checked')).status_code==200
    client.post('/api/expenses',json=dict(business_date=DAY,category='其他',amount_cents=1))
    assert client.get(f'/api/business-days/{DAY}').json()['status']=='pending'


def test_transaction_idempotency_snapshot_recycle_and_audit(client):
    p=product(client);body=closing(p)
    first=client.post('/api/closing',json=body);assert first.status_code==200,first.text
    assert client.post('/api/closing',json=body).json()['replayed'] is True
    assert client.get('/api/closing/requests/'+body['request_id']).json()['saved'] is True
    assert client.get('/api/closing/requests/missing').json()['saved'] is False
    assert client.post('/api/closing',json={**body,'sales':[]}).status_code==409
    m=metrics(client);assert (m['revenue_cents'],m['gross_profit_cents'],m['extra_expense_cents'],m['estimated_profit_cents'])==(1587,957,229,728)
    client.put('/api/products/'+str(p['id']),json=dict(name='改名',price_cents=999,unit_cost_cents=300,is_active=False))
    sale_id=first.json()['sale_ids'][0]
    assert client.delete(f'/api/sales/{sale_id}').status_code==204
    assert metrics(client)['revenue_cents'] is None
    assert client.get('/api/recycle',params=dict(business_date=DAY)).json()['sales'][0]['unit_price_cents']==529
    assert client.post(f'/api/recycle/sales/{sale_id}/restore').status_code==200
    assert metrics(client)['revenue_cents']==1587
    assert client.post(f'/api/recycle/sales/{sale_id}/restore').status_code==404
    actions={r['action'] for r in client.get('/api/audit').json()}
    assert {'create','submit','edit','delete','restore'}<=actions
    # 删除后恢复也保留原提交编号；重发不能复活或新增一条记录。
    assert client.post('/api/closing',json=body).json()['replayed']
    assert metrics(client)['sales_record_count']==1


@pytest.mark.parametrize('fault',['price','cost','inactive','bad_product','bad_expense','duplicate','float','invalid_day'])
def test_batch_failure_rolls_back(client,fault):
    p=product(client);p2=product(client,'炸串');body=closing(p)
    bad=closing(p2)['sales'][0];body['sales'].append(bad)
    if fault=='price': bad['expected_price_cents']=1
    if fault=='cost': bad['expected_cost_cents']=1
    if fault=='inactive': client.put('/api/products/'+str(p2['id']),json=dict(name=p2['name'],price_cents=529,unit_cost_cents=210,is_active=False))
    if fault=='bad_product': bad['product_id']=999
    if fault=='bad_expense': body['expenses'][0]['amount_cents']=0
    if fault=='duplicate': bad['product_id']=p['id']
    if fault=='float': bad['quantity']=1.5
    if fault=='invalid_day': body['business_date']='2026-02-30'
    assert client.post('/api/closing',json=body).status_code in (404,409,422)
    h=client.get('/api/records',params=dict(business_date=DAY)).json()
    assert h['sales']==[] and h['expenses']==[]
    assert client.get('/api/closing/requests/'+body['request_id']).json()['saved'] is False


def test_zero_entry_is_not_zero_day_and_restart(tmp_path):
    path=tmp_path/'persist.db'
    with TestClient(create_app(path,ModelSettings())) as c:
        p=product(c);body=closing(p,0)
        assert c.post('/api/closing',json=body).status_code==200
        assert metrics(c)['revenue_cents'] is None
    with TestClient(create_app(path,ModelSettings())) as c:
        assert c.get('/api/closing/requests/'+body['request_id']).json()['saved']
        assert len(c.get('/api/records',params=dict(business_date=DAY)).json()['expenses'])==1
        assert c.post('/api/closing',json=body).json()['replayed']


def test_concurrent_same_batch_once(client):
    body=closing(product(client))
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(lambda _:client.post('/api/closing',json=body),range(4)))
    assert all(r.status_code==200 for r in results)
    assert sum(not r.json()['replayed'] for r in results)==1
    assert metrics(client)['sales_record_count']==1


def test_backup_export_and_no_mutation(client,tmp_path):
    client.post('/api/closing',json=closing(product(client)))
    client.delete('/api/sales/1')
    exported=client.get('/api/data/export');assert exported.status_code==200
    assert exported.json()['data']['sales_records'][0]['deleted_at'] is not None
    before=client.get('/api/audit').json()
    binary=client.get('/api/data/backup');assert binary.content.startswith(b'SQLite format 3')
    target=tmp_path/'download.db';target.write_bytes(binary.content)
    with sqlite3.connect(target) as con:
        assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert con.execute('SELECT COUNT(*) FROM sales_records').fetchone()[0]==1
    assert client.get('/api/audit').json()==before
    assert b'AI_API_KEY' not in exported.content


def test_all_products_loss_scan(client):
    for i in range(22):
        p=product(client,f'商品{i}',10000 if i<21 else 1,1 if i<21 else 1000)
        client.post('/api/sales',json=dict(product_id=p['id'],business_date=DAY,quantity=1))
    s=client.get('/api/analysis/preview',params=dict(business_date=DAY)).json()['summary']
    f=next(c for c in s['candidates'] if c['id']=='negative_margin')
    assert '商品21' in f['observation'] and f['evidence_ids']==['p21']
    assert s['evidence']['p21']['value']==-999


@pytest.mark.parametrize('prose',['建议立刻涨价，保证提升收入','可以在晴天天气增加备货','建议增加99元预算','建议增加三倍备货','可以查客流增长了多少','建议采用此方案，营业额999','必须立即增加销售'])
def test_natural_analysis_rejects_unsupported(client,prose):
    client.post('/api/closing',json=closing(product(client)))
    s=client.get('/api/analysis/preview',params=dict(business_date=DAY)).json()['summary']
    raw=json.loads(mock_output(s));raw['items'][0]['suggestion']=prose
    with pytest.raises(ValueError): validate_result(json.dumps(raw),s)


def test_natural_analysis_goal_and_no_stale(client):
    client.post('/api/closing',json=closing(product(client)))
    s=client.get('/api/analysis/preview',params=dict(business_date=DAY)).json()['summary']
    result=client.post('/api/analysis',json=dict(business_date=DAY,summary_hash=s['fingerprint'],goal='减少准备与操作负担',use_model=True,consent_to_send=True)).json()
    assert result['source']=='mock' and result['goal']=='减少准备与操作负担'
    assert all(f['follow_up'] and f['evidence'] and f['period'] for f in result['findings'])
    client.put(f'/api/business-days/{DAY}',json={'status':'checked'})
    assert client.post('/api/analysis',json=dict(business_date=DAY,summary_hash=s['fingerprint'])).status_code==409


@pytest.mark.parametrize('text',['欢迎购买，全校第一','如果想吃，限量三份','想吃就来，售价99元','欢迎来吃，外酥里嫩','如果路过，大家都说好','我们已经卖光了','欢迎，<script>alert(1)</script>'])
def test_natural_marketing_rejects_fabrication(client,text):
    p=product(client);body=dict(product_id=p['id'],expected_price_cents=529,price_confirmed=True)
    facts=client.post('/api/marketing/preview',json=body).json()['facts']
    with pytest.raises(ValueError): validate_copy(json.dumps(dict(schema_version=2,headline='课间看看',body=text)),facts)


def test_marketing_flexible_style_and_confirmed_numbers(client):
    p=product(client);body=dict(product_id=p['id'],expected_price_cents=529,price_confirmed=True,feature='提供3种辣度选择',feature_confirmed=True,theme='课间加餐',channel='小红书',style='商品介绍')
    preview=client.post('/api/marketing/preview',json=body);assert preview.status_code==200,preview.text
    result=client.post('/api/marketing',json={**body,'facts_hash':preview.json()['facts']['fingerprint'],'use_model':True,'consent_to_send':True}).json()
    assert result['source']=='mock' and '3种辣度' in result['draft'] and '5.29 元' in result['draft'] and '\n\n' in result['draft']
    assert '商家确认特色' not in result['draft']


def test_persistent_cap_including_pending_concurrency(tmp_path,monkeypatch):
    path=tmp_path/'cap.db';initialize(path);monkeypatch.setenv('AI_DAILY_CALL_LIMIT','2')
    def attempt(_):
        try: return reserve(path,'analysis')
        except Exception: return None
    with ThreadPoolExecutor(max_workers=5) as pool: results=list(pool.map(attempt,range(5)))
    assert sum(r is not None for r in results)==2
    assert policy(path)['remaining']==0
    initialize(path);assert policy(path)['used']==2


def test_cache_and_cap_do_not_send_again(tmp_path,monkeypatch):
    monkeypatch.setenv('AI_DAILY_CALL_LIMIT','1')
    class Gateway:
        calls=0
        last_call=dict(configured_model='fake',returned_model='fake',duration_ms=1,http_status=200,usage=dict(prompt_tokens=20,completion_tokens=10))
        def generate(self,s): self.calls+=1;return mock_output(s)
    g=Gateway();settings=ModelSettings('remote','https://example.invalid','fake','not-a-real-key',True)
    with TestClient(create_app(tmp_path/'cache.db',settings,g)) as c:
        preview=c.get('/api/analysis/preview',params=dict(business_date=DAY)).json()
        assert g.calls==0
        body=dict(business_date=DAY,summary_hash=preview['summary']['fingerprint'],use_model=True,consent_to_send=True)
        assert c.post('/api/analysis',json=body).json()['source']=='model'
        result=c.post('/api/analysis',json=body).json();assert result['cached'] and g.calls==1
        result=c.post('/api/analysis',json={**body,'regenerate':True}).json();assert result['source']=='basic' and g.calls==1
        assert result['usage_policy']['used']==1


def test_cost_estimate_never_claims_bill(monkeypatch):
    monkeypatch.delenv('AI_INPUT_YUAN_PER_MILLION',raising=False)
    assert estimate({'usage':{}})['estimated_cost_yuan'] is None
    monkeypatch.setenv('AI_INPUT_YUAN_PER_MILLION','1');monkeypatch.setenv('AI_OUTPUT_YUAN_PER_MILLION','2')
    assert estimate({'usage':{'prompt_tokens':1000,'completion_tokens':100}})['estimated_cost_yuan']=='0.0012'


@pytest.mark.parametrize('kind',['sales','expenses'])
def test_single_entry_retry_has_idempotency(client,kind):
    p=product(client)
    body=dict(business_date=DAY,request_id='single-record-key-0001')
    body.update(dict(product_id=p['id'],quantity=2) if kind=='sales' else dict(category='交通',amount_cents=29))
    first=client.post('/api/'+kind,json=body)
    assert first.status_code==201
    assert client.post('/api/'+kind,json=body).json()==first.json()
    assert len(client.get('/api/records',params=dict(business_date=DAY)).json()[kind])==1
    client.delete('/api/'+kind+'/'+str(first.json()['id']))
    assert client.post('/api/'+kind,json=body).status_code==404


def test_migration_v2_keeps_values_without_confirming_days(tmp_path):
    path=tmp_path/'old.db'
    with sqlite3.connect(path) as con:
        con.executescript(SCHEMA)
        con.execute('ALTER TABLE products ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1')
        con.execute("INSERT INTO sales_records(id,product_name,business_date,quantity,unit_price_cents,unit_cost_cents) VALUES (8,'旧商品','2026-10-19',2,100,50)")
        con.execute('PRAGMA user_version=2');con.commit()
    initialize(path);initialize(path)
    with TestClient(create_app(path,ModelSettings())) as c:
        assert metrics(c)['revenue_cents']==200
        assert c.get(f'/api/business-days/{DAY}').json()['status']=='pending'
        assert c.get('/api/records',params=dict(business_date=DAY)).json()['sales'][0]['id']==8
    with connect(path) as con:
        assert con.execute('SELECT COUNT(*) FROM business_days').fetchone()[0]==0
        con.execute('PRAGMA user_version=4');con.commit()
    with pytest.raises(RuntimeError): initialize(path)


def test_restored_sale_invalidates_zero_and_rest_conflicts(client):
    first=client.post('/api/closing',json=closing(product(client))).json()
    sid=first['sale_ids'][0]
    client.delete(f'/api/sales/{sid}')
    client.put(f'/api/business-days/{DAY}',json=dict(status='rest'))
    assert client.post(f'/api/recycle/sales/{sid}/restore').status_code==409
    client.put(f'/api/business-days/{DAY}',json=dict(status='zero'))
    assert client.post(f'/api/recycle/sales/{sid}/restore').status_code==200
    assert client.get(f'/api/business-days/{DAY}').json()['status']=='pending'


def test_checked_comparison_requires_explicit_check(client):
    p=product(client)
    for d in range(13,20): client.post('/api/sales',json=dict(product_id=p['id'],business_date=f'2026-10-{d}',quantity=1))
    def preview(): return client.get('/api/analysis/preview',params=dict(business_date=DAY)).json()['summary']
    assert 'day_comparison' not in preview()['evidence']
    for d in range(13,20): client.put(f'/api/business-days/2026-10-{d}',json=dict(status='checked'))
    assert preview()['evidence']['day_comparison']['value']==0
    assert '趋势或因果' in preview()['evidence']['day_comparison']['limitation']
