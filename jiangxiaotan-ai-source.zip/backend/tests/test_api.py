from datetime import date

import pytest
from fastapi.testclient import TestClient

from app.database import connect, initialize
from app.main import create_app
from app.summary import dashboard_summary


@pytest.fixture
def db(tmp_path):
    path = tmp_path / "test.db"
    initialize(path)
    return path


def test_health_initializes_database_and_is_idempotent(tmp_path):
    path = tmp_path / "nested" / "test.db"
    for _ in range(2):
        with TestClient(create_app(path)) as client:
            response = client.get("/api/health")
            assert response.status_code == 200
            assert response.json()["database"] == "connected"
            assert response.json()["schema_version"] == 3


def test_empty_data_and_date_validation(db):
    with TestClient(create_app(db)) as client:
        data = client.get("/api/dashboard?business_date=2026-10-14").json()
        assert data["has_data"] is False
        assert data["metrics"]["revenue_cents"] is None
        assert data["metrics"]["order_count"] is None
        assert len(data["trend"]) == 7
        assert all(row["revenue_cents"] is None for row in data["trend"])
        assert client.get("/api/dashboard?business_date=not-a-date").status_code == 422
        assert client.get("/api/dashboard?business_date=0001-01-01").status_code == 422


def test_money_aggregation_date_scope_and_persistence(db):
    with connect(db) as connection:
        connection.executemany(
            "INSERT INTO sales_records(product_name, business_date, quantity, unit_price_cents, unit_cost_cents) VALUES (?, ?, ?, ?, ?)",
            [("烤冷面", "2026-10-14", 3, 1050, 425), ("炸串", "2026-10-14", 2, 300, 125),
             ("烤冷面", "2026-10-13", 1, 1050, 425), ("窗口外", "2026-10-07", 9, 999, 100)],
        )
        connection.execute("INSERT INTO expenses(business_date, category, amount_cents) VALUES (?, ?, ?)", ("2026-10-14", "摊位费", 500))
        connection.commit()
    initialize(db)
    result = dashboard_summary(db, date(2026, 10, 14))
    assert result.metrics.revenue_cents == 3750
    assert result.metrics.recorded_cost_cents == 2025
    assert result.metrics.estimated_profit_cents == 1725
    assert result.metrics.sales_record_count == 2
    assert result.metrics.order_count is None
    assert result.trend[0].revenue_cents is None
    assert result.product_ranking[0].name == "烤冷面"
    assert result.product_ranking[0].gross_profit_cents == 2500
    assert len(result.product_ranking) == 2


def test_expenses_without_sales_do_not_imply_zero_revenue(db):
    with connect(db) as connection:
        connection.execute("INSERT INTO expenses(business_date, category, amount_cents) VALUES ('2026-10-14', '摊位费', 800)")
        connection.commit()
    result = dashboard_summary(db, date(2026, 10, 14))
    assert result.metrics.recorded_cost_cents == 800
    assert result.metrics.revenue_cents is None
    assert result.metrics.estimated_profit_cents is None


def test_negative_quantity_rejected(db):
    import sqlite3
    with connect(db) as connection, pytest.raises(sqlite3.IntegrityError):
        connection.execute("INSERT INTO sales_records(product_name, business_date, quantity, unit_price_cents, unit_cost_cents) VALUES ('烤冷面', '2026-10-14', -1, 1000, 500)")


def test_previous_day_expense_is_data_but_not_today_cost(db):
    with connect(db) as connection:
        connection.execute("INSERT INTO expenses(business_date, category, amount_cents) VALUES ('2026-10-13', '摊位费', 800)")
        connection.commit()
    result = dashboard_summary(db, date(2026, 10, 14))
    assert result.has_data is True
    assert result.metrics.recorded_cost_cents is None
    assert "没有销售记录" in result.notices[0]

