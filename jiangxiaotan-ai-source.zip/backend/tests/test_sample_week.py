from datetime import date
from pathlib import Path
import sqlite3
import sys

import pytest
from fastapi.testclient import TestClient
from app.database import connect, initialize
from app.main import create_app
from app.model_gateway import ModelSettings

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
from load_sample_week import replace_with_samples, MENU, snapshot


def original(path):
    initialize(path)
    with connect(path) as con, con:
        con.execute("INSERT INTO products(id,name,price_cents,unit_cost_cents) VALUES (50,'原商品',100,50)")
        con.execute("INSERT INTO sales_records(id,product_id,product_name,business_date,quantity,unit_price_cents,unit_cost_cents) VALUES (60,50,'原快照','2026-10-18',3,100,50)")
        con.execute("INSERT INTO expenses(id,business_date,category,amount_cents) VALUES (70,'2026-10-18','原支出',1)")
        con.execute("INSERT INTO model_calls(business_date,kind) VALUES ('2026-10-19','analysis')")
        con.execute("INSERT INTO submissions(request_id,payload_hash,result_json) VALUES ('old-request','old','{}')")


def test_sample_replaces_only_business_after_full_backup(tmp_path):
    path=tmp_path/'original.db';original(path)
    with connect(path) as con: before=snapshot(con)[1]
    result=replace_with_samples(path,date(2026,10,19),tmp_path/'backups')
    with sqlite3.connect(result['backup']) as con:
        assert snapshot(con)[1]==before
        assert con.execute('pragma integrity_check').fetchone()[0]=='ok'
    with TestClient(create_app(path,ModelSettings())) as c:
        assert c.get('/api/health').json()['sample_data'] is True
        products=c.get('/api/products').json()
        assert len(products)==10 and min(p['id'] for p in products)>50
        assert all(p['name'].startswith('演示·') for p in products)
        s=c.get('/api/analysis/preview?business_date=2026-10-19').json()['summary']
        assert s['coverage']['sales_days']==7 and s['coverage']['checked_days']==0
        assert s['totals']['revenue_cents']==sum(p*q for _,p,_,quantities in MENU for q in quantities)
        assert s['totals']['extra_expense_cents']==27600
        assert any(f['id']=='negative_margin' for f in s['candidates'])
    with connect(path) as con:
        assert con.execute('select count(*) from sales_records').fetchone()[0]==70
        assert con.execute('select count(*) from expenses').fetchone()[0]==14
        assert con.execute('select count(*) from model_calls').fetchone()[0]==1
        assert con.execute('select count(*) from submissions').fetchone()[0]==1
    replace_with_samples(path,date(2026,10,19),tmp_path/'backups')
    with connect(path) as con: assert con.execute('select count(*) from sales_records').fetchone()[0]==70
    assert len(list((tmp_path/'backups').glob('*.db')))==2


def test_failed_sample_import_rolls_back_existing_rows(tmp_path):
    path=tmp_path/'original.db';original(path)
    with connect(path) as con,con:
        before=snapshot(con)[1]
        con.execute("CREATE TRIGGER reject_sample BEFORE INSERT ON products WHEN NEW.name LIKE '%柠檬茶%' BEGIN SELECT RAISE(ABORT,'test import failure'); END")
    with pytest.raises(sqlite3.IntegrityError): replace_with_samples(path,date(2026,10,19),tmp_path/'backups')
    with connect(path) as con: assert snapshot(con)[1]==before
