import json
import threading

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.model_gateway import ModelSettings, CompatibleGateway, ModelFailure
from test_analysis import mock_server


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('APP_ENV','test')
    with TestClient(create_app(tmp_path/'marketing.db',ModelSettings('mock'))) as c:
        c.post('/api/products',json=dict(name='测试豆花',price_cents=529,unit_cost_cents=210))
        yield c


def facts(**kwargs):
    return dict(product_id=1,expected_price_cents=529,price_confirmed=True,**kwargs)


def generate(c,body=None,**kwargs):
    body=body or facts()
    preview=c.post('/api/marketing/preview',json=body)
    assert preview.status_code==200,preview.text
    return c.post('/api/marketing',json={**body,'facts_hash':preview.json()['facts']['fingerprint'],**kwargs})


def test_complete_marketing_and_template(client):
    body=facts(feature='现点现做',feature_confirmed=True)
    preview=client.post('/api/marketing/preview',json=body).json()
    assert 'unit_cost' not in json.dumps(preview) and 'quantity' not in json.dumps(preview)
    r=generate(client,body,use_model=True,consent_to_send=True)
    assert r.status_code==200
    assert r.json()['source']=='mock' and '5.29 元' in r.json()['draft'] and '现点现做' in r.json()['draft']
    assert generate(client,body,use_model=False).json()['source']=='template'
    assert generate(client,body,use_model=True,consent_to_send=False).status_code==422


@pytest.mark.parametrize('change',[{'price_confirmed':False},{'expected_price_cents':999},{'feature':'现做','feature_confirmed':False},{'feature':'全校第一','feature_confirmed':True},{'feature':'买一送一','feature_confirmed':True},{'feature':'限量10份','feature_confirmed':True},{'offer_kind':'special_price','offer_price_cents':429},{'offer_kind':'none','offer_price_cents':429}])
def test_reject_unconfirmed_or_conflicting_facts(client,change):
    body=facts();body.update(change)
    assert client.post('/api/marketing/preview',json=body).status_code in (409,422)


@pytest.mark.parametrize('price,start,end,status',[(429,'2026-10-18','2026-10-20',200),(529,'2026-10-18','2026-10-20',422),(429,'2026-10-21','2026-10-20',422),(429,'2026-02-30','2026-10-20',422)])
def test_explicit_offer_and_dates(client,price,start,end,status):
    body=facts(offer_kind='special_price',offer_price_cents=price,start_date=start,end_date=end,offer_confirmed=True)
    r=client.post('/api/marketing/preview',json=body)
    assert r.status_code==status
    if status==200:
        draft=generate(client,body,use_model=False).json()['draft']
        assert '4.29 元' in draft and start in draft and end in draft and '5.29 元' in draft


def test_product_price_name_and_disable_invalidate(client):
    body=facts();preview=client.post('/api/marketing/preview',json=body).json()
    client.put('/api/products/1',json=dict(name='改名豆花',price_cents=529,unit_cost_cents=210))
    assert client.post('/api/marketing',json={**body,'facts_hash':preview['facts']['fingerprint']}).status_code==409
    client.put('/api/products/1',json=dict(name='改名豆花',price_cents=629,unit_cost_cents=210))
    assert client.post('/api/marketing/preview',json=body).status_code==409
    client.put('/api/products/1',json=dict(name='改名豆花',price_cents=529,unit_cost_cents=210,is_active=False))
    assert client.post('/api/marketing/preview',json=body).status_code==409


@pytest.mark.parametrize('raw',['{}','{"schema_version":1,"style_id":"fake","headline_id":"simple"}','{"schema_version":1,"style_id":"warm","headline_id":"simple","text":"销量9999全校第一"}',''])
def test_invalid_model_copy_falls_back(tmp_path,raw):
    class Gateway:
        def generate_marketing(self,p): return raw
    settings=ModelSettings('remote','https://example.invalid','test','test-key',True)
    with TestClient(create_app(tmp_path/'m.db',settings,Gateway())) as c:
        c.post('/api/products',json=dict(name='测试豆花',price_cents=529,unit_cost_cents=210))
        r=generate(c,use_model=True,consent_to_send=True).json()
        assert r['source']=='template' and '9999' not in r['draft'] and '回退' in r['reason']


@pytest.mark.parametrize('tail',['','/v1','/chat/completions','/v1/chat/completions'])
def test_deepseek_endpoint_parameters_and_final_content(monkeypatch,tail):
    monkeypatch.setenv('APP_ENV','test')
    with mock_server('ok') as (url,received):
        base=url.removesuffix('/v1')
        gateway=CompatibleGateway(ModelSettings('remote',base+tail,'deepseek-flash','test-key',True,2,'deepseek'))
        raw=gateway.generate_marketing({'product_name':'测试豆花','price_cents':529})
        assert json.loads(raw)['style_id']=='warm'
        route,body,_=received[0]
        assert route in ('/chat/completions','/v1/chat/completions')
        assert body['thinking']=={'type':'disabled'} and body['response_format']=={'type':'json_object'} and body['max_tokens']==1600
        assert gateway.last_call['returned_model']=='mock-returned-model'
        assert gateway.last_call['usage']['total_tokens']==30


@pytest.mark.parametrize('url',['https://third-party.invalid','https://api.deepseek.com/anthropic','https://api.deepseek.com/v1/v1','https://user:secret@api.deepseek.com','http://api.deepseek.com','https://api.deepseek.com?token=secret'])
def test_deepseek_rejects_unsafe_or_wrong_address(url):
    with pytest.raises(ModelFailure): CompatibleGateway(ModelSettings(base_url=url,provider='deepseek')).endpoint()


def test_analysis_changed_during_generation(tmp_path):
    from app.database import connect
    path=tmp_path/'m.db'
    class Gateway:
        def generate(self,summary):
            with connect(path) as con,con: con.execute("INSERT INTO expenses(business_date,category,amount_cents) VALUES ('2026-10-18','changed',1)")
            return '{"schema_version":1,"items":[{"finding_id":"coverage","evidence_ids":["coverage"],"action_id":"complete_records"}]}'
    with TestClient(create_app(path,ModelSettings('remote','https://example.invalid','test','key',True),Gateway())) as c:
        summary=c.get('/api/analysis/preview?business_date=2026-10-18').json()['summary']
        r=c.post('/api/analysis',json=dict(business_date='2026-10-18',summary_hash=summary['fingerprint'],use_model=True,consent_to_send=True))
        assert r.status_code==409


@pytest.mark.parametrize('kind',['ok','invalid','timeout','error','truncated','malformed_envelope'])
def test_marketing_http_failures_and_call_receipt(tmp_path,monkeypatch,kind):
    monkeypatch.setenv('APP_ENV','test')
    with mock_server(kind) as (url,received):
        settings=ModelSettings('remote',url,'deepseek-flash','test-key',True,.1 if kind=='timeout' else 2,'deepseek')
        with TestClient(create_app(tmp_path/'m.db',settings)) as c:
            c.post('/api/products',json=dict(name='测试豆花',price_cents=529,unit_cost_cents=210))
            assert c.get('/api/marketing/config').status_code==200 and not received
            assert c.post('/api/marketing/preview',json=facts()).status_code==200 and not received
            response=generate(c,use_model=True,consent_to_send=True)
            result=response.json()
            assert result['source']==('model' if kind=='ok' else 'template')
            assert len(received)==1
            assert result['call']['validation_passed']==(kind=='ok')
            assert result['call']['duration_ms']>=0
            assert 'test-key' not in response.text and '不得展示' not in response.text
            assert '天气晴朗' not in result['draft']


@pytest.mark.parametrize('settings',[ModelSettings(),ModelSettings('remote','https://example.invalid','x','',True),ModelSettings('remote','https://example.invalid','x','secret',False)])
def test_marketing_off_missing_key_and_not_authorized(tmp_path,settings):
    class Never:
        def generate_marketing(self,facts): raise AssertionError('must not send')
    with TestClient(create_app(tmp_path/'m.db',settings,Never())) as c:
        c.post('/api/products',json=dict(name='测试豆花',price_cents=529,unit_cost_cents=210))
        assert generate(c,use_model=True).json()['source']=='template'


def test_analysis_marketing_share_concurrent_limit(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from app.model_gateway import mock_output
    entered,release=threading.Event(),threading.Event()
    class Waiting:
        def generate(self,summary):
            entered.set()
            assert release.wait(5)
            return mock_output(summary)
    with TestClient(create_app(tmp_path/'m.db',ModelSettings('remote','https://example.invalid','test','key',True),Waiting())) as c:
        c.post('/api/products',json=dict(name='测试豆花',price_cents=529,unit_cost_cents=210))
        s=c.get('/api/analysis/preview?business_date=2026-10-18').json()['summary']
        with ThreadPoolExecutor(max_workers=1) as pool:
            pending=pool.submit(c.post,'/api/analysis',json=dict(business_date='2026-10-18',summary_hash=s['fingerprint'],use_model=True,consent_to_send=True))
            try:
                assert entered.wait(5)
                assert generate(c,use_model=True,consent_to_send=True).status_code==429
            finally: release.set()
            assert pending.result().status_code==200
