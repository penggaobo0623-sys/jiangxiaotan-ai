"""独立库 + 本机模拟 HTTP 模型，不访问收费服务。"""
from contextlib import contextmanager
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import threading
import time

import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.analysis_summary import build_summary
from app.analysis import validate_result
from app.model_gateway import ModelSettings, CompatibleGateway, ModelFailure, mock_output

DAY='2026-10-15'


def seed(c, days=7):
    p=c.post('/api/products',json=dict(name='测试商品',price_cents=29,unit_cost_cents=10)).json()
    for i in range(days):
        assert c.post('/api/sales',json=dict(product_id=p['id'],business_date=f'2026-10-{9+i:02d}',quantity=3)).status_code==201
    c.post('/api/expenses',json=dict(business_date=DAY,category='测试支出',amount_cents=5))


def request(c, **kwargs):
    preview=c.get('/api/analysis/preview',params=dict(business_date=DAY)).json()
    return c.post('/api/analysis',json=dict(business_date=DAY,summary_hash=preview['summary']['fingerprint'],**kwargs))


def test_summary_integer_and_snapshots(tmp_path):
    path=tmp_path/'a.db'
    with TestClient(create_app(path)) as c:
        seed(c)
        for i in range(7):
            assert c.put(f'/api/business-days/2026-10-{9+i:02d}',json={'status':'checked'}).status_code==200
        summary=c.get('/api/analysis/preview',params={'business_date':DAY}).json()['summary']
        assert summary['coverage']['sales_days']==7
        assert summary['totals']['revenue_cents']==609
        assert summary['totals']['gross_profit_cents']==399
        assert summary['totals']['estimated_profit_cents']==394
        assert summary['totals']['order_count'] is None
        assert summary['evidence']['day_comparison']['value']==0
        c.put('/api/products/1',json=dict(name='改名',price_cents=999,unit_cost_cents=700))
        after=c.get('/api/analysis/preview',params={'business_date':DAY}).json()['summary']
        assert after==summary
    with TestClient(create_app(path)) as c:
        assert c.get('/api/analysis/preview',params={'business_date':DAY}).json()['summary']==summary


@pytest.mark.parametrize('days',[0,1,2,6])
def test_insufficient_and_expense_only(tmp_path,days):
    with TestClient(create_app(tmp_path/'a.db')) as c:
        seed(c,days)
        r=request(c,use_model=False).json()
        s=r['summary']
        assert s['coverage']['sales_days']==days
        assert len(s['coverage']['missing_sales_dates'])==7-days
        assert 'comparison' not in [f['id'] for f in r['findings']]
        assert s['daily'][-1]['revenue_cents'] is None
        if not days:
            assert s['totals']['revenue_cents'] is None and s['totals']['estimated_profit_cents'] is None
        assert all(f['evidence'] and f['limitation'] and f['period']['start']=='2026-10-09' for f in r['findings'])


@contextmanager
def mock_server(kind='ok'):
    received=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            received.append((self.path,body,self.headers.get('Authorization')))
            summary=json.loads(body['messages'][1]['content'])
            raw=mock_output(summary) if 'candidates' in summary else '{"schema_version":1,"style_id":"warm","headline_id":"invitation"}'
            status=200
            if kind=='invalid': raw='天气晴朗，客流增长，净利润99999'
            if kind=='conflict':
                data=json.loads(raw);data['items'][0]['observation']='营业额99999';raw=json.dumps(data)
            if kind=='bad_reference':
                data=json.loads(raw);data['items'][0]['evidence_ids']=['weather'];raw=json.dumps(data)
            if kind=='timeout': time.sleep(.3)
            if kind=='error': status=503
            if kind=='redirect':
                self.send_response(302);self.send_header('Location','https://example.invalid/secret');self.end_headers();return
            value=json.dumps({'model':'mock-returned-model','usage':{'prompt_tokens':20,'completion_tokens':10,'total_tokens':30},'choices':[{'finish_reason':'length' if kind=='truncated' else 'stop','message':{'content':raw,'reasoning_content':'不得展示的思考内容'}}]}).encode()
            if kind=='malformed_envelope': value=json.dumps({'choices':['not an object']}).encode()
            try:
                self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(value)));self.end_headers();self.wfile.write(value)
            except (BrokenPipeError,ConnectionResetError): pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
    try: yield f'http://127.0.0.1:{server.server_port}/v1',received
    finally: server.shutdown();server.server_close();t.join()


@pytest.mark.parametrize('kind',['ok','invalid','conflict','bad_reference','timeout','error','redirect','truncated','malformed_envelope'])
def test_transport_and_fallback(tmp_path,monkeypatch,kind):
    monkeypatch.setenv('APP_ENV','test')
    with mock_server(kind) as (url,received):
        settings=ModelSettings('remote',url,'test-model','test-only-key',True,.1 if kind=='timeout' else 2)
        with TestClient(create_app(tmp_path/'a.db',settings)) as c:
            seed(c)
            assert not received # 打开和写记录不调用模型
            assert c.get('/api/analysis/preview').status_code==200 and not received
            response=request(c,use_model=True,consent_to_send=True)
            assert response.status_code==200
            result=response.json()
            assert result['source']==('model' if kind=='ok' else 'basic')
            assert result['findings']
            assert 'test-only-key' not in response.text and '99999' not in response.text and '天气晴朗' not in response.text
            assert len(received)==1 and received[0][0]=='/v1/chat/completions'
            assert 'category' not in received[0][1]['messages'][1]['content']


@pytest.mark.parametrize('settings',[ModelSettings(),ModelSettings('remote','https://example.invalid','x','',True),ModelSettings('remote','https://example.invalid','x','secret',False)])
def test_off_no_key_no_authorization(tmp_path,settings):
    class Never:
        def generate(self,summary): raise AssertionError('must not send')
    with TestClient(create_app(tmp_path/'a.db',settings,Never())) as c:
        result=request(c,use_model=True).json()
        assert result['source']=='basic'
        assert result['reason']


def test_consent_and_stale_preview(tmp_path,monkeypatch):
    monkeypatch.setenv('APP_ENV','test')
    with TestClient(create_app(tmp_path/'a.db',ModelSettings('mock'))) as c:
        assert request(c,use_model=True,consent_to_send=False).status_code==422
        preview=c.get('/api/analysis/preview',params=dict(business_date=DAY)).json()
        seed(c)
        assert c.post('/api/analysis',json=dict(business_date=DAY,summary_hash=preview['summary']['fingerprint'])).status_code==409
        assert request(c,use_model=True,consent_to_send=True).json()['source']=='mock'


def test_mock_disabled_in_merchant(tmp_path,monkeypatch):
    monkeypatch.setenv('APP_ENV','local')
    with TestClient(create_app(tmp_path/'a.db',ModelSettings('mock'))) as c:
        assert request(c,use_model=True,consent_to_send=True).json()['source']=='basic'


@pytest.mark.parametrize('mutation',['wrong_action','duplicate','version','extra','fake_number'])
def test_strict_selection(tmp_path,mutation):
    with TestClient(create_app(tmp_path/'a.db')) as c: seed(c)
    s=build_summary(tmp_path/'a.db',date.fromisoformat(DAY)); raw=json.loads(mock_output(s))
    if mutation=='wrong_action': raw['items'][0]['action_id']='buy_ads'
    if mutation=='duplicate': raw['items']=[raw['items'][0]]*2
    if mutation=='version': raw['schema_version']=999
    if mutation=='extra': raw['market_survey']='虚构调研'
    if mutation=='fake_number': raw['items'][0]['revenue_cents']=999999
    with pytest.raises(ValueError): validate_result(json.dumps(raw),s)


@pytest.mark.parametrize('body',[{'business_date':'2026-02-30'},{'business_date':'2026-10-15','summary_hash':'bad'},{'business_date':DAY,'summary_hash':'a'*64,'use_model':'true'}])
def test_invalid_request(tmp_path,body):
    with TestClient(create_app(tmp_path/'a.db')) as c: assert c.post('/api/analysis',json=body).status_code==422


def test_zero_sales_are_known_and_product_limit(tmp_path):
    with TestClient(create_app(tmp_path/'a.db')) as c:
        for i in range(21):
            p=c.post('/api/products',json=dict(name=f'商品{i}',price_cents=0,unit_cost_cents=1)).json()
            c.post('/api/sales',json=dict(product_id=p['id'],business_date=DAY,quantity=1))
        s=c.get('/api/analysis/preview',params=dict(business_date=DAY)).json()['summary']
        assert s['totals']['revenue_cents']==0 and s['totals']['gross_profit_cents']==-21
        assert len(s['products'])==20 and s['omitted_product_count']==1
        assert s['daily'][-1]['revenue_cents']==0 and s['daily'][0]['revenue_cents'] is None
