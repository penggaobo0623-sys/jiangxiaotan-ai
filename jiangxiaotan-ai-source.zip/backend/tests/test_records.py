"""所有样本使用 tmp_path，绝不向默认商家库写入数据。"""
import sqlite3

import pytest
from fastapi.testclient import TestClient

from app.database import SCHEMA, connect, initialize
from app.main import create_app

DAY = "2026-10-15"


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path / "business.db")) as connection:
        yield connection


def product(client, **overrides):
    body = dict(name="烤冷面", price_cents=29, unit_cost_cents=10, is_active=True)
    body.update(overrides)
    response = client.post("/api/products", json=body)
    assert response.status_code == 201, response.text
    return response.json()


def sale(client, item, quantity=3, day=DAY):
    response = client.post("/api/sales", json=dict(product_id=item["id"], business_date=day, quantity=quantity))
    assert response.status_code == 201, response.text
    return response.json()


def metrics(client, day=DAY):
    response = client.get("/api/dashboard", params={"business_date": day})
    assert response.status_code == 200, response.text
    return response.json()["metrics"]


def test_end_to_end_snapshots_price_change_edit_and_delete(client):
    item = product(client)
    first = sale(client, item)
    expense = client.post("/api/expenses", json=dict(business_date=DAY, category="交通费", amount_cents=5))
    assert expense.status_code == 201
    assert metrics(client)["revenue_cents"] == 87
    assert metrics(client)["recorded_cost_cents"] == 35
    assert metrics(client)["estimated_profit_cents"] == 52

    updated = dict(name="招牌烤冷面", price_cents=1050, unit_cost_cents=400, is_active=True)
    assert client.put(f"/api/products/{item['id']}", json=updated).status_code == 200
    records = client.get("/api/records", params={"business_date": DAY}).json()
    assert records["sales"][0] == first
    second = sale(client, item, quantity=1)
    assert second["product_name"] == "招牌烤冷面"
    assert second["unit_price_cents"] == 1050
    ranking = client.get("/api/dashboard", params={"business_date": DAY}).json()["product_ranking"]
    assert len(ranking) == 1 and ranking[0]["quantity"] == 4
    assert ranking[0]["revenue_cents"] == 1137

    edit = dict(business_date=DAY, product_name=first["product_name"], quantity=5, unit_price_cents=29, unit_cost_cents=10)
    response = client.put(f"/api/sales/{first['id']}", json=edit)
    assert response.status_code == 200
    assert response.json()["revenue_cents"] == 145
    assert metrics(client)["estimated_profit_cents"] == 740
    assert client.get("/api/products").json()[0]["price_cents"] == 1050
    assert client.delete(f"/api/sales/{first['id']}").status_code == 204
    assert client.delete(f"/api/sales/{second['id']}").status_code == 204
    remaining = metrics(client)
    assert remaining["recorded_cost_cents"] == 5
    assert remaining["revenue_cents"] is None
    assert remaining["estimated_profit_cents"] is None
    assert remaining["order_count"] is None
    expense_id = expense.json()["id"]
    assert client.delete(f"/api/expenses/{expense_id}").status_code == 204
    assert metrics(client)["recorded_cost_cents"] is None
    assert client.delete(f"/api/expenses/{expense_id}").status_code == 404


def test_inactive_product_retains_and_allows_editing_history(client):
    item = product(client)
    record = sale(client, item)
    body = dict(name=item["name"], price_cents=29, unit_cost_cents=10, is_active=False)
    assert client.put(f"/api/products/{item['id']}", json=body).status_code == 200
    assert client.post("/api/sales", json=dict(product_id=item["id"], business_date=DAY, quantity=1)).status_code == 409
    assert client.get("/api/products").json()[0]["sales_record_count"] == 1
    assert client.put(f"/api/sales/{record['id']}", json=dict(business_date=DAY, quantity=4, product_name=record["product_name"], unit_price_cents=29, unit_cost_cents=10)).status_code == 200
    body["is_active"] = True
    assert client.put(f"/api/products/{item['id']}", json=body).status_code == 200
    sale(client, item, quantity=1)
    assert metrics(client)["revenue_cents"] == 145


def test_dates_expense_edit_and_negative_profit(client):
    item = product(client, unit_cost_cents=50)
    first = sale(client, item, quantity=1)
    assert metrics(client)["estimated_profit_cents"] == -21
    expense = client.post("/api/expenses", json=dict(business_date=DAY, category="摊位费", amount_cents=100)).json()
    assert client.put(f"/api/expenses/{expense['id']}", json=dict(business_date="2026-10-14", category="摊位费更正", amount_cents=200)).status_code == 200
    yesterday = client.get("/api/records?business_date=2026-10-14").json()
    assert yesterday["expenses"][0]["amount_cents"] == 200
    assert yesterday["sales"] == []
    assert metrics(client, "2026-10-14")["revenue_cents"] is None
    assert metrics(client)["recorded_cost_cents"] == 50
    assert client.put(f"/api/sales/{first['id']}", json=dict(business_date="2026-10-13", quantity=2, product_name="更正名称", unit_price_cents=29, unit_cost_cents=50)).status_code == 200
    assert metrics(client)["revenue_cents"] is None
    assert metrics(client, "2026-10-13")["revenue_cents"] == 58
    assert client.get(f"/api/records?business_date={DAY}").json()["sales"] == []


def test_restart_keeps_committed_records(tmp_path):
    path = tmp_path / "persist.db"
    with TestClient(create_app(path)) as client:
        item = product(client)
        record = sale(client, item)
    with TestClient(create_app(path)) as restarted:
        assert restarted.get("/api/records", params={"business_date": DAY}).json()["sales"] == [record]
        assert metrics(restarted)["revenue_cents"] == 87


def test_v1_migration_preserves_existing_rows_and_ids(tmp_path):
    path = tmp_path / "v1.db"
    with sqlite3.connect(path) as connection:
        connection.executescript(SCHEMA)
        connection.execute("INSERT INTO products(id,name,price_cents,unit_cost_cents) VALUES (8,'老商品',1050,425)")
        connection.execute("INSERT INTO sales_records(id,product_id,product_name,business_date,quantity,unit_price_cents,unit_cost_cents) VALUES (19,8,'旧快照','2026-10-15',3,900,400)")
        connection.execute("INSERT INTO expenses(id,business_date,category,amount_cents) VALUES (5,'2026-10-15','支出',123)")
        connection.execute("PRAGMA user_version=1")
        connection.commit()
    with connect(path) as connection:
        before = {table: [dict(row) for row in connection.execute(f"SELECT * FROM {table}")] for table in ("products", "sales_records", "expenses")}
    for _ in range(2):
        initialize(path)
    with connect(path) as connection:
        assert connection.execute("PRAGMA user_version").fetchone()[0] == 3
        item = dict(connection.execute("SELECT * FROM products").fetchone())
        assert item.pop("is_active") == 1
        assert [item] == before["products"]
        for table in ("sales_records", "expenses"):
            migrated = [dict(row) for row in connection.execute(f"SELECT * FROM {table}")]
            for row in migrated:
                assert row.pop('deleted_at') is None
            assert migrated == before[table]
    with TestClient(create_app(path)) as client:
        assert metrics(client)["revenue_cents"] == 2700
        assert metrics(client)["estimated_profit_cents"] == 1377


@pytest.mark.parametrize("field,value", [("name", "   "), ("name", "a" * 61), ("name", 12), ("name", "坏\n名称"), ("price_cents", -1), ("price_cents", 0.29), ("price_cents", True), ("price_cents", "29"), ("unit_cost_cents", 100_000_001), ("is_active", 1)])
def test_invalid_products_rejected(client, field, value):
    body = dict(name="合法商品", price_cents=29, unit_cost_cents=10, is_active=True)
    body[field] = value
    assert client.post("/api/products", json=body).status_code == 422
    assert client.get("/api/products").json() == []


@pytest.mark.parametrize("field,value", [("quantity", 0), ("quantity", -1), ("quantity", 1.5), ("quantity", True), ("quantity", "3"), ("quantity", 100_001), ("business_date", "2026-02-30"), ("business_date", "1999-12-31"), ("business_date", "2101-01-01"), ("business_date", 0), ("business_date", "2026-10-15T00:00:00"), ("product_id", True)])
def test_invalid_sales_rejected(client, field, value):
    item = product(client)
    body = dict(product_id=item["id"], business_date=DAY, quantity=1)
    body[field] = value
    assert client.post("/api/sales", json=body).status_code == 422
    assert metrics(client)["revenue_cents"] is None


@pytest.mark.parametrize("amount", [0, -1, True, 1.5, "10", 100_000_001])
def test_invalid_expenses_rejected(client, amount):
    assert client.post("/api/expenses", json=dict(business_date=DAY, category="额外支出", amount_cents=amount)).status_code == 422
    assert metrics(client)["recorded_cost_cents"] is None


def test_unknown_records_duplicate_names_and_untrusted_calculations(client):
    item = product(client)
    assert client.post("/api/products", json=dict(name="  烤冷面  ", price_cents=99, unit_cost_cents=10)).status_code == 409
    assert client.post("/api/sales", json=dict(product_id=9999, business_date=DAY, quantity=1)).status_code == 404
    assert client.post("/api/sales", json=dict(product_id=item["id"], business_date=DAY, quantity=1, unit_price_cents=1)).status_code == 422
    record = sale(client, item)
    edit = dict(product_name=record["product_name"], unit_price_cents=29, unit_cost_cents=10, quantity=1, business_date=DAY)
    assert client.put(f"/api/sales/{record['id']}", json={**edit, "revenue_cents": 1}).status_code == 422
    assert client.put(f"/api/sales/{record['id']}", json={**edit, "product_id": 999}).status_code == 422
    assert client.put("/api/sales/9999", json=edit).status_code == 404
    assert client.delete("/api/sales/9999").status_code == 404
    assert client.put("/api/expenses/9999", json=dict(business_date=DAY, category="费", amount_cents=1)).status_code == 404
    assert client.get("/api/records?business_date=1234567890").status_code == 422


def test_different_products_with_same_historical_name_are_not_merged(client):
    first = product(client)
    sale(client, first)
    assert client.put(f"/api/products/{first['id']}", json=dict(name="新名称", price_cents=29, unit_cost_cents=10)).status_code == 200
    second = product(client)
    sale(client, second)
    ranks = client.get(f"/api/dashboard?business_date={DAY}").json()["product_ranking"]
    assert len(ranks) == 2
    assert len({row["key"] for row in ranks}) == 2


def test_write_cors_preflight(client):
    response = client.options("/api/sales", headers={"Origin": "http://localhost:5173", "Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "content-type"})
    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "http://localhost:5173"
