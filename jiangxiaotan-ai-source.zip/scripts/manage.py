"""Windows 一键安装、启动和检查；所有依赖保存在项目目录。"""
import argparse
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"
VENV_PYTHON = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
BUNDLED = Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies"
HOST = "127.0.0.1"
BACKEND_PORT = 8000
FRONTEND_PORT = 5173


@dataclass
class Service:
    name: str
    process: subprocess.Popen
    log_path: Path


@dataclass(frozen=True)
class ProbeResult:
    ok: bool
    detail: str


# 不使用系统代理，也不自动跟随重定向把错误服务当成本项目。
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        return None


def executable(name: str, fallback: Path) -> str:
    found = shutil.which(name)
    if found:
        return found
    if fallback.is_file():
        return str(fallback)
    raise RuntimeError(f"未找到 {name}，请按 README 安装后重新打开终端。")


def node() -> str:
    path = executable("node", BUNDLED / "node/bin/node.exe")
    version = subprocess.check_output([path, "--version"], text=True).strip()
    major, minor = map(int, version.lstrip("v").split(".")[:2])
    if not (major >= 22 and (major != 22 or minor >= 12) or major == 20 and minor >= 19):
        raise RuntimeError(f"当前 Node.js 为 {version}，请安装 Node.js 24 LTS 或 22.12 以上版本。")
    return path


def run(command: list[str], cwd: Path = ROOT, env: dict[str, str] | None = None) -> None:
    result = subprocess.run(command, cwd=cwd, env=env)
    if result.returncode:
        raise RuntimeError(f"命令执行失败，退出码 {result.returncode}。请查看上方错误信息。")


def install(direct_download: bool = False) -> None:
    node_path = node()
    if not VENV_PYTHON.exists():
        bundled_python = BUNDLED / "python/python.exe"
        base_python = str(bundled_python) if bundled_python.exists() else sys.executable
        run([base_python, "-m", "venv", str(ROOT / ".venv")])
    print("正在安装后端和测试依赖…", flush=True)
    # Codex 内置的新 pip 可绕开部分 Windows 旧 pip 的代理兼容问题。
    bundled_python = BUNDLED / "python/python.exe"
    if bundled_python.exists():
        pip = [str(bundled_python), "-m", "pip", "--python", str(VENV_PYTHON)]
    else:
        pip = [str(VENV_PYTHON), "-m", "pip"]
        run(pip + ["install", "--upgrade", "pip"])
    install_env = os.environ.copy()
    if direct_download:
        for key in ("HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY", "https_proxy", "http_proxy", "all_proxy"):
            install_env.pop(key, None)
        print("本次 Python 依赖下载使用直连，不修改系统代理设置。", flush=True)
    run(pip + ["install", "-r", "backend/requirements-dev.txt"], env=install_env)
    print("正在安装前端依赖…", flush=True)
    bundled_pnpm = BUNDLED / "node/node_modules/pnpm/bin/pnpm.cjs"
    if bundled_pnpm.exists():
        run([node_path, str(bundled_pnpm), "install", "--frozen-lockfile", "--store-dir", ".pnpm-store"], FRONTEND)
    elif shutil.which("pnpm"):
        run([shutil.which("pnpm"), "install", "--frozen-lockfile", "--store-dir", ".pnpm-store"], FRONTEND)
    else:
        # 标准 Node.js 安装附带 npm；无需用户另外安装包管理器。
        npm = executable("npm", Path(node_path).parent / "npm.cmd")
        run([npm, "install"], FRONTEND)
    print("安装完成。现在可以双击 start.cmd 启动。", flush=True)


def require_dependencies() -> str:
    if not VENV_PYTHON.exists() or not (FRONTEND / "node_modules/vite/bin/vite.js").is_file():
        raise RuntimeError("依赖尚未安装，请先双击 setup.cmd。")
    checked = subprocess.run(
        [str(VENV_PYTHON), "-c", "import fastapi, uvicorn, dotenv"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if checked.returncode:
        raise RuntimeError("项目虚拟环境缺少后端依赖，请先运行 setup.cmd。\n" + checked.stderr.strip())
    return node()


def build(node_path: str) -> None:
    run([node_path, "node_modules/typescript/bin/tsc", "--noEmit"], FRONTEND)
    run([node_path, "node_modules/vite/bin/vite.js", "build"], FRONTEND)


def is_port_free(port: int) -> bool:
    with socket.socket() as probe:
        try:
            probe.bind((HOST, port))
            return True
        except OSError:
            return False


def probe_http(url: str, kind: str) -> ProbeResult:
    """检查实际响应内容；保留错误原因，不能只看端口或 ready 字样。"""
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    try:
        with opener.open(url, timeout=5) as response:
            body = response.read(1024 * 1024).decode("utf-8", errors="replace")
            if response.status != 200:
                return ProbeResult(False, f"HTTP {response.status}")
            if kind == "health":
                data = json.loads(body)
                valid = isinstance(data, dict) and data.get("status") == "ok" and data.get("database") == "connected" and data.get("service") == "江小摊 AI"
            elif kind == "dashboard":
                data = json.loads(body)
                valid = isinstance(data, dict) and isinstance(data.get("metrics"), dict) and isinstance(data.get("trend"), list)
            elif kind == "html":
                valid = bool(re.search(r'<div\b[^>]*\bid\s*=\s*["\']root["\']', body)) and "/src/main.tsx" in body
            elif kind == "module":
                valid = "createRoot" in body and "import" in body
            elif kind == "built_html":
                valid = bool(re.search(r'<div\b[^>]*\bid\s*=\s*["\']root["\']', body)) and "/assets/" in body
            elif kind == "built_module":
                valid = "javascript" in response.headers.get("Content-Type", "") and len(body) > 100
            else:
                raise ValueError(f"未知检查类型：{kind}")
            return ProbeResult(valid, "HTTP 200，内容检查通过" if valid else "HTTP 200，但响应内容不符合本项目接口或页面")
    except urllib.error.HTTPError as error:
        return ProbeResult(False, f"HTTP {error.code} {error.reason}")
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as error:
        return ProbeResult(False, f"{type(error).__name__}: {error}")


def readiness_checks() -> list[tuple[str, str, str]]:
    backend = f"http://{HOST}:{BACKEND_PORT}"
    frontend = f"http://{HOST}:{FRONTEND_PORT}"
    return [
        ("后端健康检查", backend + "/api/health", "health"),
        ("前端首页", frontend + "/", "html"),
        ("前端入口模块", frontend + "/src/main.tsx", "module"),
        ("前端 API 代理", frontend + "/api/health", "health"),
        ("经营看板接口", frontend + "/api/dashboard", "dashboard"),
    ]


def log_tail(path: Path) -> str:
    try:
        return "\n".join(path.read_text(encoding="utf-8", errors="replace").splitlines()[-10:])
    except OSError:
        return "日志暂不可读。"


def check_processes(services: list[Service]) -> None:
    for service in services:
        code = service.process.poll()
        if code is not None:
            raise RuntimeError(f"{service.name}进程已退出（退出码 {code}）。日志：{service.log_path}\n{log_tail(service.log_path)}")


def wait_for_services(services: list[Service], warning_after: float = 90, checks=None) -> None:
    """超时提示和进程失败分开处理：未就绪不冒充成功，也不误杀活着的服务。"""
    started = time.monotonic()
    next_report = 0.0
    warned = False
    checks = checks if checks is not None else readiness_checks()
    while True:
        check_processes(services)
        failures = []
        for name, url, kind in checks:
            result = probe_http(url, kind)
            if not result.ok:
                failures.append(f"{name} {url}\n  {result.detail}")
        check_processes(services)
        if not failures:
            return
        elapsed = time.monotonic() - started
        if elapsed >= warning_after and not warned:
            print(f"\n等待已超过 {warning_after:g} 秒，以下检查仍未通过。进程将继续运行，保留日志供排查；不会自动关闭，也不会宣称启动成功。", flush=True)
            print("可按 Ctrl+C 停止。日志目录：" + str(ROOT / "artifacts/runtime"), flush=True)
            warned = True
        if elapsed >= next_report:
            print(f"\n正在等待服务就绪（{elapsed:.0f} 秒）：\n" + "\n".join(failures), flush=True)
            next_report = elapsed + 10
        time.sleep(.5)


def follow_log(service: Service) -> None:
    """子进程直接写日志文件，避免未消费的 PIPE 填满后阻塞服务。"""
    with service.log_path.open(encoding="utf-8", errors="replace") as stream:
        while True:
            line = stream.readline()
            if line:
                print(f"[{service.name}] {line.rstrip()}", flush=True)
            elif service.process.poll() is not None:
                return
            else:
                time.sleep(.1)


def launch_service(name: str, command: list[str], cwd: Path, log_path: Path, env: dict[str, str]) -> Service:
    options = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {}
    with log_path.open("w", encoding="utf-8") as output:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, **options)
    service = Service(name, process, log_path)
    threading.Thread(target=follow_log, args=(service,), daemon=True).start()
    return service


def stop_services(services: list[Service]) -> None:
    for service in reversed(services):
        child = service.process
        if child.poll() is not None:
            continue
        try:
            child.send_signal(signal.CTRL_BREAK_EVENT) if os.name == "nt" else child.terminate()
            child.wait(timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            if os.name == "nt":
                # 仅结束本次创建的进程树，兼容 Windows 虚拟环境的 Python 启动器。
                try:
                    subprocess.run(["taskkill.exe", "/PID", str(child.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except OSError:
                    child.kill()
            else:
                child.kill()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                print(f"{service.name}未能及时退出，请检查进程 PID {child.pid}。", file=sys.stderr, flush=True)


def start(node_path: str, no_browser: bool) -> None:
    for port in (BACKEND_PORT, FRONTEND_PORT):
        if not is_port_free(port):
            raise RuntimeError(f"端口 {port} 已被占用。请关闭之前的启动窗口或对应服务后重试。")
    services: list[Service] = []
    log_dir = ROOT / "artifacts/runtime" / datetime_stamp()
    log_dir.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["PATH"] = str(Path(node_path).parent) + os.pathsep + env.get("PATH", "")
    print(f"启动日志目录：{log_dir}\n正在启动后端和前端，首次预构建可能需要一些时间。", flush=True)
    try:
        services.append(launch_service("后端", [str(VENV_PYTHON), "-m", "uvicorn", "app.main:app", "--host", HOST, "--port", str(BACKEND_PORT)], ROOT / "backend", log_dir / "backend.log", env))
        services.append(launch_service("前端", [node_path, "node_modules/vite/bin/vite.js", "--host", HOST, "--port", str(FRONTEND_PORT), "--strictPort"], FRONTEND, log_dir / "frontend.log", env))
        wait_for_services(services)
        print("\n江小摊 AI 已启动：http://127.0.0.1:5173\n后端文档：http://127.0.0.1:8000/docs\n请保留本窗口，按 Ctrl+C 停止两个服务。\n", flush=True)
        if not no_browser:
            try:
                opened = webbrowser.open("http://127.0.0.1:5173")
            except (OSError, webbrowser.Error) as error:
                print(f"自动打开浏览器失败：{error}", flush=True)
                opened = False
            if not opened:
                print("服务继续运行，请手动在浏览器访问 http://127.0.0.1:5173。", flush=True)
        while True:
            check_processes(services)
            time.sleep(.5)
    except KeyboardInterrupt:
        print("\n正在停止江小摊 AI…", flush=True)
    finally:
        stop_services(services)


def datetime_stamp() -> str:
    from datetime import datetime, timedelta, timezone
    return datetime.now(timezone(timedelta(hours=8))).strftime("%Y%m%d-%H%M%S-%f")


def main() -> int:
    # 保证从资源管理器或 PowerShell 启动时中文日志一致。
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    os.environ["PYTHONUTF8"] = "1"
    parser = argparse.ArgumentParser(description="江小摊 AI 项目管理")
    parser.add_argument("action", choices=["install", "start", "check", "build"])
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--direct-download", action="store_true", help="仅本次 Python 依赖安装绕过环境代理，保留证书校验")
    args = parser.parse_args()
    try:
        if sys.version_info < (3, 10):
            raise RuntimeError("请安装 Python 3.10 或以上版本。")
        if args.action == "install":
            install(args.direct_download)
        else:
            node_path = require_dependencies()
            if args.action == "start":
                start(node_path, args.no_browser)
            elif args.action == "check":
                run([str(VENV_PYTHON), "-m", "pytest", "tests", "../tests", "-q"], ROOT / "backend")
                run([node_path, "--test", "tests/money.test.mjs"], FRONTEND)
                build(node_path)
                print("后端测试、TypeScript 检查和前端构建均已通过。", flush=True)
            else:
                build(node_path)
        return 0
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print(f"\n操作未完成：{error}", file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

