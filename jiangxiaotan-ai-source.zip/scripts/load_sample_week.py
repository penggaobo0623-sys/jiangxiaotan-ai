"""明确授权后替换业务记录；先一致性备份，保留模型次数回执与提交凭据。"""
import argparse
from datetime import date, datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
from app.database import connect, initialize
from backup import backup

# 所有名称、价格、销量均为虚构演示，不代表校园商家的实际经营。
MENU = [
    ('烤冷面', 1000, 420, [40,46,42,51,59,66,54]),
    ('鸡蛋煎饼', 800, 310, [28,31,29,35,42,47,38]),
    ('蛋炒饭', 1200, 520, [18,20,17,25,29,33,24]),
    ('炸鸡柳', 800, 360, [22,27,25,31,36,40,30]),
    ('炸土豆', 500, 170, [16,19,18,24,28,32,25]),
    ('章鱼小丸子', 900, 430, [12,15,14,19,21,24,18]),
    ('关东煮', 800, 330, [15,18,16,21,25,29,22]),
    ('原味豆花', 550, 220, [14,17,15,20,23,26,21]),
    ('柠檬茶', 700, 240, [26,30,28,35,43,48,36]),
    ('试卖小串（负毛利示例）', 300, 350, [4,5,4,6,7,9,5]),
]


def snapshot(con, columns=None):
    if columns is None:
        columns = {t: [r[1] for r in con.execute(f'PRAGMA table_info({t})')]
                   for t in ('products','sales_records','expenses','business_days')}
    data = {}
    for table, names in columns.items():
        if names:
            data[table] = [list(r) for r in con.execute(f'SELECT {",".join(names)} FROM {table} ORDER BY 1')]
    return columns, hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def replace_with_samples(path: Path, end: date, backup_directory: Path):
    path = path.resolve()
    saved = backup(path, backup_directory)
    with sqlite3.connect(saved) as old:
        columns, expected = snapshot(old)
        old_counts = {t:old.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
                      for t in ('products','sales_records','expenses')}
    initialize(path)
    days = [(end-timedelta(days=6-i)).isoformat() for i in range(7)]
    with connect(path) as con, con:
        con.execute('BEGIN IMMEDIATE')
        if snapshot(con,columns)[1] != expected:
            raise RuntimeError('备份之后账目发生变化，未替换业务记录；请先核对后再操作。')
        next_ids = {t:con.execute(f'SELECT COALESCE(MAX(id),0)+1 FROM {t}').fetchone()[0]
                    for t in ('products','sales_records','expenses')}
        # 仅替换用户授权的业务表，不重建数据库、不改密钥，不重置费用次数。
        con.execute('DELETE FROM sales_records')
        con.execute('DELETE FROM expenses')
        con.execute('DELETE FROM products')
        con.execute('DELETE FROM business_days')
        con.execute('DELETE FROM model_cache')
        sale_id = next_ids['sales_records']
        for j,(name,price,cost,quantities) in enumerate(MENU):
            pid = next_ids['products']+j
            name = '演示·'+name
            con.execute('INSERT INTO products(id,name,price_cents,unit_cost_cents,is_active) VALUES (?,?,?,?,1)',(pid,name,price,cost))
            for day,quantity in zip(days,quantities):
                con.execute('INSERT INTO sales_records(id,product_id,product_name,business_date,quantity,unit_price_cents,unit_cost_cents) VALUES (?,?,?,?,?,?,?)',
                            (sale_id,pid,name,day,quantity,price,cost))
                sale_id += 1
        expense_id = next_ids['expenses']
        for i,day in enumerate(days):
            for label,amount in [('演示·摊位费',3000),('演示·交通费',[800,800,1000,800,1200,1200,800][i])]:
                con.execute('INSERT INTO expenses(id,business_date,category,amount_cents) VALUES (?,?,?,?)',(expense_id,day,label,amount))
                expense_id += 1
            con.execute("INSERT INTO business_days(business_date,status) VALUES (?,'pending')",(day,))
        con.execute('INSERT INTO record_audit(kind,record_id,action,before_json,after_json) VALUES (?,?,?,?,?)',
                    ('dataset',0,'replace_with_demo',json.dumps(dict(counts=old_counts,backup=str(saved)),ensure_ascii=False),
                     json.dumps(dict(label='虚构演示数据，非真实商家成效',start=days[0],end=days[-1],products=len(MENU),sales=70,expenses=14),ensure_ascii=False)))
        if con.execute('PRAGMA foreign_key_check').fetchall():
            raise RuntimeError('外键检查失败，已回滚。')
    return dict(database=str(path),backup=str(saved),label='虚构演示数据，非真实商家成效',start=days[0],end=days[-1],
                old_counts=old_counts,products=len(MENU),sales=70,expenses=14,
                menu=[dict(name='演示·'+n,price_cents=p,unit_cost_cents=c) for n,p,c,_ in MENU])


if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser(description='先备份，再替换默认商家业务数据为一周虚构演示数据')
    parser.add_argument('--replace-default',action='store_true',help='明确确认替换默认库中的商品、销售、支出和营业状态')
    args=parser.parse_args()
    if not args.replace_default: parser.error('需要 --replace-default 明确确认替换；普通启动不会执行此脚本。')
    result=replace_with_samples(ROOT/'backend/data/jiangxiaotan.db',datetime.now(timezone(timedelta(hours=8))).date(),ROOT/'backups'/'before-sample-week')
    report=ROOT/'artifacts'/'sample-week';report.mkdir(parents=True,exist_ok=True)
    (report/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
