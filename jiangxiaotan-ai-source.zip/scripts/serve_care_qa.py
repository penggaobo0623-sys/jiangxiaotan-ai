"""浏览器验收专用：隔离数据库、强制模拟服务；不读取真实模型密钥。"""
import os
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
os.environ['APP_ENV']='test'
os.environ['AI_MODE']='off'
os.environ['AI_ALLOW_EXTERNAL']='false'
os.environ['AI_API_KEY']=''
os.environ['DATABASE_PATH']=str(ROOT/'artifacts/care/browser.db')
sys.path.insert(0,str(ROOT/'backend'))

from app.main import create_app
from app.model_gateway import ModelSettings
import uvicorn

if __name__=='__main__':
    uvicorn.run(create_app(ROOT/'artifacts/care/browser.db',ModelSettings('mock')),host='127.0.0.1',port=8013)
