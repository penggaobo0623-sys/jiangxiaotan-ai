"""只在专用 demo/data 目录生成演示场景，永不覆盖已有数据库。"""
import argparse
from datetime import date, datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sys
import time
import webbrowser

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
from app.database import connect, initialize
import manage


def prepare(scenario, end):
    directory=ROOT/'demo'/'data'/scenario
    path=directory/'demo.db'
    if path.exists():
        print(f'保留已有演示记录：{path}（不重复插入或重置）',flush=True)
        return path
    directory.mkdir(parents=True,exist_ok=True)
    initialize(path)
    if scenario!='empty':
        with connect(path) as con, con:
            for name,price,cost in [('演示·烤冷面',1000,400),('演示·柠檬茶',700,250),('演示·试做小串',300,350)]:
                con.execute('INSERT INTO products(name,price_cents,unit_cost_cents) VALUES (?,?,?)',(name,price,cost))
            for i in range(7 if scenario=='week' else 2):
                day=(end-timedelta(days=6-i)).isoformat()
                for pid,name,price,cost,qty in [(1,'演示·烤冷面',1000,400,20+i*2),(2,'演示·柠檬茶',700,250,12+i),(3,'演示·试做小串',300,350,2)]:
                    con.execute('INSERT INTO sales_records(product_id,product_name,business_date,quantity,unit_price_cents,unit_cost_cents) VALUES (?,?,?,?,?,?)',(pid,name,day,qty,price,cost))
                if i%2==0: con.execute('INSERT INTO expenses(business_date,category,amount_cents) VALUES (?,?,?)',(day,'演示·摊位费用',1000))
    (directory/'scenario.json').write_text(json.dumps(dict(label='演示数据，非真实商家成效',scenario=scenario,start=(end-timedelta(days=6)).isoformat(),end=end.isoformat()),ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'已创建独立演示库：{path}；窗口结束日期：{end}',flush=True)
    return path


def main():
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'): stream.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser(description='江小摊 AI 独立比赛演示，不操作商家库')
    parser.add_argument('--scenario',choices=['week','sparse','empty'],default='week')
    parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--no-browser',action='store_true')
    parser.add_argument('--real-model',action='store_true',help='仅已有密钥、明确允许费用及后端开关时使用；默认模拟')
    args=parser.parse_args()
    services=[]
    try:
        path=prepare(args.scenario,datetime.now(timezone(timedelta(hours=8))).date())
        if args.prepare_only: return 0
        node=manage.require_dependencies()
        manage.BACKEND_PORT=8002; manage.FRONTEND_PORT=5175
        for port in (8002,5175):
            if not manage.is_port_free(port): raise RuntimeError(f'演示端口 {port} 已占用，请停止旧演示窗口后重试。')
        # 比赛演示使用正式构建，避免开发依赖冷预构建时页面长时间等待。
        manage.build(node)
        env=os.environ.copy()
        env.update(DATABASE_PATH=str(path),APP_ENV='demo',AI_MODE='remote' if args.real_model else 'mock',PYTHONUTF8='1',PYTHONUNBUFFERED='1')
        if not args.real_model: env.update(AI_ALLOW_EXTERNAL='false',AI_API_KEY='',AI_BASE_URL='',AI_MODEL='')
        logs=ROOT/'artifacts'/'runtime'/('demo-'+manage.datetime_stamp());logs.mkdir(parents=True,exist_ok=True)
        services.append(manage.launch_service('演示后端',[str(manage.VENV_PYTHON),'-m','uvicorn','app.main:app','--host','127.0.0.1','--port','8002'],ROOT/'backend',logs/'backend.log',env))
        services.append(manage.launch_service('演示前端',[node,'node_modules/vite/bin/vite.js','preview','--config','vite.demo.config.ts','--host','127.0.0.1','--port','5175','--strictPort'],ROOT/'frontend',logs/'frontend.log',env))
        asset=next((ROOT/'frontend'/'dist'/'assets').glob('*.js')).name
        checks=[('演示后端','http://127.0.0.1:8002/api/health','health'),('演示首页','http://127.0.0.1:5175/','built_html'),('正式脚本','http://127.0.0.1:5175/assets/'+asset,'built_module'),('演示代理','http://127.0.0.1:5175/api/health','health'),('演示看板','http://127.0.0.1:5175/api/dashboard','dashboard')]
        manage.wait_for_services(services,checks=checks)
        print('演示已就绪：http://127.0.0.1:5175/#analysis\n数据为独立演示样本；'+('已选择真实模型配置，点击前请核对费用授权与摘要。' if args.real_model else '当前使用模拟模型，未调用真实模型。')+'\n请保留窗口，Ctrl+C 停止演示。',flush=True)
        if not args.no_browser: webbrowser.open('http://127.0.0.1:5175/#analysis')
        while True:
            manage.check_processes(services);time.sleep(.5)
    except KeyboardInterrupt: print('正在停止本次演示服务…',flush=True)
    except (OSError,RuntimeError) as error:
        print(f'演示未完成：{error}',file=sys.stderr,flush=True);return 1
    finally: manage.stop_services(services)
    return 0


if __name__=='__main__': raise SystemExit(main())
