"""SQLite 一致性只读备份；不提供覆盖或恢复操作。"""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
import sys
import argparse

ROOT=Path(__file__).resolve().parents[1]


def backup(source: Path, directory: Path):
    source=source.resolve()
    if not source.is_file(): raise RuntimeError('源数据库不存在，请先检查路径。')
    directory.mkdir(parents=True,exist_ok=True)
    target=directory/('backup-'+datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d-%H%M%S-%f')+'.db')
    # 独占创建，不覆盖旧备份；SQLite backup 提供一致性快照。
    with target.open('xb'): pass
    with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as src, sqlite3.connect(target) as dst:
        src.backup(dst)
        if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok': raise RuntimeError('备份完整性检查未通过。')
    return target


if __name__=='__main__':
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'): stream.reconfigure(encoding='utf-8')
    p=argparse.ArgumentParser(description='只读备份，不恢复、不覆盖原库或旧备份')
    p.add_argument('--source',type=Path,default=ROOT/'backend/data/jiangxiaotan.db')
    p.add_argument('--output',type=Path,default=ROOT/'backups')
    args=p.parse_args()
    try: print('备份完成：'+str(backup(args.source,args.output)))
    except (OSError,RuntimeError,sqlite3.Error) as e: print('备份未完成：'+str(e),file=sys.stderr);sys.exit(1)
