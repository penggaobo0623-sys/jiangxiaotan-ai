"""2026-10-19 单次人工授权验收：最多三个不同演示场景，不重试、不改.env。

此脚本不是日常启动入口。授权已限定为 week/sparse/marketing 各一次。
调用前先写入保守计数，失败或进程中断也不会重用该次数。
"""
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
sys.path.insert(0,str(ROOT/'scripts'))
RUN=ROOT/'artifacts/deepseek/real-20261019'
DAY=date(2026,10,19)
LIMIT=3


def timestamp():
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


def digest(path):
    if not path.exists(): return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def merchant_digest():
    path=ROOT/'backend/data/jiangxiaotan.db'
    if not path.exists(): return None
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as con:
        rows={t:con.execute(f'SELECT * FROM {t} ORDER BY id').fetchall() for t in ('products','sales_records','expenses')}
    return hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case',required=True,choices=['week','sparse','marketing'])
    parser.add_argument('--authorized-20261019',action='store_true')
    args=parser.parse_args()
    if not args.authorized_20261019:
        print('需要本次明确授权标志；未调用。');return 2
    from app.model_gateway import ModelSettings, CompatibleGateway
    from app.main import create_app
    from fastapi.testclient import TestClient
    import demo

    # 本机dotenv只读取，密钥从不进入输出、文件、命令行或发送内容。
    original=ModelSettings.from_env()
    settings=replace(original,mode='remote',allow_external=True,provider='deepseek',timeout=15,max_output_tokens=1600)
    if not settings.key or settings.model!='deepseek-flash':
        print('密钥缺失或模型不符合本次授权；未调用。');return 2
    if CompatibleGateway(settings).endpoint()!='https://api.deepseek.com/chat/completions':
        print('地址不符合本次官方根地址授权；未调用。');return 2
    RUN.mkdir(parents=True,exist_ok=True)
    ledger_path=RUN/'calls.json'
    lock_path=RUN/'acceptance.lock'
    try: lock_fd=os.open(lock_path,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:
        print('已有验收在执行或曾中断；为避免重复收费，本次不调用。');return 2
    os.close(lock_fd)
    before=dict(env=digest(ROOT/'.env'),merchant=merchant_digest(),cmd={n:digest(ROOT/n) for n in ['start.cmd','setup.cmd','check.cmd','demo.cmd']})
    ledger=[]
    record=None
    def save_json(path,value):
        text=json.dumps(value,ensure_ascii=False,indent=2)
        if settings.key in text: raise RuntimeError('Refusing to persist credential')
        temporary=path.with_suffix(path.suffix+'.tmp')
        temporary.write_text(text,encoding='utf-8');os.replace(temporary,path)
    try:
        ledger=json.loads(ledger_path.read_text(encoding='utf-8')) if ledger_path.exists() else []
        if len(ledger)>=LIMIT or any(r['case']==args.case for r in ledger):
            print('本次授权次数已用完或该场景已尝试；不重试。');return 2
        os.environ['APP_ENV']='demo'
        demo.ROOT=RUN
        scenario='sparse' if args.case=='sparse' else 'week'
        path=demo.prepare(scenario,DAY)
        assert path.resolve().is_relative_to(RUN.resolve())
        with sqlite3.connect(path) as con:
            assert all(name.startswith('演示·') for name, in con.execute('SELECT name FROM products'))
        record=dict(number=len(ledger)+1,case=args.case,authorization_date='2026-10-19',started_at=timestamp(),status='reserved',service='DeepSeek official API',configured_model=settings.model,endpoint='https://api.deepseek.com/chat/completions',timeout_seconds=15,max_output_tokens=1600,request_bytes_limit=60000,demo_db=str(path.relative_to(ROOT)),network_attempts=0,validation_passed=False)
        ledger.append(record)
        # 在任何可能发送网络数据的操作之前持久化一次额度。
        save_json(ledger_path,ledger)

        class OneCallGateway(CompatibleGateway):
            def complete(self,prompt,payload):
                if record['network_attempts']:
                    raise RuntimeError('禁止重试或追加调用')
                record['network_attempts']=1
                record['status']='attempting'
                request=dict(model=settings.model,messages=[dict(role='system',content=prompt),dict(role='user',content=json.dumps(payload,ensure_ascii=False))],stream=False,max_tokens=1600,thinking={'type':'disabled'},response_format={'type':'json_object'})
                record['request_bytes']=len(json.dumps(request,ensure_ascii=False).encode())
                assert record['request_bytes']<=60000
                save_json(RUN/f'{args.case}-sent-summary.json',payload)
                save_json(ledger_path,ledger)
                try: return super().complete(prompt,payload)
                finally:
                    record['call']=self.last_call
                    save_json(ledger_path,ledger)
        gateway=OneCallGateway(settings)
        started=time.monotonic()
        with TestClient(create_app(path,settings,gateway)) as c:
            if args.case in ('week','sparse'):
                preview=c.get('/api/analysis/preview',params=dict(business_date=DAY.isoformat()))
                assert preview.status_code==200
                summary=preview.json()['summary']
                assert summary['coverage']['sales_days']==(7 if args.case=='week' else 2)
                assert summary['totals']['order_count'] is None
                save_json(RUN/f'{args.case}-preview.json',preview.json())
                response=c.post('/api/analysis',json=dict(business_date=DAY.isoformat(),summary_hash=summary['fingerprint'],use_model=True,consent_to_send=True))
                result=response.json()
                if result.get('source')=='model':
                    assert result['summary']==summary
                    assert all(f['evidence'] and f['period']==summary['period'] and f['limitation'] for f in result['findings'])
                    if args.case=='sparse':
                        assert len(summary['coverage']['missing_sales_dates'])==5
                        assert 'comparison' not in [f['id'] for f in result['findings']]
            else:
                product=next(p for p in c.get('/api/products').json() if p['is_active'] and p['name']=='演示·烤冷面')
                body=dict(product_id=product['id'],expected_price_cents=product['price_cents'],price_confirmed=True,feature='现点现做',feature_confirmed=True,theme='校园日常',channel='朋友圈',offer_kind='none')
                preview=c.post('/api/marketing/preview',json=body)
                assert preview.status_code==200
                save_json(RUN/'marketing-preview.json',preview.json())
                response=c.post('/api/marketing',json={**body,'facts_hash':preview.json()['facts']['fingerprint'],'use_model':True,'consent_to_send':True})
                result=response.json()
                if result.get('source')=='model':
                    assert result['facts']==preview.json()['facts']
                    assert product['name'] in result['draft'] and '10.00 元' in result['draft']
                    assert result['facts']['offer'] is None
            record['local_api_status']=response.status_code
            record['source']=result.get('source')
            record['reason']=result.get('reason',result.get('detail'))
            record['call']=result.get('call',record.get('call'))
            record['validation_passed']=response.status_code==200 and result.get('source')=='model' and bool((result.get('call') or {}).get('validation_passed'))
            record['status']='passed' if record['validation_passed'] else 'failed_or_fallback'
            record['elapsed_ms']=round((time.monotonic()-started)*1000)
            record['completed_at']=timestamp()
            # 仅保存经过业务层处理的结果，不保存未校验模型原文或思考内容。
            save_json(RUN/f'{args.case}-result.json',result)
        return 0 if record['validation_passed'] else 1
    except Exception as error:
        if record:
            record['status']='interrupted_or_local_validation_failed'
            record['error_type']=type(error).__name__
            record['completed_at']=timestamp()
        print('验收未完成，异常类型：'+type(error).__name__+'；没有自动重试。')
        return 1
    finally:
        after=dict(env=digest(ROOT/'.env'),merchant=merchant_digest(),cmd={n:digest(ROOT/n) for n in ['start.cmd','setup.cmd','check.cmd','demo.cmd']})
        protection=dict(env_unchanged=before['env']==after['env'],merchant_unchanged=before['merchant']==after['merchant'],cmd_unchanged=before['cmd']==after['cmd'])
        save_json(RUN/'protection.json',protection)
        if record:
            record['protection']=protection
            save_json(ledger_path,ledger)
            print(json.dumps(record,ensure_ascii=True))
        lock_path.unlink()


if __name__=='__main__':
    for stream in (sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'): stream.reconfigure(encoding='utf-8')
    raise SystemExit(main())
