import { useEffect, useMemo, useRef, useState } from 'react'
import { Copy, LoaderCircle, Sparkles } from 'lucide-react'
import { getJson, money } from './api'
import type { Product } from './api'
import { centsToYuan, yuanToCents } from './money'
import { ModelCall } from './ModelCall'
import type { CallInfo } from './ModelCall'
import { UsageNotice } from './Care'
import type { UsagePolicy } from './Care'
import { useUnsaved } from './unsaved'

interface Config { usage_policy?: UsagePolicy; model_available: boolean; model_mode: string; model_label: string; notice: string | null }
interface Preview { facts: { fingerprint: string; product_name: string; price_cents: number; feature: string; theme: string; channel: string; style: string; offer: { price_cents: number; start: string; end: string } | null }; disclosure: string }
interface Draft { usage_policy?: UsagePolicy; source_label: string; reason: string; draft: string; review_notice: string; call?: CallInfo | null }

export function MarketingPage({ revision }: { revision: number }) {
  const [products, setProducts] = useState<Product[]>([])
  const [config, setConfig] = useState<Config | null>(null)
  const [loading, setLoading] = useState(true)
  const [reload, setReload] = useState(0)
  const [id, setId] = useState('')
  const [feature, setFeature] = useState('')
  const [priceConfirmed, setPriceConfirmed] = useState(false)
  const [featureConfirmed, setFeatureConfirmed] = useState(false)
  const [theme, setTheme] = useState('校园日常')
  const [style, setStyle] = useState('校园日常')
  const [edited, setEdited] = useState(false)
  const [channel, setChannel] = useState('朋友圈')
  const [offer, setOffer] = useState(false)
  const [offerPrice, setOfferPrice] = useState('')
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')
  const [offerConfirmed, setOfferConfirmed] = useState(false)
  const [preview, setPreview] = useState<Preview | null>(null)
  const [draft, setDraft] = useState<Draft | null>(null)
  const [consent, setConsent] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState('')
  const inFlight = useRef(false)
  const lastGeneration = useRef(0)
  const copyRef = useRef<HTMLTextAreaElement>(null)
  const product = products.find(p => String(p.id) === id && p.is_active)
  useEffect(() => {
    const controller = new AbortController(); setLoading(true); setError('')
    const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(8000)])
    Promise.all([getJson<Product[]>('/api/products', signal), getJson<Config>('/api/marketing/config', signal)])
      .then(([p, c]) => { if (!controller.signal.aborted) { setProducts(p); setConfig(c); setPriceConfirmed(false) } })
      .catch(() => { if (!controller.signal.aborted) setError('商品或模型状态读取失败，请检查连接后重新读取。') })
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [revision, reload])
  const formKey = JSON.stringify([id, product?.name, product?.price_cents, feature, priceConfirmed, featureConfirmed, theme, style, channel, offer, offerPrice, start, end, offerConfirmed])
  useEffect(() => { setPreview(null); setDraft(null); setConsent(false); setCopied('') }, [formKey])
  const body = useMemo(() => ({ product_id: Number(id), expected_price_cents: product?.price_cents, price_confirmed: priceConfirmed, feature, feature_confirmed: featureConfirmed, theme, style, channel, offer_kind: offer ? 'special_price' : 'none', offer_price_cents: offer ? yuanToCentsSafe(offerPrice) : null, start_date: offer ? start || null : null, end_date: offer ? end || null : null, offer_confirmed: offer && offerConfirmed }), [formKey])
  async function request(path: string, payload: unknown) {
    const response = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(30000), body: JSON.stringify(payload) })
    const result = await response.json().catch(() => { throw new Error('服务响应无法读取，请检查连接并重新核对；不要连续生成。') })
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : '输入不符合要求，请核对后重试。')
    return result
  }
  async function prepare(event: React.FormEvent) {
    event.preventDefault(); if (inFlight.current) return
    inFlight.current = true; setBusy(true); setError(''); setDraft(null)
    try {
      if (offer) yuanToCents(offerPrice)
      setPreview(await request('/api/marketing/preview', body) as Preview); setConsent(false)
    } catch (cause) { setError(cause instanceof TypeError ? '无法连接后端，请恢复连接后重新预览。' : cause instanceof Error && cause.name !== 'TimeoutError' ? cause.message : '预览请求超时，请检查连接后重新预览。') }
    finally { inFlight.current = false; setBusy(false) }
  }
  async function generate(useModel: boolean) {
    const regenerate = !!draft && useModel
    if (regenerate && config?.model_mode === 'remote' && !window.confirm('重新生成会跳过缓存，可能再次收费，确认继续？')) return
    if (!preview || inFlight.current) return
    if (Date.now() - lastGeneration.current < 1200) return
    lastGeneration.current = Date.now()
    inFlight.current = true; setBusy(true); setError(''); setDraft(null); setCopied(''); setEdited(false)
    try { setDraft(await request('/api/marketing', { ...body, facts_hash: preview.facts.fingerprint, use_model: useModel, consent_to_send: consent, regenerate }) as Draft) }
    catch (cause) { setError(cause instanceof TypeError ? '无法连接后端。请求可能已发送，请恢复连接后核对，避免重复调用。' : cause instanceof Error && cause.name !== 'TimeoutError' ? cause.message : '生成请求未完成，请稍后核对，避免连续调用。') }
    finally { inFlight.current = false; setBusy(false) }
  }
  useUnsaved(edited)
  async function copy() {
    if (!draft) return
    try { await navigator.clipboard.writeText(draft.draft); setCopied('已复制草稿，请核对后使用。') }
    catch { copyRef.current?.focus(); copyRef.current?.select(); setCopied('浏览器未允许自动复制。已选中文案，请按 Ctrl+C 或长按复制。') }
  }
  return <section className="analysis-page marketing-page">
    <form className="card analysis-intro" onSubmit={prepare}>
      <div className="section-title"><h2>先确认商品事实</h2><button type="button" className="text-button" disabled={busy || loading} onClick={() => setReload(n => n + 1)}>重新读取商品</button></div>
      {loading ? <p role="status">正在读取商品…</p> : !products.some(p => p.is_active) && <p>暂无使用中的商品，请先到<a href="#products">商品管理</a>创建或启用商品。</p>}
      <fieldset disabled={busy || loading} className="marketing-fields">
        <label className="form-field"><span>推广商品</span><select required value={id} onChange={e => { setId(e.target.value); setPriceConfirmed(false) }}><option value="">请选择商品</option>{products.filter(p => p.is_active).map(p => <option key={p.id} value={p.id}>{p.name} · {money(p.price_cents)}</option>)}</select></label>
        {product && <p>当前售价：<strong>{centsToYuan(product.price_cents)} 元</strong>。生成期间价格变化时，需要重新确认。</p>}
        <label className="check-field"><input type="checkbox" checked={priceConfirmed} onChange={e => setPriceConfirmed(e.target.checked)} />我已核对商品名称和当前售价</label>
        <label className="form-field"><span>商品特色（可选）</span><input maxLength={60} value={feature} placeholder="例如：现点现做、微辣口味" onChange={e => { setFeature(e.target.value); setFeatureConfirmed(false) }} /></label>
        <p className="form-hint">填写你能确认的口味或制作方式，可以描述已确认的数量属性；价格与活动走下方专门字段，不虚构销量、排名或功效。</p>
        {!!feature.trim() && <label className="check-field"><input type="checkbox" checked={featureConfirmed} onChange={e => setFeatureConfirmed(e.target.checked)} />我确认所填特色真实准确</label>}
        <div className="form-grid"><label className="form-field"><span>宣传主题</span><input list="theme-options" maxLength={40} required value={theme} onChange={e => setTheme(e.target.value)} /><datalist id="theme-options">{['校园日常','午餐时段','晚餐时段'].map(t => <option key={t}>{t}</option>)}</datalist></label><label className="form-field"><span>使用场景</span><select value={channel} onChange={e => setChannel(e.target.value)}><option>朋友圈</option><option>摊位海报</option><option>小红书</option></select></label></div>
        <label className="form-field"><span>表达风格</span><select value={style} onChange={e => setStyle(e.target.value)}>{['校园日常','商品介绍','收摊随记'].map(t => <option key={t}>{t}</option>)}</select></label><p className="form-hint">收摊随记也不会编造卖光、顾客评价或商家经历。主题只影响语气，不代表活动已发生。</p>
        <label className="check-field"><input type="checkbox" checked={offer} onChange={e => setOffer(e.target.checked)} />添加商家已确认的活动价</label>
        {offer && <div className="form-grid"><label className="form-field"><span>活动价（元）</span><input required inputMode="decimal" value={offerPrice} onChange={e => { setOfferPrice(e.target.value); setOfferConfirmed(false) }} /></label><label className="form-field"><span>活动开始日期</span><input required type="date" min="2000-01-01" max="2100-12-31" value={start} onChange={e => { setStart(e.target.value); setOfferConfirmed(false) }} /></label><label className="form-field"><span>活动结束日期</span><input required type="date" min="2000-01-01" max="2100-12-31" value={end} onChange={e => { setEnd(e.target.value); setOfferConfirmed(false) }} /></label><label className="check-field"><input type="checkbox" checked={offerConfirmed} onChange={e => setOfferConfirmed(e.target.checked)} />我确认活动价格及日期真实有效</label></div>}
        <button className="button primary" disabled={!product || !priceConfirmed || (!!feature.trim() && !featureConfirmed) || (offer && !offerConfirmed)}>确认信息并预览</button>
      </fieldset>
    </form>
    {error && <p className="form-error" role="alert">{error}</p>}
    {preview && <article className="card analysis-source"><h2>本次生成内容</h2><p>{preview.facts.product_name} · {money(preview.facts.price_cents)} · {preview.facts.feature || '未填写特色'} · {preview.facts.theme} · {preview.facts.style} · {preview.facts.channel}</p>{preview.facts.offer && <p>活动价 {money(preview.facts.offer.price_cents)}，{preview.facts.offer.start} 至 {preview.facts.offer.end}</p>}<p>{preview.disclosure}</p><UsageNotice policy={draft?.usage_policy ?? config?.usage_policy} /><p>当前模型：{config?.model_label}。{config?.notice}</p>
      {config?.model_available && <label className="check-field"><input type="checkbox" checked={consent} disabled={busy} onChange={e => setConsent(e.target.checked)} />{config.model_mode === 'mock' ? '我知道这是模拟模型，不会发送到外部服务' : '我同意发送以上商品信息并了解可能产生费用'}</label>}
      <div className="form-actions"><button className="button primary" disabled={busy || (!!config?.model_available && !consent)} onClick={() => generate(true)}>{busy ? <LoaderCircle className="spin" size={15} /> : <Sparkles size={15} />}{busy ? '正在生成…' : draft ? '重新生成草稿' : '生成文案草稿'}</button><button className="button secondary" disabled={busy} onClick={() => generate(false)}>仅本机模板（不发送）</button></div>
    </article>}
    {draft && <article className="card analysis-finding" aria-live="polite"><h2>{draft.source_label}</h2><p>{draft.reason}</p><ModelCall call={draft.call} /><label className="form-field"><span>待审核文案</span><textarea ref={copyRef} rows={9} value={draft.draft} onChange={e => { setDraft({ ...draft, draft: e.target.value }); setEdited(true); setCopied('') }} /></label>{edited && <p className="analysis-warning">已自行编辑：此版本尚未经后端校验，请核对后使用。</p>}<button className="button primary" onClick={copy}><Copy size={15} />复制文案</button><p role="status">{copied}</p><p className="analysis-warning">{draft.review_notice}</p></article>}
  </section>
}

function yuanToCentsSafe(value: string) { try { return yuanToCents(value) } catch { return null } }
