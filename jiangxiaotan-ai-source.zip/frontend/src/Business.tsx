import { useEffect, useRef, useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import { Check, LoaderCircle, Pencil, Plus, RefreshCw, Trash2, X } from 'lucide-react'
import { getJson, money, mutate } from './api'
import type { Product, Sale, Expense, History } from './api'
import { centsToYuan, yuanToCents } from './money'
import { ClosingForm, DayStatus, Recovery } from './Care'
import { useUnsaved } from './unsaved'
import { ConfirmDialog } from './Confirmation'

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="form-field"><span>{label}</span>{children}</label>
}
function Amount({ value, onChange }: { value: string; onChange: (text: string) => void }) {
  return <input required inputMode="decimal" placeholder="例如 10.50" maxLength={16} value={value} onChange={event => onChange(event.target.value)} />
}
function DateInput({ value, onChange }: { value: string; onChange: (text: string) => void }) {
  return <input required type="date" min="2000-01-01" max="2100-12-31" value={value} onChange={event => onChange(event.target.value)} />
}

interface BusinessProps { revision: number; onSaved: (message: string, day?: string) => void }

export function ProductsPage({ revision, onSaved }: BusinessProps) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const busyRef = useRef(false)
  const [edit, setEdit] = useState<Product | null>(null)
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')
  const [cost, setCost] = useState('')
  const [active, setActive] = useState(true)
  const [toggle, setToggle] = useState<Product | null>(null)
  const [toggleError, setToggleError] = useState('')
  const formRef = useRef<HTMLFormElement>(null)
  const [reload, setReload] = useState(0)
  useEffect(() => {
    const controller = new AbortController(); setLoading(true); setLoadError('')
    getJson<Product[]>('/api/products', AbortSignal.any([controller.signal, AbortSignal.timeout(8000)]))
      .then(data => { if (!controller.signal.aborted) setProducts(data) })
      .catch(() => { if (!controller.signal.aborted) setLoadError('商品列表读取失败，请检查服务连接后重试。') })
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [revision, reload])
  useUnsaved(edit ? name !== edit.name || price !== centsToYuan(edit.price_cents) || cost !== centsToYuan(edit.unit_cost_cents) || active !== edit.is_active : !!(name || price || cost))
  const reset = () => { setEdit(null); setName(''); setPrice(''); setCost(''); setActive(true); setError('') }
  const editProduct = (product: Product) => {
    setEdit(product); setName(product.name); setPrice(centsToYuan(product.price_cents)); setCost(centsToYuan(product.unit_cost_cents)); setActive(product.is_active); setError('')
    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }
  async function save(event: FormEvent) {
    event.preventDefault(); if (busyRef.current) return; busyRef.current = true; setError(''); setBusy(true)
    try {
      await mutate<Product>(edit ? `/api/products/${edit.id}` : '/api/products', edit ? 'PUT' : 'POST', { name: name.trim(), price_cents: yuanToCents(price), unit_cost_cents: yuanToCents(cost), is_active: active })
      reset(); onSaved(edit ? '商品已修改，历史销售快照保持原样' : '商品已创建，可以开始记营业记录')
    } catch (cause) { setError(cause instanceof Error ? cause.message : '保存失败') }
    finally { busyRef.current = false; setBusy(false) }
  }
  async function confirmToggle() {
    if (!toggle || busyRef.current) return; busyRef.current = true; setBusy(true); setToggleError('')
    try {
      await mutate(`/api/products/${toggle.id}`, 'PUT', { name: toggle.name, price_cents: toggle.price_cents, unit_cost_cents: toggle.unit_cost_cents, is_active: !toggle.is_active })
      if (edit?.id === toggle.id) reset()
      setToggle(null); onSaved(toggle.is_active ? '商品已停用，历史记录仍保留' : '商品已启用')
    } catch (cause) { setToggleError(cause instanceof Error ? cause.message : '操作失败') }
    finally { busyRef.current = false; setBusy(false) }
  }
  return <section className="business-page">
    <div className="business-intro"><span>先整理商品，再记下生意</span><a className="button primary" href="#records">去记营业记录 <Plus size={15} /></a></div>
    <form ref={formRef} className="card business-form" onSubmit={save}><fieldset className="business-fieldset" disabled={busy}><div className="section-title"><h2>{edit ? '编辑商品' : '新增商品'}</h2>{edit && <button type="button" className="text-button" onClick={reset} disabled={busy}><X size={14} />取消编辑</button>}</div>
      <div className="form-grid product-fields"><Field label="商品名称"><input required maxLength={60} placeholder="例如：招牌烤冷面" value={name} onChange={event => setName(event.target.value)} /></Field><Field label="售价（元）"><Amount value={price} onChange={setPrice} /></Field><Field label="单位成本（元）"><Amount value={cost} onChange={setCost} /></Field></div>
      <label className="check-field"><input type="checkbox" checked={active} onChange={event => setActive(event.target.checked)} />允许新增该商品的销售记录</label>
      <details className="cost-help"><summary>单位成本怎么填？</summary><p>按每份可售商品估算原料、包装等成本，并明确哪些已经计入。已计入单位成本的费用不要再填额外支出；采购付款不等于当日已售商品成本。尚未录入的人工、损耗等不会自动包含在估算中。</p></details><p className="form-hint">{edit ? `已有 ${edit.sales_record_count} 条关联销售记录。改名、改价、改成本或停用，都不会修改历史快照。` : '售价和成本可以为 0。成本应按每份商品估算，额外经营支出在记账页单独填写。'}</p>
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="button primary" disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <Check size={15} />}{busy ? '正在保存…' : edit ? '保存商品修改' : '创建商品'}</button>
    </fieldset></form>
    <div className="section-title"><h2>我的商品 · {products.length} 款</h2><button className="text-button" disabled={loading} onClick={() => setReload(value => value + 1)}><RefreshCw size={14} />刷新列表</button></div>
    {loading ? <p className="list-state">正在读取商品…</p> : loadError ? <p className="form-error" role="alert">{loadError}</p> : !products.length ? <div className="card list-state">还没有商品。填写上方信息，创建你的第一款商品。</div> : <div className="product-list">{products.map(product => <article className={`card product-item ${!product.is_active ? 'inactive-product' : ''}`} key={product.id}><div className="product-item-title"><h3>{product.name}</h3><span className={`connection-pill ${product.is_active ? 'connected' : ''}`}>{product.is_active ? '使用中' : '已停用'}</span></div><dl><div><dt>售价</dt><dd>{money(product.price_cents)}</dd></div><div><dt>单位成本</dt><dd>{money(product.unit_cost_cents)}</dd></div><div><dt>单位估算毛利</dt><dd>{money(product.price_cents - product.unit_cost_cents)}</dd></div></dl><p className="form-hint">{product.sales_record_count} 条历史销售记录</p><div className="form-actions"><button className="button secondary" disabled={busy} onClick={() => editProduct(product)} aria-label={`编辑商品 ${product.name}`}><Pencil size={14} />编辑</button><button className="text-button" disabled={busy} onClick={() => { setToggle(product); setToggleError('') }} aria-label={`${product.is_active ? '停用' : '启用'}商品 ${product.name}`}>{product.is_active ? '停用商品' : '重新启用'}</button></div></article>)}</div>}
    {toggle && <ConfirmDialog message={toggle.is_active ? `停用「${toggle.name}」后不能新增该商品销售；已有销售和统计仍保留，可继续编辑历史记录。` : `启用「${toggle.name}」后可继续录入销售。历史快照保持原样。`} busy={busy} error={toggleError} onCancel={() => setToggle(null)} onConfirm={confirmToggle} />}
  </section>
}

export function RecordsPage({ day, revision, onSaved }: BusinessProps & { day: string }) {
  const [products, setProducts] = useState<Product[]>([])
  const [history, setHistory] = useState<History | null>(null)
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [reload, setReload] = useState(0)
  const [busy, setBusy] = useState(false)
  const busyRef = useRef(false)
  const [saleError, setSaleError] = useState('')
  const [expenseError, setExpenseError] = useState('')
  const [saleEdit, setSaleEdit] = useState<Sale | null>(null)
  const [expenseEdit, setExpenseEdit] = useState<Expense | null>(null)
  const [productId, setProductId] = useState('')
  const [quantity, setQuantity] = useState('')
  const [saleDay, setSaleDay] = useState(day)
  const [snapshotName, setSnapshotName] = useState('')
  const [snapshotPrice, setSnapshotPrice] = useState('')
  const [snapshotCost, setSnapshotCost] = useState('')
  const [expenseDay, setExpenseDay] = useState(day)
  const [category, setCategory] = useState('')
  const [amount, setAmount] = useState('')
  const [remove, setRemove] = useState<{ kind: 'sales' | 'expenses'; id: number; description: string } | null>(null)
  const [deleteError, setDeleteError] = useState('')
  const salesRef = useRef<HTMLFormElement>(null)
  const expenseRef = useRef<HTMLFormElement>(null)
  const clearSale = () => { setSaleEdit(null); setQuantity(''); setSaleDay(day); setSaleError('') }
  const clearExpense = () => { setExpenseEdit(null); setCategory(''); setAmount(''); setExpenseDay(day); setExpenseError('') }
  useEffect(() => { setSaleEdit(null); setExpenseEdit(null); setSaleDay(day); setExpenseDay(day); setQuantity(''); setCategory(''); setAmount(''); setSaleError(''); setExpenseError('') }, [day])
  useEffect(() => {
    const controller = new AbortController(); setLoading(true); setLoadError('')
    const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(8000)])
    Promise.all([getJson<Product[]>('/api/products', signal), getJson<History>(`/api/records?business_date=${day}`, signal)])
      .then(([items, records]) => { if (!controller.signal.aborted) { setProducts(items); setHistory(records); setProductId(value => items.some(product => product.is_active && String(product.id) === value) ? value : '') } })
      .catch(() => { if (!controller.signal.aborted) { setHistory(null); setLoadError('营业记录读取失败，请检查服务连接后刷新。') } })
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [day, revision, reload])
  useUnsaved(!!quantity || !!category || !!amount)
  const selected = products.find(product => String(product.id) === productId && product.is_active)
  async function saveSale(event: FormEvent) {
    event.preventDefault(); if (busyRef.current) return; busyRef.current = true; setBusy(true); setSaleError('')
    try {
      if (!/^\d+$/.test(quantity) || Number(quantity) < 1 || Number(quantity) > 100_000) throw new Error('销量请填写 1–100000 之间的整数')
      const payload = saleEdit ? { business_date: saleDay, quantity: Number(quantity), product_name: snapshotName.trim(), unit_price_cents: yuanToCents(snapshotPrice), unit_cost_cents: yuanToCents(snapshotCost) } : { business_date: saleDay, quantity: Number(quantity), product_id: Number(productId) }
      await mutate<Sale>(saleEdit ? `/api/sales/${saleEdit.id}` : '/api/sales', saleEdit ? 'PUT' : 'POST', payload)
      clearSale(); onSaved(saleEdit ? '销售记录已修改，看板已重新计算' : '销售记录已保存，看板已更新', saleDay)
    } catch (cause) { setSaleError(cause instanceof Error ? cause.message : '保存失败') }
    finally { busyRef.current = false; setBusy(false) }
  }
  async function saveExpense(event: FormEvent) {
    event.preventDefault(); if (busyRef.current) return; busyRef.current = true; setBusy(true); setExpenseError('')
    try {
      const cents = yuanToCents(amount); if (cents <= 0) throw new Error('额外支出必须大于 0 元')
      await mutate(expenseEdit ? `/api/expenses/${expenseEdit.id}` : '/api/expenses', expenseEdit ? 'PUT' : 'POST', { business_date: expenseDay, category: category.trim(), amount_cents: cents })
      clearExpense(); onSaved(expenseEdit ? '支出记录已修改，看板已重新计算' : '支出已保存，看板已更新', expenseDay)
    } catch (cause) { setExpenseError(cause instanceof Error ? cause.message : '保存失败') }
    finally { busyRef.current = false; setBusy(false) }
  }
  const editSale = (sale: Sale) => {
    setSaleEdit(sale); setSaleDay(sale.business_date); setQuantity(String(sale.quantity)); setSnapshotName(sale.product_name); setSnapshotPrice(centsToYuan(sale.unit_price_cents)); setSnapshotCost(centsToYuan(sale.unit_cost_cents)); setSaleError(''); salesRef.current?.closest('details')?.setAttribute('open', ''); salesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }
  const editExpense = (expense: Expense) => {
    setExpenseEdit(expense); setExpenseDay(expense.business_date); setCategory(expense.category); setAmount(centsToYuan(expense.amount_cents)); setExpenseError(''); expenseRef.current?.closest('details')?.setAttribute('open', ''); expenseRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }
  async function confirmDelete() {
    if (!remove || busyRef.current) return; busyRef.current = true; setBusy(true); setDeleteError('')
    try {
      await mutate(`/api/${remove.kind}/${remove.id}`, 'DELETE')
      if (remove.kind === 'sales' && saleEdit?.id === remove.id) clearSale()
      if (remove.kind === 'expenses' && expenseEdit?.id === remove.id) clearExpense()
      setRemove(null); onSaved('记录已删除，历史与看板已刷新')
    } catch (cause) { setDeleteError(cause instanceof Error ? cause.message : '删除失败') }
    finally { busyRef.current = false; setBusy(false) }
  }
  return <section className="business-page">
    <div className="business-intro"><span>记销售、记支出，都以实际发生的数据为准。</span><a className="text-button" href="#products">管理商品 →</a></div>
    {loadError && <div className="form-error" role="alert">{loadError}<button className="text-button" onClick={() => setReload(value => value + 1)}>重新读取</button></div>}
    <DayStatus day={day} revision={revision} onSaved={onSaved} />
    <ClosingForm key={day} day={day} revision={revision} onSaved={onSaved} />
    <details className="card care-card"><summary>逐条补记或编辑历史</summary>
    <div className="record-forms">
      <form ref={salesRef} className="card business-form" onSubmit={saveSale}><fieldset className="business-fieldset" disabled={busy}><div className="section-title"><h2>{saleEdit ? '编辑销售快照' : '记一笔销售'}</h2>{saleEdit && <button type="button" className="text-button" disabled={busy} onClick={clearSale}>取消编辑</button>}</div>
        <div className="form-grid"><Field label="销售营业日期"><DateInput value={saleDay} onChange={setSaleDay} /></Field>{saleEdit ? <Field label="商品名称快照"><input required maxLength={60} value={snapshotName} onChange={event => setSnapshotName(event.target.value)} /></Field> : <Field label="选择商品"><select required value={productId} onChange={event => setProductId(event.target.value)}><option value="">请选择使用中的商品</option>{products.filter(product => product.is_active).map(product => <option value={product.id} key={product.id}>{product.name} · {money(product.price_cents)}</option>)}</select></Field>}
        <Field label="销售数量"><input required inputMode="numeric" pattern="[0-9]+" maxLength={6} placeholder="例如：20" value={quantity} onChange={event => setQuantity(event.target.value)} /></Field>
        {saleEdit && <><Field label="售价快照（元）"><Amount value={snapshotPrice} onChange={setSnapshotPrice} /></Field><Field label="单位成本快照（元）"><Amount value={snapshotCost} onChange={setSnapshotCost} /></Field></>}</div>
        <p className="form-hint">{saleEdit ? '仅更正这一条历史快照，不修改商品资料或其他记录；关联商品编号保持不变。' : selected ? `当前售价 ${money(selected.price_cents)}，单位成本 ${money(selected.unit_cost_cents)}。后端将保存提交时的商品信息快照。` : <>尚无可选商品时，先到<a href="#products">商品管理</a>创建或启用商品。</>}</p>
        {saleError && <p className="form-error" role="alert">{saleError}</p>}<button className="button primary" disabled={busy || loading || !!loadError || (!saleEdit && !selected)}><Check size={15} />{busy ? '处理中…' : saleEdit ? '保存销售修改' : '保存销售'}</button>
      </fieldset></form>
      <form ref={expenseRef} className="card business-form" onSubmit={saveExpense}><fieldset className="business-fieldset" disabled={busy}><div className="section-title"><h2>{expenseEdit ? '编辑额外支出' : '记一笔额外支出'}</h2>{expenseEdit && <button type="button" className="text-button" disabled={busy} onClick={clearExpense}>取消编辑</button>}</div><div className="form-grid"><Field label="支出营业日期"><DateInput value={expenseDay} onChange={setExpenseDay} /></Field><Field label="支出说明"><input required maxLength={60} placeholder="例如：摊位费、交通费" value={category} onChange={event => setCategory(event.target.value)} /></Field><Field label="支出金额（元）"><Amount value={amount} onChange={setAmount} /></Field></div><p className="form-hint">只填额外支出，商品单位成本已在销售中计算，请勿重复记入。</p>{expenseError && <p className="form-error" role="alert">{expenseError}</p>}<button className="button primary" disabled={busy || loading || !!loadError}><Check size={15} />{busy ? '处理中…' : expenseEdit ? '保存支出修改' : '保存支出'}</button></fieldset></form>
    </div>
    </details>
    <div className="section-title"><div><h2>{day} · 营业历史</h2><p className="form-hint">日期修改后会切换到保存日期；同一天可以有多条销售记录，条数不代表订单数。</p></div><a className="button secondary" href="#dashboard">查看当日看板</a></div>
    {loading ? <p className="list-state">正在读取历史…</p> : !history ? <p className="list-state">暂无可用的历史响应，请重新读取。</p> : <>
      <section className="card history-section"><h2>销售记录 · {history.sales.length} 条</h2>{!history.sales.length ? <p className="list-state">这一天没有销售记录，不推断为零销售。</p> : <div className="history-list">{history.sales.map(sale => <article className="history-item" key={sale.id}><div><h3>{sale.product_name}</h3><p className="form-hint">销量 {sale.quantity} · 售价快照 {money(sale.unit_price_cents)} · 单位成本快照 {money(sale.unit_cost_cents)}</p><div className="record-amounts"><span>销售额 <strong>{money(sale.revenue_cents)}</strong></span><span>估算毛利 <strong>{money(sale.gross_profit_cents)}</strong></span></div></div><div className="record-actions"><button disabled={busy} className="button secondary" onClick={() => editSale(sale)} aria-label={`编辑销售 ${sale.product_name}`}><Pencil size={14} />编辑</button><button disabled={busy} className="text-button delete-button" onClick={() => { setRemove({ kind: 'sales', id: sale.id, description: `确定删除 ${sale.business_date} 的「${sale.product_name}」销售记录吗？数量 ${sale.quantity}，销售额 ${money(sale.revenue_cents)}。删除后移入当日回收区，可以恢复；历史与看板会重新计算。` }); setDeleteError('') }} aria-label={`删除销售 ${sale.product_name}`}><Trash2 size={14} />删除</button></div></article>)}</div>}</section>
      <section className="card history-section"><h2>额外支出 · {history.expenses.length} 条</h2>{!history.expenses.length ? <p className="list-state">这一天暂无额外支出记录。</p> : <div className="history-list">{history.expenses.map(expense => <article className="history-item" key={expense.id}><div><h3>{expense.category}</h3><p className="record-amounts">已记录支出 <strong>{money(expense.amount_cents)}</strong></p></div><div className="record-actions"><button disabled={busy} className="button secondary" onClick={() => editExpense(expense)} aria-label={`编辑支出 ${expense.category}`}><Pencil size={14} />编辑</button><button disabled={busy} className="text-button delete-button" onClick={() => { setRemove({ kind: 'expenses', id: expense.id, description: `确定删除 ${expense.business_date} 的「${expense.category}」支出 ${money(expense.amount_cents)} 吗？删除后移入当日回收区，可以恢复；历史与看板会重新计算。` }); setDeleteError('') }} aria-label={`删除支出 ${expense.category}`}><Trash2 size={14} />删除</button></div></article>)}</div>}</section>
    </>}
    <Recovery day={day} revision={revision} onSaved={onSaved} />
    {remove && <ConfirmDialog message={remove.description} busy={busy} error={deleteError} onCancel={() => setRemove(null)} onConfirm={confirmDelete} />}
  </section>
}
