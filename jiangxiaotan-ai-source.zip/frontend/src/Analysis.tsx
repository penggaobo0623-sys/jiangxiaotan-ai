import { useEffect, useRef, useState } from 'react'
import { Sparkles, LoaderCircle, RefreshCw } from 'lucide-react'
import { getJson, money } from './api'
import { ModelCall } from './ModelCall'
import type { CallInfo } from './ModelCall'
import { UsageNotice } from './Care'
import type { UsagePolicy } from './Care'

interface Period { start: string; end: string; days: number }
interface Evidence { id: string; label: string; display: string; period: Period; limitation: string }
interface Summary {
  fingerprint: string; period: Period; coverage: { sales_days: number; expense_days: number; missing_sales_dates: string[]; zero_days?: number; rest_days?: number; checked_days?: number; unknown_dates?: string[] }
  totals: { revenue_cents: number | null; gross_profit_cents: number | null; extra_expense_cents: number | null; estimated_profit_cents: number | null }
  limitations: string[]; cannot_determine: string[]; omitted_product_count: number
}
interface Preview { usage_policy?: UsagePolicy; summary: Summary; model_available: boolean; model_mode: string; model_label: string; notice: string | null; disclosure: string }
interface Finding { follow_up?: string; id: string; title: string; observation: string; recommendation: string; limitation: string; evidence: Evidence[]; period: Period }
interface Result { usage_policy?: UsagePolicy; source: 'basic' | 'mock' | 'model'; source_label: string; model: string | null; reason: string; generated_at: string; summary: Summary; findings: Finding[]; limitations: string[]; cannot_determine: string[]; call?: CallInfo | null }

export function AnalysisPage({ day, revision }: { day: string; revision: number }) {
  const [goal, setGoal] = useState('看清商品贡献')
  const [feedback, setFeedback] = useState<Record<string,string>>({})
  const [preview, setPreview] = useState<Preview | null>(null)
  const [result, setResult] = useState<Result | null>(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [consent, setConsent] = useState(false)
  const [reload, setReload] = useState(0)
  const inFlight = useRef(false)
  const lastAnalysis = useRef(0)
  useEffect(() => {
    const controller = new AbortController()
    setLoading(true); setError(''); setPreview(null); setResult(null); setConsent(false)
    getJson<Preview>(`/api/analysis/preview?business_date=${day}`, AbortSignal.any([controller.signal, AbortSignal.timeout(8000)]))
      .then(data => { if (!controller.signal.aborted) setPreview(data) })
      .catch(() => { if (!controller.signal.aborted) setError('摘要读取失败，请检查后端连接并重新读取。') })
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [day, revision, reload])
  useEffect(() => {
    if (!result || busy) return
    const controller = new AbortController()
    const verify = () => {
      if (document.hidden) return
      getJson<Preview>(`/api/analysis/preview?business_date=${day}`, AbortSignal.any([controller.signal, AbortSignal.timeout(8000)]))
        .then(data => { if (!controller.signal.aborted && data.summary.fingerprint !== result.summary.fingerprint) { setResult(null); setPreview(data); setConsent(false); setError('记录已变化，旧分析已撤下。请核对新摘要后重新分析。') } })
        .catch(() => { if (!controller.signal.aborted) setError('暂时无法核验记录是否变化。下方仅为上次分析快照，请恢复连接后重新读取。') })
    }
    window.addEventListener('focus', verify)
    const timer = window.setInterval(verify, 15000)
    return () => { controller.abort(); window.removeEventListener('focus', verify); window.clearInterval(timer) }
  }, [result, day, busy])
  async function analyze(useModel: boolean, regenerate = false) {
    if (!preview || inFlight.current) return
    if (Date.now() - lastAnalysis.current < 1200) return
    lastAnalysis.current = Date.now()
    inFlight.current = true
    setBusy(true); setError(''); setResult(null); setFeedback({})
    try {
      const response = await fetch('/api/analysis', { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(30000), body: JSON.stringify({ business_date: day, summary_hash: preview.summary.fingerprint, use_model: useModel, consent_to_send: consent, goal, regenerate }) })
      const data = await response.json().catch(() => { throw new Error('服务响应无法读取，请检查连接；请求可能已发送，不要连续调用。') })
      if (!response.ok) throw new Error(data.detail || '分析失败，请重试。')
      setResult(data as Result)
    } catch (cause) { setError(cause instanceof TypeError ? '无法连接后端。请求可能已发送，请恢复连接后核对，不要连续调用。' : cause instanceof Error && cause.name !== 'TimeoutError' ? cause.message : '分析请求未完成，请稍后重试。外部请求可能已发送，请先等待，不要连续点击。') }
    finally { inFlight.current = false; setBusy(false) }
  }
  const summary = preview?.summary
  return <section className="analysis-page" aria-busy={busy || loading}>
    <article className="card analysis-intro"><div className="section-title"><h2>分析前，先看数据</h2><button className="text-button" disabled={busy || loading} onClick={() => setReload(n => n + 1)}><RefreshCw size={15} />重新读取摘要</button></div>
      {loading && <p role="status">正在读取本机经营摘要…</p>}
      {summary && preview && <><p className="analysis-period">{summary.period.start} 至 {summary.period.end} · 北京时间 · 已记录数据</p>
        <div className="analysis-totals">{[['已记录销售额', summary.totals.revenue_cents], ['商品估算毛利', summary.totals.gross_profit_cents], ['额外支出', summary.totals.extra_expense_cents], ['按已录入支出估算结余', summary.totals.estimated_profit_cents]].map(([label, value]) => <div key={String(label)}><span>{label}</span><strong>{money(value as number | null)}</strong></div>)}</div>
        <p>销售记录覆盖 <strong>{summary.coverage.sales_days} / 7 天</strong>，支出记录覆盖 {summary.coverage.expense_days} 天；确认零销售 {summary.coverage.zero_days ?? 0} 天，休息 {summary.coverage.rest_days ?? 0} 天，商家已核对 {summary.coverage.checked_days ?? 0} 天。覆盖不代表记全。</p>
        {!!summary.coverage.missing_sales_dates.length && <p className="analysis-warning">尚未明确销售情况的日期：{(summary.coverage.unknown_dates ?? summary.coverage.missing_sales_dates).join('、') || '无；其余日期可能为已标记休息'}。未知日期不能当零，休息日不参与营业日比较。</p>}
        <details><summary>查看将发送的摘要</summary><p>仅发送下方列出的汇总、商品明细、后端事实及候选行动，不发送原始数据库或支出备注。</p><pre className="summary-json">{JSON.stringify({ ...preview.summary, merchant_goal: goal }, null, 2)}</pre></details>
        <label className="form-field"><span>这次想先看什么？</span><select value={goal} disabled={busy} onChange={e => { setGoal(e.target.value); setResult(null); setConsent(false) }}>{['看清商品贡献','减少剩余和浪费','减少准备与操作负担','尝试一个新品'].map(t => <option key={t}>{t}</option>)}</select></label><p className="form-hint">选择目标不会补足缺失数据；没有损耗记录时，不能判断是否发生浪费。</p><UsageNotice policy={result?.usage_policy ?? preview.usage_policy} /><div className="analysis-disclosure"><p>{preview.disclosure}</p><p>当前模型：<strong>{preview.model_label}</strong>{preview.notice ? ` · ${preview.notice}` : ''}</p>
          {preview.model_available && <label className="check-field"><input type="checkbox" checked={consent} disabled={busy} onChange={e => setConsent(e.target.checked)} />{preview.model_mode === 'mock' ? '我知道当前为模拟服务，不是真实大模型' : '我同意将本页经营摘要发送给已配置的模型服务，了解可能产生费用'}</label>}
          <div className="form-actions"><button className="button primary" disabled={busy || (preview.model_available && !consent)} onClick={() => analyze(true)}>{busy ? <LoaderCircle size={16} className="spin" /> : <Sparkles size={16} />}{busy ? '正在分析，请稍候…' : '分析我的生意'}</button><button className="button secondary" disabled={busy} onClick={() => analyze(false)}>仅基础分析（不发送）</button></div>
          <p className="form-hint">打开本页不会调用模型。事实和金额由后端计算；模型可组织可选行动和复盘问题。自动语义校验有限，请结合实际判断。相同摘要默认复用已校验结果。</p>
        </div></>}
    </article>
    {error && <p role="alert" className="form-error">{error}</p>}
    {busy && <p role="status" className="list-state">正在分析这份摘要；模型不可用时会明确标注并提供基础分析。</p>}
    {result && <div className="analysis-result" aria-live="polite"><header className="card analysis-source"><h2>{result.source_label}</h2><p>{result.reason}</p>{result.model && <p>配置模型：{result.model}</p>}<p>数据范围：{result.summary.period.start} 至 {result.summary.period.end}；生成时间：{new Date(result.generated_at).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })}</p><ModelCall call={result.call} /><button className="button secondary" disabled={busy || (preview?.model_available && !consent)} onClick={() => { if (preview?.model_mode !== 'remote' || window.confirm('重新生成会跳过缓存，可能再次产生费用。确认继续？')) analyze(true,true) }}>重新分析（可能新增请求）</button><p>以下为本次摘要快照。记录变化后，请重新读取并分析。</p></header>
      {result.findings.map((item, index) => <article className="card analysis-finding" key={item.id}><span className="section-kicker">重点 {index + 1} · {item.period.start} 至 {item.period.end}</span><h2>{item.title}</h2><p>{item.observation}</p><h3>可以尝试</h3><p>{item.recommendation}</p><h3>下次复盘</h3><p>{item.follow_up}</p><div className="form-actions"><button className="button secondary" onClick={() => setFeedback(f => ({ ...f, [item.id]: '已记下：暂不处理，按自己的节奏来。' }))}>暂不处理</button><button className="text-button" onClick={() => setFeedback(f => ({ ...f, [item.id]: '已记下：这条不适合当前情况，没有执行任何经营调整。' }))}>不适合我的情况</button></div>{feedback[item.id] && <p role="status">{feedback[item.id]}</p>}<h3>数据依据</h3><ul className="evidence-list">{item.evidence.map(e => <li key={e.id}><strong>{e.label}：{e.display}</strong><small>{e.period.start} 至 {e.period.end} · {e.limitation}</small></li>)}</ul><p className="analysis-warning">局限：{item.limitation}</p></article>)}
      <article className="card analysis-limits"><h2>目前不能判断什么</h2><ul>{result.cannot_determine.map(t => <li key={t}>{t}</li>)}</ul><h3>共同口径</h3><ul>{result.limitations.map(t => <li key={t}>{t}</li>)}</ul></article>
    </div>}
  </section>
}
