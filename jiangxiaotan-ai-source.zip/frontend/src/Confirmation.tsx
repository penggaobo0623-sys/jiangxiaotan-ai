import { useEffect, useRef } from 'react'

export function ConfirmDialog({ message, busy, error, onCancel, onConfirm }: { message: string; busy: boolean; error: string; onCancel: () => void; onConfirm: () => void }) {
  const ref = useRef<HTMLDialogElement>(null)
  useEffect(() => { const element = ref.current; const previous = document.activeElement as HTMLElement | null; element?.showModal(); return () => { element?.close(); previous?.focus() } }, [])
  return <dialog ref={ref} className="info-dialog" aria-labelledby="confirm-title" onCancel={event => { event.preventDefault(); if (!busy) onCancel() }}>
    <h2 id="confirm-title">请确认此操作</h2><p className="confirm-message">{message}</p>
    {error && <p className="form-error" role="alert">{error}</p>}
    <div className="form-actions"><button autoFocus className="button secondary" disabled={busy} onClick={onCancel}>取消</button><button className="button danger" disabled={busy} onClick={onConfirm}>{busy ? '处理中…' : '确认操作'}</button></div>
  </dialog>
}
