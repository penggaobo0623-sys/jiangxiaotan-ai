import { useEffect, useRef, useState } from 'react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ArrowDownLeft, ArrowRight, ArrowUpRight, BarChart3, BookOpen, Check, CheckCircle2, ChevronRight, CircleHelp, ClipboardList, Database, Home, Leaf, LoaderCircle, Menu, RefreshCw, Server, ShieldCheck, Sparkles, Sprout, Store, Wallet, X } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { getJson, money } from './api'
import type { Dashboard, Health } from './api'
import { ProductsPage, RecordsPage } from './Business'
import { shanghaiDay } from './money'
import { AnalysisPage } from './Analysis'
import { MarketingPage } from './Marketing'
import { DataTools, dayLabels } from './Care'
import { requestLeave, hasUnsaved } from './unsaved'
import { UnsavedGuard } from './UnsavedGuard'

type Page = 'home' | 'dashboard' | 'products' | 'records' | 'analysis' | 'marketing' | 'system'
type Dialog = 'roadmap' | 'method' | null
const navigation: { id: Page; label: string; icon: LucideIcon }[] = [
  { id: 'home', label: '我的工作台', icon: Home },
  { id: 'dashboard', label: '经营看板', icon: BarChart3 },
  { id: 'products', label: '商品管理', icon: Store },
  { id: 'records', label: '营业记录', icon: ClipboardList },
  { id: 'analysis', label: '经营分析', icon: Sparkles },
  { id: 'marketing', label: '营销文案', icon: BookOpen },
  { id: 'system', label: '设置与帮助', icon: Server },
]
const pageFromHash = (): Page => ['dashboard', 'products', 'records', 'analysis', 'marketing', 'system'].includes(location.hash.slice(1)) ? location.hash.slice(1) as Page : 'home'

function StallIllustration() {
  return <svg className="stall-art" viewBox="0 0 400 250" role="img" aria-label="校园树荫下的绿色小吃摊插画">
    <ellipse cx="222" cy="226" rx="143" ry="13" fill="#154b39" opacity=".12" />
    <circle cx="312" cy="64" r="44" fill="#d9e9bf" /><circle cx="341" cy="96" r="34" fill="#cbdeac" />
    <path d="M319 74v144m0-94 21-23m-21 53-17-20" stroke="#749b76" strokeWidth="5" strokeLinecap="round" />
    <path d="M86 107h200v102H86z" fill="#fbf7eb" /><path d="M95 117h182v70H95z" fill="#e4eadb" />
    <path d="M82 89h209l-28-44H111z" fill="#2f7055" /><path d="M111 45h30l-13 44H98zm60 0h30v44h-43zm60 0h32l28 44h-47z" fill="#fff6de" />
    <path d="M82 89h209v13q-17 18-35 0-17 18-35 0-17 18-35 0-17 18-35 0-17 18-35 0-17 18-34 0z" fill="#448563" />
    <path d="M83 185h207v25H83z" fill="#2f7055" /><rect x="109" y="211" width="12" height="13" rx="3" fill="#3b5f4d" /><rect x="253" y="211" width="12" height="13" rx="3" fill="#3b5f4d" />
    <rect x="152" y="124" width="72" height="34" rx="5" fill="#fffaf0" /><text x="188" y="146" textAnchor="middle" fill="#2f7055" fontSize="15" fontFamily="sans-serif" fontWeight="700">江小摊</text>
    <path d="M112 169h30l-4 16h-22z" fill="#dca66b" /><path d="m119 169-5-20m13 20v-24m8 24 4-20" stroke="#aa744c" strokeWidth="3" />
    <path d="M239 168h30v17h-30z" fill="#efbc74" /><path d="M243 164q-4-9 3-13m7 13q-4-9 3-13m7 13q-4-9 3-13" stroke="#7e9b78" strokeWidth="2" fill="none" strokeLinecap="round" />
    <circle cx="65" cy="62" r="4" fill="#ecb774" /><path d="m276 22 3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="#e8b065" />
    <path d="M46 219q-7-39 10-34 17 3 7 34" fill="#7da77c" /><path d="M51 219q-22-20-17-30 15-3 22 30" fill="#a1bd8f" /><path d="M41 217h26l-5 12H45z" fill="#d9aa74" />
  </svg>
}

function EmptyState({ kind = 'chart' }: { kind?: 'chart' | 'products' }) {
  const Icon = kind === 'chart' ? BarChart3 : Store
  return <div className="empty-state"><span className="empty-icon"><Icon size={25} strokeWidth={1.6} /></span>
    <strong>{kind === 'chart' ? '你的第一条经营曲线，从这里开始' : '好生意，从了解每一款商品开始'}</strong>
    <p>{kind === 'chart' ? '最近 7 天暂无销售记录，暂时无法判断营业趋势。' : '最近 7 天暂无商品销售记录。'}</p>
    <span className="soft-label">到营业记录页，记下这一天的生意</span>
  </div>
}

export default function App() {
  const demoDateInitialized = useRef(false)
  const [page, setPage] = useState<Page>(pageFromHash)
  const [businessDate, setBusinessDate] = useState(shanghaiDay)
  const [menuOpen, setMenuOpen] = useState(false)
  const [dialog, setDialog] = useState<Dialog>(null)
  const [health, setHealth] = useState<Health | null>(null)
  const [dashboard, setDashboard] = useState<Dashboard | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [refreshId, setRefreshId] = useState(0)
  const [toast, setToast] = useState('')
  const acceptedHash = useRef(location.hash)

  useEffect(() => {
    const handler = () => {
      const target=location.hash
      if (hasUnsaved()) {
        history.replaceState(null,'',acceptedHash.current || '#home')
        requestLeave(() => { location.hash=target })
        return
      }
      acceptedHash.current=target; setPage(pageFromHash()); setMenuOpen(false)
    }
    window.addEventListener('hashchange', handler)
    return () => window.removeEventListener('hashchange', handler)
  }, [])

  useEffect(() => {
    const controller = new AbortController()
    const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(8000)])
    setLoading(true)
    setError('')
    Promise.all([getJson<Health>('/api/health', signal), getJson<Dashboard>(`/api/dashboard?business_date=${businessDate}`, signal)])
      .then(([service, data]) => {
        if (controller.signal.aborted) return
        setHealth(service); setDashboard(data)
        if (!demoDateInitialized.current) {
          demoDateInitialized.current = true
          if (service.demo_mode && service.demo_business_date) setBusinessDate(service.demo_business_date)
        }
        if (refreshId > 0) setToast('已重新获取后端状态和经营数据')
      }).catch((cause: unknown) => {
        if (controller.signal.aborted) return
        setHealth(null); setDashboard(null)
        setError(cause instanceof Error && cause.name === 'TimeoutError' ? '连接超时，请确认后端正在运行后重试。' : '暂时连接不到后端，请确认后端已启动，然后重试。')
      }).finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [refreshId, businessDate])

  useEffect(() => {
    if (!toast) return
    const timer = window.setTimeout(() => setToast(''), 3500)
    return () => clearTimeout(timer)
  }, [toast])

  useEffect(() => {
    if (!dialog) return
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setDialog(null) }
    window.addEventListener('keydown', close)
    const previous = document.activeElement as HTMLElement | null
    const element = document.querySelector<HTMLDialogElement>('#info-dialog')
    element?.showModal()
    return () => { window.removeEventListener('keydown', close); element?.close(); previous?.focus() }
  }, [dialog])

  const connected = health?.status === 'ok' && health.database === 'connected'
  const refresh = () => setRefreshId(value => value + 1)
  const onSaved = (message: string, day?: string) => { setToast(message); if (day) setBusinessDate(day); refresh() }
  const metricPrefix = businessDate === shanghaiDay() ? '今日' : '当日'
  const today = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: 'long', day: 'numeric', weekday: 'long' }).format(new Date())
  const trendData = dashboard?.trend.map(point => ({ ...point, label: point.date.slice(5).replace('-', '/'), revenue: point.revenue_cents === null ? null : point.revenue_cents / 100 })) ?? []
  const hasTrend = trendData.some(point => point.revenue !== null)
  const stats = [
    { label: '已录入销售额', value: dashboard?.metrics.revenue_cents ?? null, icon: Wallet, caption: '销售数量 × 商品售价', style: 'green' },
    { label: '商品估算毛利', value: dashboard?.metrics.gross_profit_cents ?? null, icon: Sprout, caption: '销售额 − 对应商品成本', style: 'green' },
    { label: '已录入额外支出', value: dashboard?.metrics.extra_expense_cents ?? null, icon: ArrowDownLeft, caption: '不重复计入商品单位成本', style: 'orange' },
    { label: `${metricPrefix}记录的成本`, value: dashboard?.metrics.recorded_cost_cents ?? null, icon: ArrowDownLeft, caption: '商品记录成本 + 额外记录支出', style: 'orange' },
    { label: '估算结余', value: dashboard?.metrics.estimated_profit_cents ?? null, icon: Sprout, caption: '扣除已录入支出，未含遗漏费用', style: 'blue' },
  ]

  return <div className="app-shell"><UnsavedGuard />
    <aside className={`sidebar ${menuOpen ? 'is-open' : ''}`}>
      <a className="brand" href="#home" onClick={() => setMenuOpen(false)}><span className="brand-symbol"><Store size={25} /></span><span>江小摊 <em>AI</em><small>校园小吃摊智能经营助手</small></span></a>
      <div className="workspace-label">我的经营空间 <span>本地版</span></div>
      <nav aria-label="主导航">{navigation.map(item => <a key={item.id} href={`#${item.id}`} onClick={() => setMenuOpen(false)} className={page === item.id ? 'nav-item active' : 'nav-item'} aria-current={page === item.id ? 'page' : undefined}><item.icon size={19} />{item.label}{page === item.id && <span className="active-dot" />}</a>)}</nav>
      <div className="nav-divider" /><p className="nav-caption">接下来，一起把生意做好</p>
      
      
      <div className="sidebar-bottom"><div className="sidebar-note"><Leaf size={20} /><strong>小摊位，也有大可能</strong><p>从认真记录每一天开始，<br />让经营多一份底气。</p><a href="#system">账本备份与帮助 →</a></div><div className="local-status"><span className={`status-dot ${connected ? 'online' : ''}`} />赛前版本 · 有据分析 <span>v0.5</span></div></div>
    </aside>
    {menuOpen && <button className="menu-backdrop" aria-label="关闭导航" onClick={() => setMenuOpen(false)} />}
    <div className="main-shell">
      <header className="topbar"><div className="breadcrumb"><button className="icon-button mobile-menu" aria-label="打开导航" aria-expanded={menuOpen} onClick={() => setMenuOpen(value => !value)}><Menu size={22} /></button><span>我的经营空间</span><ChevronRight size={14} /><strong>{navigation.find(item => item.id === page)?.label}</strong></div><div className="topbar-right"><span className="local-badge"><ShieldCheck size={14} /> {!health ? '数据来源确认中' : health.demo_mode ? '演示数据' : health.test_mode ? '独立测试数据' : health.sample_data || dashboard?.product_ranking.some(p => p.name.startsWith('演示·')) ? '含演示数据' : '账本保存在本机'}</span><span className="avatar">江</span></div></header>
      <main>
        <div className="page-heading"><div><div className="eyebrow">{page === 'system' ? 'CONNECTION' : 'MY LITTLE BUSINESS'}</div><h1>{page === 'home' ? '每一份认真经营，都值得被看见。' : navigation.find(item => item.id === page)?.label}</h1><p>{page === 'home' ? '欢迎来到江小摊，和你一起照顾好这门小生意。' : page === 'dashboard' ? '把每天的经营，变成看得懂的数字。' : page === 'products' ? '维护商品信息，妥善保留每一条历史快照。' : page === 'marketing' ? '确认商品事实，生成可核对的文案草稿。' : page === 'analysis' ? '查看摘要，主动分析，每条建议都有依据与局限。' : page === 'records' ? '选择营业日期，记录销售和额外经营支出。' : '查看前端、后端与数据库是否已准备就绪。'}</p></div><span className="date-label">{today}</span></div>

        {['home', 'dashboard', 'records', 'analysis'].includes(page) && <div className="business-date-bar"><label>选定营业日期 <input aria-label="选定营业日期" type="date" min="2000-01-01" max="2100-12-31" value={businessDate} onChange={event => { const value=event.target.value; if (value) requestLeave(() => setBusinessDate(value)) }} /></label><button className="text-button" onClick={() => { requestLeave(() => setBusinessDate(shanghaiDay())) }}>回到今天</button>{page !== 'records' && <a className="button primary" href="#records">记营业记录 <ArrowRight size={14} /></a>}</div>}

        {page === 'home' && <section className="welcome-banner"><div className="welcome-copy"><span className="banner-tag"><Sparkles size={14} /> 你的校园经营伙伴</span><h2>让每一个小吃摊，<br />都拥有自己的 <span>AI 经营顾问。</span></h2><p>记录一日生意，发现一点机会。<br />让数据帮你看清经营，让建议更有依据。</p><div className="banner-actions"><a className="button primary" href="#dashboard">打开经营看板 <ArrowRight size={16} /></a><button className="text-button" onClick={() => setDialog('method')}>查看计算口径 <ArrowUpRight size={15} /></button></div></div><StallIllustration /><span className="banner-caption">江汉大学 · 校园创业计划</span></section>}

        {error && <div className="error-banner" role="alert"><Server size={20} /><span><strong>服务连接暂不可用</strong>{error}</span><button className="button secondary" disabled={loading} onClick={refresh}>重新连接</button></div>}

        {page === 'marketing' ? <MarketingPage revision={refreshId} /> : page === 'analysis' ? <AnalysisPage key={`${businessDate}:${refreshId}`} day={businessDate} revision={refreshId} /> : page === 'products' ? <ProductsPage revision={refreshId} onSaved={onSaved} /> : page === 'records' ? <RecordsPage day={businessDate} revision={refreshId} onSaved={onSaved} /> : page === 'system' ? <section className="system-section"><DataTools />
          <div className="section-title"><h2>运行状态</h2><button className="button secondary" onClick={refresh} disabled={loading}><RefreshCw size={15} className={loading ? 'spin' : ''} />{loading ? '检查中…' : '检查服务连接'}</button></div>
          <div className="status-cards">{[{ name: '前端页面', icon: Home, ok: true, detail: 'React + TypeScript · 页面已加载' }, { name: '后端接口', icon: Server, ok: connected, detail: health ? `FastAPI · v${health.version}` : '等待连接到本机后端' }, { name: '数据库', icon: Database, ok: connected, detail: health ? `SQLite · 数据结构版本 ${health.schema_version}` : '需要通过后端检查连接' }].map(item => <article className="card system-card" key={item.name}><item.icon size={25} /><h3>{item.name}</h3><span className={`connection-pill ${item.ok ? 'connected' : ''}`}>{item.ok ? '已就绪' : loading ? '检查中' : '未连接'}</span><p>{item.detail}</p></article>)}</div>
          <article className="card api-card"><div><span className="section-kicker">真实接口请求</span><h2>前后端已经说上话了吗？</h2><p>此处内容来自后端健康检查接口，每次检查都会重新请求。</p></div><code>GET /api/health</code><pre aria-live="polite">{loading ? '正在请求后端…' : health ? JSON.stringify(health, null, 2) : '尚未获取接口响应。请启动后端后重试。'}</pre><a className="text-button" href="http://127.0.0.1:8000/docs" target="_blank" rel="noreferrer">打开后端接口文档 <ArrowUpRight size={15} /></a></article>
        </section> : <>
          <div className="section-title stats-heading"><div className="title-with-note"><h2>{metricPrefix === '今日' ? '今天的经营概况' : '当日经营概况'}</h2><span className="soft-label">{dashboard?.business_date ?? '北京时间今天'}</span></div><button className="text-button" onClick={refresh} disabled={loading}><RefreshCw size={14} className={loading ? 'spin' : ''} />{loading ? '正在连接…' : '刷新数据'}</button></div>
          <p className="care-status">{dashboard?.business_status ? dayLabels[dashboard.business_status.status] : ''} · 核对由商家确认，不是完整性证明</p>
          <section className="stats-grid" aria-label={`${metricPrefix}经营指标`} aria-busy={loading}>{stats.map(item => <article className="card stat-card" key={item.label}><div className="stat-top"><span>{item.label}</span><span className={`stat-icon ${item.style}`}><item.icon size={19} /></span></div><div className={`stat-number ${loading ? 'loading-number' : ''}`}>{loading ? <LoaderCircle size={24} className="spin" /> : money(item.value)}</div><div className="stat-bottom"><span>{loading ? '正在获取数据' : error ? '暂未获取数据' : item.value === null ? '暂无相关记录' : '根据当日记录计算'}</span><span className="stat-formula">{item.caption}</span></div></article>)}</section>
          <div className="method-note"><CircleHelp size={14} /><span>仅按已录入费用估算结余，不是实际净利润；未录入不代表没有发生。</span><button onClick={() => setDialog('method')}>了解计算口径 <ChevronRight size={13} /></button></div>
          <div className="dashboard-grid"><section className="card trend-card"><div className="card-heading"><div><h2>营业额趋势</h2><p>看看最近一周，生意的变化</p></div><span className="period-badge">最近 7 天</span></div><div className="chart-legend"><span />营业额（元）<small>未记录日期不视为零销售</small></div><div className="chart-area" aria-label="最近七天营业额趋势">{loading ? <div className="loading-state"><LoaderCircle className="spin" size={25} /><span>正在读取经营数据…</span></div> : error ? <div className="loading-state"><Server size={25} /><span>连接恢复后显示经营趋势</span></div> : <><ResponsiveContainer width="100%" height="100%"><AreaChart data={trendData} margin={{ top: 16, right: 10, left: 0, bottom: 0 }}><defs><linearGradient id="revenue-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#3b8062" stopOpacity={0.2} /><stop offset="100%" stopColor="#3b8062" stopOpacity={0} /></linearGradient></defs><CartesianGrid stroke="#e9ede7" strokeDasharray="4 5" vertical={false} /><XAxis interval={0} dataKey="label" axisLine={false} tickLine={false} tick={{ fill: '#92998e', fontSize: 11 }} dy={8} /><YAxis hide={!hasTrend} axisLine={false} tickLine={false} tick={{ fill: '#92998e', fontSize: 11 }} /><Tooltip formatter={value => value == null ? '未记录' : `¥${value}`} /><Area type="linear" dataKey="revenue" name="营业额" stroke="#3b8062" fill="url(#revenue-fill)" strokeWidth={2.5} connectNulls={false} dot={{ r: 3 }} /></AreaChart></ResponsiveContainer>{!hasTrend && <EmptyState />}</>}</div></section>
          <aside className="advisor-card"><div className="advisor-top"><span className="ai-icon"><Sparkles size={22} /></span><span>AI 经营助手 <small>成长中的经营伙伴</small></span><span className="stage-tag">已开放</span></div><h2>先把生意记下来，<br />再让建议有据可依。</h2><p>按已记录的七日数据查看经营重点、对应依据与局限。外部模型仅在你同意并主动点击后调用；不可用时提供基础分析。</p><div className="advisor-principle"><ShieldCheck size={16} />数据不足，就明确告诉你。</div><a className="button secondary" href="#analysis">分析我的生意 <ArrowRight size={16} /></a><Sparkles className="advisor-decoration" size={90} strokeWidth={.7} /></aside></div>
          <div className="bottom-grid"><section className="card product-card"><div className="card-heading"><div><h2>商品销售排行</h2><p>最近 7 天 · 按销售额排序</p></div><span className="small-icon"><Store size={19} /></span></div>{loading ? <div className="loading-state compact"><LoaderCircle className="spin" size={22} />读取中…</div> : error ? <div className="loading-state compact">服务连接恢复后显示商品数据</div> : dashboard?.product_ranking.length ? <div className="product-table"><table><thead><tr><th>商品</th><th>销量</th><th>销售额</th><th>估算毛利</th></tr></thead><tbody>{dashboard.product_ranking.map(item => <tr key={item.key}><td>{item.name}</td><td>{item.quantity}</td><td>{money(item.revenue_cents)}</td><td>{money(item.gross_profit_cents)}</td></tr>)}</tbody></table></div> : <EmptyState kind="products" />}</section>
          <section className="card journey-card"><div className="card-heading"><div><h2>按自己的节奏使用</h2><p>需要时打开，不必每天完成任务</p></div></div><div className="journey-item"><div><strong>收摊时核对这一天</strong><p><a href="#records">记下销量与支出，休息也可以标明 →</a></p></div></div><div className="journey-item"><div><strong>有疑问时再看建议</strong><p><a href="#analysis">查看数据依据，暂不处理也可以 →</a></p></div></div><div className="journey-item"><div><strong>账本由你保管</strong><p><a href="#system">备份与导出，不上传 →</a></p></div></div></section></div>
        </>}

        <footer><span><Leaf size={14} /> 江小摊 AI · 陪你认真经营每一天</span><button onClick={() => setDialog('method')}>数据说明</button><span className="footer-version">赛前版本 · 本地运行</span></footer>
      </main>
    </div>
    {toast && <div className="toast" role="status"><CheckCircle2 size={18} />{toast}</div>}
    {dialog && <dialog id="info-dialog" className="info-dialog" onCancel={() => setDialog(null)} onClick={event => { if (event.target === event.currentTarget) setDialog(null) }} aria-labelledby="dialog-title"><button className="icon-button dialog-close" onClick={() => setDialog(null)} aria-label="关闭说明"><X size={20} /></button><span className="dialog-icon">{dialog === 'method' ? <CircleHelp size={26} /> : <Sprout size={26} />}</span><h2 id="dialog-title">{dialog === 'method' ? '每一个数字，都有清楚的来处' : '江小摊，一步一步成长'}</h2>{dialog === 'method' ? <div className="dialog-content"><p>当前页面使用后端读取的 SQLite 数据；独立演示环境会明确标注“演示数据”，不代表真实商家成效。</p><ul><li>销售额 = 销售数量 × 商品售价。</li><li>记录的成本 = 销售数量 × 单位成本 + 额外记录支出。</li><li>估算利润 = 销售额 − 记录的成本。未录入的房租、人工、水电等费用不包含在内。</li><li>没有销售记录且未明确确认零销售时，销售额和结余显示“—”；休息日可单独记支出。</li><li>系统尚未采集订单数据，销售记录条数不能用作订单数。</li><li>营业日期按北京时间统计；趋势和商品排行覆盖当天及前六天。</li></ul></div> : <ol className="roadmap-list">{['基础版本：页面、接口与数据库连接', '营业记录：商品管理、记账与历史编辑', 'AI 诊断：数据汇总、规则分析与可选模型', '营销助手：基于已确认信息生成文案', '优化测试：移动端、异常处理与回归测试', '比赛准备：独立演示数据与产品验证'].map((item, index) => <li key={item}><span>{String(index + 1).padStart(2, '0')}</span><p>{item}<small>{index === 0 ? '已完成' : index === 1 || index === 2 || index === 3 ? '已开放' : index === 5 ? '本地演示已准备' : '已实施，真实设备待验证'}</small></p></li>)}</ol>}<button className="button primary dialog-confirm" onClick={() => setDialog(null)}>我知道了 <Check size={16} /></button></dialog>}
  </div>
}

