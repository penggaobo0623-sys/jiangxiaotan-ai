export interface Health {
  sample_data?: boolean
  demo_business_date?: string | null
  demo_mode?: boolean
  test_mode?: boolean
  status: string
  service: string
  version: string
  database: string
  schema_version: number
}

export interface Dashboard {
  business_status?: { status: string; label: string };
  business_date: string
  has_data: boolean
  metrics: {
    gross_profit_cents: number | null; extra_expense_cents: number | null;
    revenue_cents: number | null
    recorded_cost_cents: number | null
    estimated_profit_cents: number | null
    sales_record_count: number
    expense_record_count: number
    order_count: number | null
  }
  trend: { date: string; revenue_cents: number | null; has_sales_records: boolean }[]
  product_ranking: { key: string; product_id: number | null; name: string; quantity: number; revenue_cents: number; gross_profit_cents: number }[]
  notices: string[]
}

export async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(path, { signal: signal ?? AbortSignal.timeout(8000) })
  if (!response.ok) throw new Error(`服务请求失败（${response.status}），请确认后端已启动。`)
  return response.json() as Promise<T>
}

export function money(cents: number | null): string {
  return cents === null ? '—' : new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(cents / 100)
}

export interface Product {
  id: number; name: string; price_cents: number; unit_cost_cents: number
  is_active: boolean; created_at: string; sales_record_count: number
}
export interface Sale {
  id: number; product_id: number | null; product_name: string; business_date: string
  quantity: number; unit_price_cents: number; unit_cost_cents: number
  revenue_cents: number; gross_profit_cents: number; created_at: string
}
export interface Expense {
  id: number; business_date: string; category: string; amount_cents: number; created_at: string
}
export interface History { business_date: string; sales: Sale[]; expenses: Expense[] }

const pendingWrites = new Map<string, string>()
export async function mutate<T>(path: string, method: 'POST' | 'PUT' | 'DELETE', body?: unknown): Promise<T> {
  const identity = `${method}:${path}:${JSON.stringify(body)}`
  const guarded = method === 'POST' && ['/api/sales','/api/expenses'].includes(path)
  if (guarded) {
    if (!pendingWrites.has(identity)) pendingWrites.set(identity, crypto.randomUUID())
    body = { ...(body as object), request_id: pendingWrites.get(identity) }
  }
  let response: Response
  try {
    response = await fetch(path, {
      method, headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(10000),
    })
  } catch {
    throw new Error('请求未能确认完成，请刷新历史检查是否已保存，避免重复提交。')
  }
  if (!response.ok) {
    if (response.status < 500) pendingWrites.delete(identity)
    const data = await response.json().catch(() => ({}))
    throw new Error(typeof data.detail === 'string' ? data.detail : `操作失败（HTTP ${response.status}），请刷新后重试。`)
  }
  if (response.status === 204) { pendingWrites.delete(identity); return undefined as T }
  try {
    const result = await response.json() as T
    pendingWrites.delete(identity)
    return result
  } catch { throw new Error('服务响应无法读取，请先核对历史；同页相同销售或支出重发会沿用提交编号。') }
}

