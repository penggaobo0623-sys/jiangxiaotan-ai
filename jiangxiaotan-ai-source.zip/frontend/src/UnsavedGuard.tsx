import { useEffect, useState } from 'react'
import { ConfirmDialog } from './Confirmation'
import { clearUnsaved } from './unsaved'

export function UnsavedGuard() {
  const [action, setAction] = useState<(() => void) | null>(null)
  useEffect(() => {
    const listener = (event: Event) => setAction(() => (event as CustomEvent<() => void>).detail)
    window.addEventListener('jxt:leave', listener)
    return () => window.removeEventListener('jxt:leave', listener)
  }, [])
  if (!action) return null
  return <ConfirmDialog message="还有未保存或未确认完成的内容。离开后本页填写不会保留，确定离开吗？取消可继续填写。" busy={false} error="" onCancel={() => setAction(null)} onConfirm={() => { const next=action; clearUnsaved(); setAction(null); next() }} />
}
