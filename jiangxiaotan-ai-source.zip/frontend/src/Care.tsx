import { useEffect, useRef, useState } from 'react'
import { getJson, money, mutate } from './api'
import type { Product, History } from './api'
import { yuanToCents } from './money'
import { useUnsaved } from './unsaved'
import { ConfirmDialog } from './Confirmation'

export const dayLabels: Record<string, string> = { unrecorded: '尚未记录', rest: '今日休息', pending: '今日营业，记录待核对', checked: '今日营业，记录已核对', zero: '今日营业，确认没有销售' }
interface DayState { status: string; label: string; notice: string }
interface Props { day: string; revision: number; onSaved: (message: string, day?: string) => void }

export function DayStatus({ day, revision, onSaved }: Props) {
  const [state, setState] = useState<DayState | null>(null)
  const [choice, setChoice] = useState('unrecorded')
  const [busy, setBusy] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const flight = useRef(false)
  const [error, setError] = useState('')
  useEffect(() => { let alive = true; setState(null); setError(''); getJson<DayState>(`/api/business-days/${day}`).then(s => { if (alive) { setState(s); setChoice(s.status) } }).catch(() => { if (alive) setError('营业状态读取失败，请刷新。') }); return () => { alive = false } }, [day, revision])
  async function save(confirmed = false) {
    if (flight.current || !state) return
    if (['zero', 'rest', 'checked'].includes(choice) && !confirmed) { setConfirming(true); return }
    flight.current = true; setBusy(true); setError('')
    try { await mutate(`/api/business-days/${day}`, 'PUT', { status: choice }); setConfirming(false); onSaved('营业状态已更新', day) }
    catch (e) { setError(e instanceof Error ? e.message : '状态未保存') }
    finally { flight.current = false; setBusy(false) }
  }
  return <article className="card care-card"><h2>这一天的营业情况</h2><p>{state ? `当前：${state.label}` : '正在读取…'}</p><div className="form-actions"><label className="form-field"><span>核对营业状态</span><select value={choice} disabled={busy || !state} onChange={e => setChoice(e.target.value)}>{Object.entries(dayLabels).map(([v,t]) => <option key={v} value={v}>{t}</option>)}</select></label><button className="button secondary" disabled={busy || !state} onClick={() => save()}>{busy ? '保存中…' : '保存营业状态'}</button></div><p className="form-hint">休息也是正常安排。没有填写不等于零销售；休息日仍可记支出。改动账目后需要重新核对。</p>{error && <p className="form-error" role="alert">{error}</p>}{confirming && <ConfirmDialog message={`确认 ${day}：${dayLabels[choice]}？这是你的核对声明，不代表系统证明账目完整。`} busy={busy} error={error} onCancel={() => setConfirming(false)} onConfirm={() => save(true)} />}</article>
}

interface ClosingPayload { request_id: string; business_date: string; sales: { product_id: number; quantity: number; expected_price_cents: number; expected_cost_cents: number }[]; expenses: { business_date: string; category: string; amount_cents: number }[] }
export function ClosingForm({ day, revision, onSaved }: Props) {
  const [products, setProducts] = useState<Product[]>([])
  const [quantities, setQuantities] = useState<Record<number,string>>({})
  const [expenses, setExpenses] = useState([{ category: '', amount: '' }])
  const [existing, setExisting] = useState(0)
  const [review, setReview] = useState<ClosingPayload | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [uncertain, setUncertain] = useState(false)
  const flight = useRef(false)
  const dirty = Object.values(quantities).some(q => q !== '') || expenses.some(e => e.category || e.amount) || !!review
  useUnsaved(dirty)
  useEffect(() => { let alive = true; Promise.all([getJson<Product[]>('/api/products'), getJson<History>(`/api/records?business_date=${day}`)]).then(([p,h]) => { if (alive) { setProducts(p.filter(p => p.is_active)); setExisting(h.sales.length) } }).catch(() => { if (alive) setError('收摊资料读取失败，请刷新后再填。') }); return () => { alive = false } }, [day, revision])
  function prepare(event: React.FormEvent) {
    event.preventDefault(); setError('')
    try {
      const sales = products.filter(p => quantities[p.id] !== undefined && quantities[p.id] !== '').map(p => {
        const q = quantities[p.id]
        if (!/^\d+$/.test(q) || Number(q) > 100000) throw new Error('销量填写 0–100000 的整数；没有核对的商品请留空。')
        return { product_id: p.id, quantity: Number(q), expected_price_cents: p.price_cents, expected_cost_cents: p.unit_cost_cents }
      })
      const entries = expenses.filter(e => e.category || e.amount).map(e => { const cents = yuanToCents(e.amount); if (!e.category.trim() || cents <= 0) throw new Error('请补全支出说明和正数金额。'); return { business_date: day, category: e.category.trim(), amount_cents: cents } })
      if (!sales.length && !entries.length) throw new Error('请填销量或支出。确认整天无销售请使用上方营业状态。')
      setReview({ request_id: crypto.randomUUID(), business_date: day, sales, expenses: entries })
    } catch (e) { setError(e instanceof Error ? e.message : '请核对输入') }
  }
  function complete(message: string) { setReview(null); setUncertain(false); setQuantities({}); setExpenses([{ category: '', amount: '' }]); onSaved(message, day) }
  async function save() {
    if (!review || flight.current) return
    flight.current = true; setBusy(true); setError('')
    try { await mutate('/api/closing', 'POST', review); complete('收摊内容已保存，请核对下方历史，再确认营业状态') }
    catch (e) { setUncertain(true); setError(e instanceof Error ? e.message : '请求结果未知，请核对本次提交') }
    finally { flight.current = false; setBusy(false) }
  }
  async function verify() {
    if (!review || flight.current) return
    flight.current = true; setBusy(true); setError('')
    try {
      const result = await getJson<{ saved: boolean }>(`/api/closing/requests/${review.request_id}`)
      if (result.saved) complete('已核对：本次提交已经保存，没有重复录入')
      else { setUncertain(false); setError('目前未查到保存结果；可保留同一提交编号再次确认保存。正在处理的请求即使稍后完成，也会按编号防止重复。') }
    } catch { setError('暂时无法核对，请恢复连接后继续；请勿另建一份重复提交。') }
    finally { flight.current = false; setBusy(false) }
  }
  const revenue = review?.sales.reduce((sum,s) => sum+s.quantity*s.expected_price_cents,0) ?? 0
  const cost = review?.sales.reduce((sum,s) => sum+s.quantity*s.expected_cost_cents,0) ?? 0
  const extra = review?.expenses.reduce((sum,e) => sum+e.amount_cents,0) ?? 0
  return <article className="card care-card"><h2>每日收摊 · 一次核对再保存</h2><p>只新增本次填写的记录，不覆盖历史。{existing > 0 ? `当天已有 ${existing} 条销售，请先看历史，避免重复记整天销量。` : ''}</p><form onSubmit={prepare}><fieldset disabled={busy || !!review} className="business-fieldset"><div className="closing-products">{products.map(p => <label key={p.id} className="closing-row"><span><strong>{p.name}</strong><small>售价 {money(p.price_cents)} · 成本 {money(p.unit_cost_cents)}</small></span><input aria-label={`${p.name}收摊销量`} inputMode="numeric" maxLength={6} placeholder="未核对留空" value={quantities[p.id] ?? ''} onChange={e => setQuantities(q => ({ ...q, [p.id]: e.target.value }))} /></label>)}</div><p className="form-hint">填 0 表示核对过这款商品本次没有销售，不会创建虚假销售行，也不代表整天零销售。</p>{expenses.map((e,i) => <div className="form-grid" key={i}><label className="form-field"><span>额外支出说明 {i+1}</span><input maxLength={60} value={e.category} onChange={event => setExpenses(list => list.map((v,j) => j===i ? { ...v, category: event.target.value } : v))} /></label><label className="form-field"><span>额外支出金额 {i+1}（元）</span><input inputMode="decimal" value={e.amount} onChange={event => setExpenses(list => list.map((v,j) => j===i ? { ...v, amount: event.target.value } : v))} /></label></div>)}<div className="form-actions"><button type="button" className="button secondary" disabled={expenses.length>=20} onClick={() => setExpenses(list => [...list,{ category: '', amount: '' }])}>再加一笔支出</button><button className="button primary">核对本次收摊内容</button></div></fieldset></form>
    {review && <section className="closing-review" aria-label="收摊核对单"><h3>{review.business_date} · 本次新增核对单</h3><ul>{review.sales.map(s => <li key={s.product_id}>{products.find(p => p.id===s.product_id)?.name}：{s.quantity}，销售额 {money(s.quantity*s.expected_price_cents)}</li>)}{review.expenses.map((e,i) => <li key={i}>{e.category}：{money(e.amount_cents)}</li>)}</ul><p>销售额 {money(revenue)} · 商品成本 {money(cost)} · 额外支出 {money(extra)}</p><p>这些是本次新增金额，非当日完整结果。提交编号会用于防止重复记账。</p><div className="form-actions"><button className="button primary" disabled={busy || uncertain} onClick={save}>{busy ? '处理中…' : '确认保存本次内容'}</button><button className="button secondary" disabled={busy} onClick={verify}>核对本次是否已保存</button><button className="text-button" disabled={busy || uncertain} onClick={() => setReview(null)}>返回修改</button></div></section>}
    {error && <p className="form-error" role="alert">{error}</p>}<p className="form-hint">填写内容仅在当前页面内存中，离开后不保留草稿。请勿把已计入单位成本的费用重复填入支出。</p></article>
}

export function Recovery({ day, revision, onSaved }: Props) {
  const [data, setData] = useState<{ sales: { id:number; product_name:string }[]; expenses: { id:number; category:string }[] }>({ sales: [], expenses: [] })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const flight = useRef(false)
  useEffect(() => { let alive = true; getJson<typeof data>(`/api/recycle?business_date=${day}`).then(d => { if (alive) setData(d) }).catch(() => { if (alive) setError('回收区暂时无法读取，请刷新。') }); return () => { alive = false } }, [day, revision])
  async function restore(kind: string, id: number) { if (flight.current) return; flight.current = true; setBusy(true); setError(''); try { await mutate(`/api/recycle/${kind}/${id}/restore`, 'POST'); onSaved('记录已恢复，请重新核对当天账目') } catch (e) { setError(e instanceof Error ? e.message : '恢复失败') } finally { flight.current = false; setBusy(false) } }
  return <details className="card care-card"><summary>当日回收区 · {data.sales.length+data.expenses.length} 条</summary><p>删除记录仍保留原快照，恢复后重新参与看板计算。不会自动套用商品现价。</p>{data.sales.map(s => <p key={`s${s.id}`}>{s.product_name} <button className="button secondary" disabled={busy} onClick={() => restore('sales',s.id)}>恢复销售 #{s.id}</button></p>)}{data.expenses.map(e => <p key={`e${e.id}`}>{e.category} <button className="button secondary" disabled={busy} onClick={() => restore('expenses',e.id)}>恢复支出 #{e.id}</button></p>)}{error && <p role="alert">{error}</p>}</details>
}

export function DataTools() {
  return <article className="card care-card"><h2>账本备份与导出</h2><p>下载仅保存到你的电脑，不上传。包含经营记录，含回收区和修改历史，请妥善保管。</p><div className="form-actions"><a className="button secondary" href="/api/data/backup" download>下载完整数据库备份</a><a className="button secondary" href="/api/data/export" download>导出账本 JSON</a></div><p className="form-hint">备份包含本机缓存和调用记录，不含环境密钥。恢复或覆盖现有账本需另行确认；本页不提供覆盖操作。修改历史可通过导出文件查看。</p></article>
}

export interface UsagePolicy { used: number; limit: number; remaining: number; notice: string; recent?: { id: number; kind: string; created_at: string; metadata_json: string | null }[] }
export function UsageNotice({ policy }: { policy?: UsagePolicy }) {
  if (!policy) return null
  return <details className="usage-notice"><summary>今日真实请求 {policy.used} / {policy.limit} 次 · 剩余 {policy.remaining} 次</summary><p>{policy.notice} 模拟调用不计入。相同数据可复用一天内的已校验结果，主动重新生成可能再次收费。</p>{policy.recent?.map(r => <p key={r.id}>#{r.id} · {r.kind==='analysis' ? '经营分析' : '营销文案'} · {r.metadata_json ? '已记录回执' : '已预占次数，用量待核对'}</p>)}</details>
}
