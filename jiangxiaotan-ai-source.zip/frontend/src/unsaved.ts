import { useEffect, useRef } from 'react'

const dirtyForms = new Set<symbol>()
export function hasUnsaved() { return dirtyForms.size > 0 }
export function requestLeave(action: () => void) {
  if (!dirtyForms.size) { action(); return }
  window.dispatchEvent(new CustomEvent('jxt:leave', { detail: action }))
}
export function clearUnsaved() { dirtyForms.clear() }
document.addEventListener('click', event => {
  const link = (event.target as Element)?.closest('a[href^="#"]')
  const href = link?.getAttribute('href')
  if (href && href !== location.hash && !event.defaultPrevented && dirtyForms.size) {
    event.preventDefault()
    requestLeave(() => { location.hash = href })
  }
})
export function useUnsaved(dirty: boolean) {
  const id = useRef(Symbol('form'))
  useEffect(() => {
    const key = id.current
    if (dirty) dirtyForms.add(key)
    const unload = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = '' } }
    window.addEventListener('beforeunload', unload)
    return () => { dirtyForms.delete(key); window.removeEventListener('beforeunload', unload) }
  }, [dirty])
}
