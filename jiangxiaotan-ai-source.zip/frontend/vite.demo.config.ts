import base from './vite.config'
export default {
  ...base,
  cacheDir: 'node_modules/.vite-demo',
  server: { ...base.server, host: '127.0.0.1', port: 5175, strictPort: true, proxy: { '/api': 'http://127.0.0.1:8002' } },
  preview: { host: '127.0.0.1', port: 5175, strictPort: true, proxy: { '/api': 'http://127.0.0.1:8002' } },
}
